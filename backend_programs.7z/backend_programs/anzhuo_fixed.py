#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
智能课表 - 安卓版（优化版本）
解决字符显示和界面结构问题
"""

import os
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.actionbar import ActionBar, ActionView, ActionPrevious, ActionButton
from kivy.graphics import Color, Rectangle, Line
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.core.text import LabelBase
from plyer import notification
from datetime import datetime, timedelta
import threading

# 注册中文字体 - 解决字符显示问题
def setup_chinese_font():
    """设置中文字体支持"""
    try:
        # Windows系统字体路径
        font_paths = [
            "C:/Windows/Fonts/msyh.ttc",  # 微软雅黑
            "C:/Windows/Fonts/simsun.ttc",  # 宋体
            "C:/Windows/Fonts/simhei.ttf",  # 黑体
            "/System/Library/Fonts/PingFang.ttc",  # macOS
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"  # Linux
        ]
        
        for font_path in font_paths:
            if os.path.exists(font_path):
                LabelBase.register(name="Chinese", fn_regular=font_path)
                print(f"已加载中文字体: {font_path}")
                return True
        
        print("未找到系统中文字体，使用默认字体")
        return False
    except Exception as e:
        print(f"字体加载失败: {e}")
        return False

# 设置中文字体
FONT_LOADED = setup_chinese_font()
FONT_NAME = "Chinese" if FONT_LOADED else "Roboto"

# 尝试导入数据库模块
try:
    from mysqlconnect import get_db_connection, check_table_exists, get_all_table_names, query_by_id_and_table, \
        update_field, insert_into_table, delete_by_id_and_table
    import pymysql
    DB_AVAILABLE = True
    print("数据库模块加载成功")
except ImportError as e:
    print(f"数据库模块加载失败: {e}")
    DB_AVAILABLE = False

# 应用主题配色方案
class Theme:
    PRIMARY = (0.2, 0.6, 0.86, 1)      # 主色调 - 蓝色
    SECONDARY = (0.96, 0.26, 0.21, 1)  # 次要色 - 红色
    SUCCESS = (0.3, 0.8, 0.3, 1)       # 成功色 - 绿色
    WARNING = (1.0, 0.76, 0.03, 1)     # 警告色 - 橙色
    LIGHT = (0.98, 0.98, 0.98, 1)     # 浅色背景
    DARK = (0.2, 0.2, 0.2, 1)         # 深色文字
    CARD = (1, 1, 1, 1)               # 卡片背景
    BORDER = (0.9, 0.9, 0.9, 1)       # 边框色

# 数据库管理器
class DatabaseManager:
    def __init__(self):
        self.db_available = DB_AVAILABLE
        print(f"数据库连接状态: {'可用' if self.db_available else '不可用'}")
        
    def get_all_courses(self):
        """获取所有课程数据"""
        if not self.db_available:
            return self.get_demo_courses()
        
        try:
            courses = []
            table_names = get_all_table_names()
            
            for table_name in table_names:
                if table_name.lower() in ['course_schedule', 'courses']:
                    continue
                    
                try:
                    conn = get_db_connection()
                    cursor = conn.cursor(pymysql.cursors.DictCursor)
                    cursor.execute(f"SELECT * FROM `{table_name}`")
                    records = cursor.fetchall()
                    
                    for record in records:
                        course = {
                            'id': record['id'],
                            'name': table_name,
                            'teacher': record.get('teacher', ''),
                            'location': record.get('place', ''),
                            'day': self.parse_day(record.get('day', '0')),
                            'start': self.parse_time(record.get('time', '第1节')),
                            'end': self.parse_end_time(record.get('time', '第1节')),
                            'reminder': 15,
                            'weeks': self.parse_weeks(record.get('week', '1')),
                            'term': record.get('term', ''),
                            'table_name': table_name,
                            'record_id': record['id']
                        }
                        courses.append(course)
                        
                    cursor.close()
                    conn.close()
                    
                except Exception as e:
                    print(f"查询表 {table_name} 失败: {e}")
                    
            return courses
            
        except Exception as e:
            print(f"获取课程数据失败: {e}")
            return self.get_demo_courses()
    
    def get_demo_courses(self):
        """获取演示课程数据"""
        return [
            {
                "id": 1,
                "name": "高等数学",
                "teacher": "张教授",
                "location": "A座101教室",
                "day": 0,
                "start": "08:00",
                "end": "09:40",
                "reminder": 15,
                "weeks": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
            },
            {
                "id": 2,
                "name": "大学英语",
                "teacher": "李老师",
                "location": "外语楼203",
                "day": 1,
                "start": "10:00",
                "end": "11:40",
                "reminder": 10,
                "weeks": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
            },
            {
                "id": 3,
                "name": "计算机基础",
                "teacher": "王教授",
                "location": "机房A201",
                "day": 2,
                "start": "14:00",
                "end": "15:40",
                "reminder": 20,
                "weeks": [1, 2, 3, 4, 5, 6, 7, 8]
            },
            {
                "id": 4,
                "name": "体育课",
                "teacher": "刘老师",
                "location": "体育馆",
                "day": 3,
                "start": "16:00",
                "end": "17:40",
                "reminder": 5,
                "weeks": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
            }
        ]
    
    def parse_day(self, day_str):
        """解析星期"""
        day_map = {'0': 0, '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6}
        return day_map.get(str(day_str), 0)
    
    def parse_time(self, time_str):
        """解析开始时间"""
        time_map = {
            '第1节': '08:00', '第2节': '08:50', '第3节': '10:00', '第4节': '10:50',
            '第5节': '14:00', '第6节': '14:50', '第7节': '16:00', '第8节': '16:50',
            '第9节': '19:00', '第10节': '19:50', '第11节': '20:40', '第12节': '21:30',
            '1-2节': '08:00', '3-4节': '10:00', '5-6节': '14:00', '7-8节': '16:00',
            '9-10节': '19:00', '11-12节': '20:40'
        }
        return time_map.get(str(time_str), '08:00')
    
    def parse_end_time(self, time_str):
        """解析结束时间"""
        time_map = {
            '第1节': '08:40', '第2节': '09:30', '第3节': '10:40', '第4节': '11:30',
            '第5节': '14:40', '第6节': '15:30', '第7节': '16:40', '第8节': '17:30',
            '第9节': '19:40', '第10节': '20:30', '第11节': '21:20', '第12节': '22:10',
            '1-2节': '09:30', '3-4节': '11:30', '5-6节': '15:30', '7-8节': '17:30',
            '9-10节': '20:30', '11-12节': '22:10'
        }
        return time_map.get(str(time_str), '08:40')
    
    def parse_weeks(self, week_str):
        """解析周次"""
        try:
            if '-' in str(week_str):
                start, end = map(int, str(week_str).split('-'))
                return list(range(start, end + 1))
            else:
                return [int(week_str)]
        except:
            return [1]

# 主界面屏幕
class MainScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = "main"
        self.current_week = 1
        self.current_day = None
        self.db_manager = DatabaseManager()
        self.courses = []
        self.setup_ui()
        
    def setup_ui(self):
        """设置主界面UI"""
        main_layout = BoxLayout(orientation='vertical', spacing=5, padding=10)
        
        # 设置背景色
        with main_layout.canvas.before:
            Color(*Theme.LIGHT)
            self.bg_rect = Rectangle(size=main_layout.size, pos=main_layout.pos)
        main_layout.bind(size=self.update_bg, pos=self.update_bg)
        
        # 顶部标题栏
        header = self.create_header()
        main_layout.add_widget(header)
        
        # 周次和日期控制
        control_layout = self.create_controls()
        main_layout.add_widget(control_layout)
        
        # 课程列表
        self.scroll_view = self.create_course_list()
        main_layout.add_widget(self.scroll_view)
        
        # 底部状态栏
        self.status_bar = Label(
            text="欢迎使用智能课表",
            size_hint_y=None,
            height=30,
            font_name=FONT_NAME,
            color=Theme.DARK
        )
        main_layout.add_widget(self.status_bar)
        
        self.add_widget(main_layout)
        
        # 初始化加载数据
        Clock.schedule_once(lambda dt: self.load_courses(), 0.5)
    
    def update_bg(self, instance, value):
        """更新背景"""
        self.bg_rect.size = instance.size
        self.bg_rect.pos = instance.pos
    
    def create_header(self):
        """创建标题栏"""
        header_layout = BoxLayout(size_hint_y=None, height=60, spacing=10, padding=5)
        
        # 背景
        with header_layout.canvas.before:
            Color(*Theme.PRIMARY)
            self.header_rect = Rectangle(size=header_layout.size, pos=header_layout.pos)
        header_layout.bind(size=self.update_header_bg, pos=self.update_header_bg)
        
        # 标题
        title = Label(
            text="智能课表",
            font_size=24,
            bold=True,
            color=(1, 1, 1, 1),
            font_name=FONT_NAME
        )
        header_layout.add_widget(title)
        
        # 刷新按钮
        refresh_btn = Button(
            text="刷新",
            size_hint_x=None,
            width=80,
            background_normal='',
            background_color=Theme.SUCCESS,
            color=(1, 1, 1, 1),
            font_name=FONT_NAME
        )
        refresh_btn.bind(on_press=self.refresh_data)
        header_layout.add_widget(refresh_btn)
        
        return header_layout
    
    def update_header_bg(self, instance, value):
        """更新标题栏背景"""
        self.header_rect.size = instance.size
        self.header_rect.pos = instance.pos
    
    def create_controls(self):
        """创建控制区域"""
        control_layout = BoxLayout(orientation='vertical', size_hint_y=None, height=120, spacing=10)
        
        # 周次控制
        week_layout = BoxLayout(size_hint_y=None, height=50, spacing=10)
        
        prev_btn = Button(
            text="◀ 上周",
            size_hint_x=None,
            width=80,
            background_normal='',
            background_color=Theme.PRIMARY,
            color=(1, 1, 1, 1),
            font_name=FONT_NAME
        )
        prev_btn.bind(on_press=lambda x: self.change_week(-1))
        
        self.week_label = Label(
            text=f"第 {self.current_week} 周",
            font_size=18,
            bold=True,
            color=Theme.DARK,
            font_name=FONT_NAME
        )
        
        next_btn = Button(
            text="下周 ▶",
            size_hint_x=None,
            width=80,
            background_normal='',
            background_color=Theme.PRIMARY,
            color=(1, 1, 1, 1),
            font_name=FONT_NAME
        )
        next_btn.bind(on_press=lambda x: self.change_week(1))
        
        week_layout.add_widget(prev_btn)
        week_layout.add_widget(self.week_label)
        week_layout.add_widget(next_btn)
        
        # 星期筛选
        day_layout = GridLayout(cols=4, size_hint_y=None, height=60, spacing=5)
        
        days = [
            ("全部", None, Theme.WARNING),
            ("周一", 0, Theme.PRIMARY),
            ("周二", 1, Theme.PRIMARY),
            ("周三", 2, Theme.PRIMARY),
            ("周四", 3, Theme.PRIMARY),
            ("周五", 4, Theme.PRIMARY),
            ("周六", 5, Theme.PRIMARY),
            ("周日", 6, Theme.PRIMARY)
        ]
        
        for day_name, day_index, color in days:
            btn = Button(
                text=day_name,
                background_normal='',
                background_color=color,
                color=(1, 1, 1, 1),
                font_name=FONT_NAME
            )
            btn.bind(on_press=lambda x, day_idx=day_index: self.filter_by_day(day_idx))
            day_layout.add_widget(btn)
        
        control_layout.add_widget(week_layout)
        control_layout.add_widget(day_layout)
        
        return control_layout
    
    def create_course_list(self):
        """创建课程列表"""
        scroll = ScrollView()
        self.course_layout = BoxLayout(orientation='vertical', spacing=10, size_hint_y=None)
        self.course_layout.bind(minimum_height=self.course_layout.setter('height'))
        scroll.add_widget(self.course_layout)
        return scroll
    
    def create_course_card(self, course):
        """创建课程卡片"""
        card_layout = BoxLayout(orientation='vertical', size_hint_y=None, height=120, spacing=5, padding=15)
        
        # 卡片背景和边框
        with card_layout.canvas.before:
            Color(*Theme.CARD)
            card_bg = Rectangle(size=card_layout.size, pos=card_layout.pos)
            Color(*Theme.BORDER)
            card_border = Line(rectangle=(card_layout.x, card_layout.y, card_layout.width, card_layout.height), width=1)
        
        def update_card_graphics(instance, value):
            card_bg.size = instance.size
            card_bg.pos = instance.pos
            card_border.rectangle = (instance.x, instance.y, instance.width, instance.height)
        
        card_layout.bind(size=update_card_graphics, pos=update_card_graphics)
        
        # 课程标题
        title_layout = BoxLayout(size_hint_y=None, height=30)
        
        course_name = Label(
            text=course['name'],
            font_size=18,
            bold=True,
            color=Theme.PRIMARY,
            text_size=(300, None),
            halign='left',
            font_name=FONT_NAME
        )
        title_layout.add_widget(course_name)
        
        # 星期标签
        days_cn = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
        day_label = Label(
            text=days_cn[course['day']],
            size_hint_x=None,
            width=50,
            font_size=14,
            color=Theme.SUCCESS,
            font_name=FONT_NAME
        )
        title_layout.add_widget(day_label)
        
        # 课程详情
        info_text = f"教师: {course['teacher']}\n地点: {course['location']}\n时间: {course['start']} - {course['end']}"
        
        info_label = Label(
            text=info_text,
            font_size=14,
            color=Theme.DARK,
            text_size=(None, None),
            halign='left',
            valign='top',
            font_name=FONT_NAME
        )
        
        card_layout.add_widget(title_layout)
        card_layout.add_widget(info_label)
        
        return card_layout
    
    def refresh_data(self, instance):
        """刷新数据"""
        self.status_bar.text = "正在刷新数据..."
        self.courses = self.db_manager.get_all_courses()
        self.load_courses()
        self.status_bar.text = f"数据已刷新，共 {len(self.courses)} 门课程"
    
    def change_week(self, delta):
        """切换周次"""
        new_week = max(1, min(20, self.current_week + delta))
        if new_week != self.current_week:
            self.current_week = new_week
            self.week_label.text = f"第 {self.current_week} 周"
            self.load_courses()
    
    def filter_by_day(self, day_index):
        """按星期筛选"""
        self.current_day = day_index
        self.load_courses()
        
        if day_index is None:
            self.status_bar.text = f"第{self.current_week}周 | 显示: 全部课程"
        else:
            days_cn = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
            self.status_bar.text = f"第{self.current_week}周 | 显示: {days_cn[day_index]} 课程"
    
    def load_courses(self):
        """加载课程数据"""
        if not self.courses:
            self.courses = self.db_manager.get_all_courses()
        
        # 筛选课程
        if self.current_day is not None:
            display_courses = [
                c for c in self.courses
                if c['day'] == self.current_day and self.current_week in c.get('weeks', [])
            ]
        else:
            display_courses = [
                c for c in self.courses
                if self.current_week in c.get('weeks', [])
            ]
        
        # 按星期和时间排序
        display_courses.sort(key=lambda x: (x['day'], x['start']))
        
        # 更新显示
        self.update_course_list(display_courses)
        
        # 更新状态
        count = len(display_courses)
        if self.current_day is None:
            self.status_bar.text = f"第{self.current_week}周 | 共 {count} 门课程"
        else:
            days_cn = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
            self.status_bar.text = f"第{self.current_week}周 | {days_cn[self.current_day]} | 共 {count} 门课程"
    
    def update_course_list(self, courses):
        """更新课程列表显示"""
        self.course_layout.clear_widgets()
        
        if not courses:
            empty_label = Label(
                text="本周暂无课程安排",
                font_size=20,
                color=(0.6, 0.6, 0.6, 1),
                size_hint_y=None,
                height=200,
                font_name=FONT_NAME
            )
            self.course_layout.add_widget(empty_label)
            return
        
        for course in courses:
            card = self.create_course_card(course)
            self.course_layout.add_widget(card)

# 主应用类
class SmartTimetableApp(App):
    def build(self):
        self.title = "智能课表"
        
        # 设置窗口大小（适合移动设备）
        Window.size = (400, 700)
        
        # 创建屏幕管理器
        sm = ScreenManager()
        
        # 添加主屏幕
        main_screen = MainScreen()
        sm.add_widget(main_screen)
        
        return sm

if __name__ == '__main__':
    SmartTimetableApp().run() 