import sqlite3
import os
import logging
import traceback


# 设置日志
def setup_logging():
    try:
        log_file = os.path.join(os.path.dirname(__file__), 'app.log')
        logging.basicConfig(
            filename=log_file,
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            encoding='utf-8'
        )
    except Exception as e:
        print(f"日志设置失败: {e}")


setup_logging()


# ======================== 数据库连接管理 ========================
def get_db_connection():
    """获取SQLite数据库连接"""
    try:
        db_path = os.path.join(os.path.dirname(__file__), 'smart_timetable.db')
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        return conn
    except Exception as e:
        logging.error(f"数据库连接失败: {e}")
        return None


def init_database():
    """初始化数据库表结构"""
    try:
        conn = get_db_connection()
        if conn:
            cursor = conn.cursor()
            cursor.execute('''
                           CREATE TABLE IF NOT EXISTS courses
                           (
                               id
                               INTEGER
                               PRIMARY
                               KEY
                               AUTOINCREMENT,
                               name
                               TEXT
                               NOT
                               NULL,
                               place
                               TEXT,
                               time
                               TEXT,
                               week
                               INTEGER,
                               teacher
                               TEXT,
                               day
                               INTEGER,
                               term
                               TEXT
                           )
                           ''')
            conn.commit()
            conn.close()
            logging.info("数据库初始化成功")
    except Exception as e:
        logging.error(f"数据库初始化失败: {e}")


# 确保数据库初始化
init_database()


# ======================== 数据增删改查 ========================
def insert_course(name, place, time, week, teacher, day, term):
    """插入新课程"""
    try:
        conn = get_db_connection()
        if conn is None:
            return False

        cursor = conn.cursor()
        cursor.execute('''
                       INSERT INTO courses (name, place, time, week, teacher, day, term)
                       VALUES (?, ?, ?, ?, ?, ?, ?)
                       ''', (name, place, time, week, teacher, day, term))

        conn.commit()
        logging.info(f"成功插入课程: {name}")
        return True
    except Exception as e:
        logging.error(f"插入课程失败: {e}\n{traceback.format_exc()}")
        return False
    finally:
        if conn:
            conn.close()


def get_all_courses():
    """获取所有课程"""
    try:
        conn = get_db_connection()
        if conn is None:
            return []

        cursor = conn.cursor()
        cursor.execute('SELECT * FROM courses')
        courses = [dict(row) for row in cursor.fetchall()]
        return courses
    except Exception as e:
        logging.error(f"获取课程失败: {e}\n{traceback.format_exc()}")
        return []
    finally:
        if conn:
            conn.close()


def get_courses_by_week(week):
    """按周获取课程"""
    try:
        conn = get_db_connection()
        if conn is None:
            return []

        cursor = conn.cursor()
        cursor.execute('SELECT * FROM courses WHERE week = ?', (week,))
        courses = [dict(row) for row in cursor.fetchall()]
        return courses
    except Exception as e:
        logging.error(f"按周获取课程失败: {e}\n{traceback.format_exc()}")
        return []
    finally:
        if conn:
            conn.close()


def update_course(course_id, **fields):
    """更新课程字段"""
    valid_fields = ['name', 'place', 'time', 'week', 'teacher', 'day', 'term']

    try:
        conn = get_db_connection()
        if conn is None:
            return False

        cursor = conn.cursor()

        # 构建更新语句
        update_fields = []
        values = []
        for field, value in fields.items():
            if field in valid_fields:
                update_fields.append(f"{field} = ?")
                values.append(value)

        if not update_fields:
            return False

        values.append(course_id)
        sql = f"UPDATE courses SET {', '.join(update_fields)} WHERE id = ?"

        cursor.execute(sql, values)
        conn.commit()
        logging.info(f"更新课程ID {course_id} 成功")
        return True
    except Exception as e:
        logging.error(f"更新课程失败: {e}\n{traceback.format_exc()}")
        return False
    finally:
        if conn:
            conn.close()


def delete_course(course_id):
    """删除课程"""
    try:
        conn = get_db_connection()
        if conn is None:
            return False

        cursor = conn.cursor()
        cursor.execute('DELETE FROM courses WHERE id = ?', (course_id,))
        conn.commit()
        logging.info(f"删除课程ID: {course_id}")
        return cursor.rowcount > 0
    except Exception as e:
        logging.error(f"删除课程失败: {e}\n{traceback.format_exc()}")
        return False
    finally:
        if conn:
            conn.close()


def delete_all_courses():
    """删除所有课程"""
    try:
        conn = get_db_connection()
        if conn is None:
            return False

        cursor = conn.cursor()
        cursor.execute('DELETE FROM courses')
        conn.commit()
        logging.info("删除所有课程成功")
        return True
    except Exception as e:
        logging.error(f"删除所有课程失败: {e}\n{traceback.format_exc()}")
        return False
    finally:
        if conn:
            conn.close()


def get_course_by_id(course_id):
    """按ID获取课程"""
    try:
        conn = get_db_connection()
        if conn is None:
            return None

        cursor = conn.cursor()
        cursor.execute('SELECT * FROM courses WHERE id = ?', (course_id,))
        course = cursor.fetchone()
        return dict(course) if course else None
    except Exception as e:
        logging.error(f"按ID获取课程失败: {e}\n{traceback.format_exc()}")
        return None
    finally:
        if conn:
            conn.close()