from datetime import datetime, timedelta
from apscheduler.schedulers.background import BackgroundScheduler
import time
import pymysql

# 数据库配置
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'password',
    'database': 'smart timetable',
    'charset': 'utf8mb4'
}

# 节次→开始时间映射（确保包含所有可能的节次）
SECTION_TIME_MAP = {
    "第1节": (8, 0),
    "第2节": (8, 50),
    "第3节": (9, 50),
    "第4节": (10, 40),
    "第5节": (11, 30),
    "第6节": (13, 30),
    "第7节": (14, 20),
    "第8节": (15, 20),
    "第9节": (16, 10),
    "第10节": (18, 30),
    "第11节": (19, 20),  # 新增第11节
    "第12节": (20, 10),  # 新增第12节
    "第13节": (21, 0),
}


def is_leap_year(year):
    """判断是否为闰年"""
    return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)


def get_days_in_month(year, month):
    """获取某个月的天数"""
    if month == 2:
        return 29 if is_leap_year(year) else 28
    elif month in [4, 6, 9, 11]:
        return 30
    else:
        return 31


def query_by_id_and_table(table_name, record_id):
    """根据表名和记录ID查询数据"""
    try:
        conn = pymysql.connect(**DB_CONFIG)
        cursor = conn.cursor()
        sql = f"""
        SELECT id, place, time, week, teacher, day, term 
        FROM `{table_name}`  
        WHERE id = %s
        """
        cursor.execute(sql, (record_id,))
        result = cursor.fetchone()
        cursor.close()
        conn.close()
        return result
    except pymysql.MySQLError as e:
        print(f"数据库查询失败: {e}")
        return None


def parse_section(section_str):
    """解析节次字符串，如 "11-12节" 提取出 "第11节" """
    first_section = section_str.split('-')[0].strip()
    # 处理数字节次（如"11"转"第11节"）
    if first_section.isdigit():
        return f"第{first_section}节"
    return f"第{first_section}节"


def clock(table_name, record_id):
    """获取课程的时间信息并整理成列表返回"""
    result = query_by_id_and_table(table_name, record_id)
    if not result:
        print(f"查询 {table_name} 表 ID:{record_id} 失败")
        return None

    # 关键修正：从time字段获取节次（原代码错误使用了place字段）
    _, place, section_str, _, _, day_offset, term = result

    try:
        first_section = parse_section(section_str)

        # 解析学期基准日期
        base_year, base_month, base_day = map(int, term.split('-'))
        base_date = datetime(base_year, base_month, base_day)

        # 计算最终日期
        new_date = base_date + timedelta(days=int(day_offset))

        # 检查节次是否在映射表中
        if first_section not in SECTION_TIME_MAP:
            raise ValueError(f"未知节次: {first_section}，请检查SECTION_TIME_MAP")

        hour, minute = SECTION_TIME_MAP[first_section]
        timetable = [new_date.year, new_date.month, new_date.day, hour, minute]
        print(f"课程 {place} 的开始时间: {datetime(*timetable)}")
        return timetable
    except (ValueError, KeyError, IndexError) as e:
        print(f"处理课程时间信息失败: {e}")
        return None


def calculate_before_start_time(clock_result, x):
    """计算课程开始前x分钟的时间"""
    if not clock_result or len(clock_result) != 5:
        raise ValueError("时间格式错误")
    year, month, day, hour, minute = clock_result
    start = datetime(year, month, day, hour, minute)
    before = start - timedelta(minutes=x)
    return [before.year, before.month, before.day, before.hour, before.minute]


def clock_start_remind(year, month, day, hour, minute, course_name, minutes_before):
    """设置提醒任务"""

    def job():
        print(f"提醒：{course_name} 将在 {minutes_before} 分钟后开始")

    scheduler = BackgroundScheduler()
    run_time = datetime(year, month, day, hour, minute)

    if run_time < datetime.now():
        print(f"警告：{run_time} 已过期，提醒无效")
        return

    scheduler.add_job(job, 'date', run_date=run_time, misfire_grace_time=60)
    scheduler.start()
    print(f"已设置提醒：{run_time.strftime('%Y-%m-%d %H:%M')} 提醒 {course_name}")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        scheduler.shutdown()
        print("\n程序停止")


def warning(table_name, record_id, advance_minutes):
    """对外提醒接口"""
    time_info = clock(table_name, record_id)
    if not time_info:
        return

    try:
        before_time = calculate_before_start_time(time_info, advance_minutes)
    except ValueError as e:
        print(f"计算提醒时间失败: {e}")
        return

    # 从数据库获取课程名称（假设place字段为课程名称）
    course_info = query_by_id_and_table(table_name, record_id)
    course_name = course_info[1] if course_info else f"课程ID_{record_id}"

    clock_start_remind(*before_time, course_name, advance_minutes)


if __name__ == "__main__":
    # 示例调用（表名、ID、提前分钟数）
    warning("数学", 1, 10)