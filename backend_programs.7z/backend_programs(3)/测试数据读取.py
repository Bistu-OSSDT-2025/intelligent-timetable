#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
测试数据读取功能
"""

def test_data_reading():
    print("=== 测试课表数据读取功能 ===\n")
    
    try:
        # 导入必要的模块
        from mysqlconnect import get_all_table_names, get_db_connection
        import pymysql.cursors
        
        print("1. 测试数据库连接...")
        conn = get_db_connection()
        if conn:
            print("✓ 数据库连接成功")
            conn.close()
        else:
            print("✗ 数据库连接失败")
            return False
        
        print("\n2. 测试获取表名...")
        tables = get_all_table_names()
        print(f"✓ 找到 {len(tables)} 个课程表: {tables}")
        
        if not tables:
            print("⚠ 数据库中没有课程表")
            return True
        
        print("\n3. 测试查询所有课程数据...")
        
        def query_all_courses_from_table(table_name):
            """查询指定表中的所有课程"""
            try:
                connection = get_db_connection()
                if connection is None:
                    return []
                    
                cursor = connection.cursor(pymysql.cursors.DictCursor)
                cursor.execute(f"SELECT * FROM `{table_name}`")
                courses = cursor.fetchall()
                cursor.close()
                connection.close()
                
                return courses if courses else []
                
            except Exception as e:
                print(f"查询表 {table_name} 失败: {str(e)}")
                return []
        
        total_courses = 0
        for table_name in tables:
            print(f"\n  测试表: {table_name}")
            courses = query_all_courses_from_table(table_name)
            print(f"  ✓ 查询到 {len(courses)} 条课程记录")
            
            if courses:
                # 显示第一条记录的详细信息
                first_course = courses[0]
                print(f"    示例课程: {first_course}")
            
            total_courses += len(courses)
        
        print(f"\n✅ 测试完成！总共查询到 {total_courses} 门课程")
        
        # 测试按周次筛选
        print("\n4. 测试周次筛选...")
        current_week = 1
        filtered_courses = 0
        
        for table_name in tables:
            courses = query_all_courses_from_table(table_name)
            for course in courses:
                if course['week'] == current_week:
                    filtered_courses += 1
        
        print(f"✓ 第{current_week}周有 {filtered_courses} 门课程")
        
        return True
        
    except Exception as e:
        print(f"❌ 测试失败: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_data_reading()
    if success:
        print("\n🎉 数据读取功能正常！")
    else:
        print("\n💥 数据读取功能有问题，需要进一步检查。")
    
    input("\n按回车键退出...") 