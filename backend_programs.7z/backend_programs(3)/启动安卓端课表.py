#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
智能课表 - 安卓版启动器
自动检查依赖并启动安卓端程序
"""

import os
import sys
import subprocess
import importlib.util

def print_banner():
    """显示启动横幅"""
    print("=" * 50)
    print("           智能课表 - 安卓版启动器")
    print("=" * 50)
    print()

def check_python_version():
    """检查Python版本"""
    if sys.version_info < (3, 7):
        print("[错误] 需要Python 3.7或更高版本")
        print(f"[错误] 当前版本: {sys.version}")
        return False
    
    print(f"[信息] Python版本: {sys.version.split()[0]}")
    return True

def check_package(package_name):
    """检查包是否已安装"""
    spec = importlib.util.find_spec(package_name)
    return spec is not None

def install_package(package_name):
    """安装包"""
    try:
        print(f"[安装] 正在安装 {package_name}...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", package_name])
        print(f"[成功] {package_name} 安装完成")
        return True
    except subprocess.CalledProcessError:
        print(f"[错误] {package_name} 安装失败")
        return False

def check_and_install_dependencies():
    """检查并安装依赖"""
    print("[检查] 正在检查必要的依赖包...")
    
    dependencies = [
        ("kivy", "Kivy框架"),
        ("plyer", "通知支持"),
        ("pymysql", "数据库连接")
    ]
    
    for package, description in dependencies:
        if not check_package(package):
            print(f"[缺失] {description} ({package})")
            if not install_package(package):
                return False
        else:
            print(f"[已安装] {description}")
    
    return True

def check_files():
    """检查必要的文件"""
    print("\n[检查] 正在检查程序文件...")
    
    # 检查数据库连接文件
    if not os.path.exists("mysqlconnect.py"):
        print("[警告] 未找到数据库连接文件 mysqlconnect.py")
        print("[警告] 将使用演示数据运行")
    else:
        print("[找到] 数据库连接文件")
    
    # 检查安卓端程序文件
    if not os.path.exists("anzhuo_database.py"):
        print("[错误] 未找到安卓端程序文件 anzhuo_database.py")
        return False
    else:
        print("[找到] 安卓端程序文件")
    
    return True

def launch_app():
    """启动应用"""
    print("\n[启动] 正在启动智能课表安卓版...")
    print("=" * 50)
    print("           程序运行中...")
    print("           按Ctrl+C退出程序")
    print("=" * 50)
    print()
    
    try:
        # 导入并运行安卓端程序
        import anzhuo_database
        # 程序运行完成
        print("\n[信息] 程序已退出")
    except KeyboardInterrupt:
        print("\n[信息] 用户中断程序")
    except Exception as e:
        print(f"\n[错误] 程序运行失败: {e}")
        import traceback
        traceback.print_exc()

def main():
    """主函数"""
    print_banner()
    
    # 检查Python版本
    if not check_python_version():
        input("按Enter键退出...")
        return
    
    # 检查并安装依赖
    if not check_and_install_dependencies():
        print("\n[错误] 依赖安装失败，无法继续")
        input("按Enter键退出...")
        return
    
    # 检查文件
    if not check_files():
        print("\n[错误] 必要文件缺失，无法继续")
        input("按Enter键退出...")
        return
    
    print("\n[信息] 所有检查完成，准备启动程序")
    print()
    
    # 启动应用
    launch_app()
    
    input("\n按Enter键退出...")

if __name__ == "__main__":
    main() 