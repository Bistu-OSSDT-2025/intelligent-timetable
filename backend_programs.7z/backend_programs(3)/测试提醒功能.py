#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
测试智能提醒功能
"""

import os
import sys
from datetime import datetime, timedelta

def test_reminder_system():
    """测试智能提醒系统"""
    print("=== 智能提醒功能测试 ===\n")
    
    try:
        # 导入主程序
        from 智能课表 import SmartTimetableApp
        
        print("1. 初始化提醒系统...")
        app = SmartTimetableApp()
        
        # 检查提醒系统是否已初始化
        if hasattr(app, 'reminder_enabled'):
            print(f"✓ 提醒系统状态: {'启用' if app.reminder_enabled else '关闭'}")
            print(f"✓ 提前时间: {getattr(app, 'reminder_advance_minutes', '未设置')} 分钟")
        else:
            print("⚠ 提醒系统未初始化")
            return False
        
        print("\n2. 测试系统通知功能...")
        
        # 测试通知
        test_title = "📚 测试通知"
        test_message = "这是一个测试通知\n用于验证提醒功能是否正常工作"
        
        app.show_system_notification(test_title, test_message)
        print("✓ 已发送测试通知（请检查系统通知区域）")
        
        print("\n3. 检查节次时间映射...")
        if hasattr(app, 'section_time_map'):
            print("✓ 节次时间映射已配置")
            for section, (hour, minute) in list(app.section_time_map.items())[:5]:
                print(f"  {section}: {hour:02d}:{minute:02d}")
            print(f"  ... （共{len(app.section_time_map)}个节次）")
        else:
            print("✗ 节次时间映射未配置")
            return False
        
        print("\n4. 测试时间计算功能...")
        today = datetime.now().date()
        test_section = "第1节"
        course_time = app.get_course_start_time(today, test_section)
        
        if course_time:
            print(f"✓ 时间计算正常: {test_section} 开始时间 {course_time.strftime('%H:%M')}")
        else:
            print("✗ 时间计算失败")
            return False
        
        print("\n5. 检查当前课程数据...")
        try:
            from mysqlconnect import get_all_table_names
            tables = get_all_table_names()
            
            if tables:
                print(f"✓ 找到 {len(tables)} 个课程表")
                
                # 检查当前周的课程
                current_week = app.current_week.get()
                current_weekday = datetime.now().weekday()
                
                if current_weekday < 5:  # 工作日
                    today_courses = 0
                    for table_name in tables:
                        courses = app.query_all_courses_from_table(table_name)
                        for course in courses:
                            if (course['week'] == current_week and 
                                int(course['day']) == current_weekday):
                                today_courses += 1
                    
                    print(f"✓ 今天（第{current_week}周，{'周一二三四五'[current_weekday]}）有 {today_courses} 门课程")
                    
                    if today_courses > 0:
                        print("  提醒系统将在课程开始前发送通知")
                    else:
                        print("  今天没有课程，不会发送提醒")
                else:
                    print("  今天是周末，提醒系统不工作")
            else:
                print("⚠ 没有找到课程数据")
                
        except Exception as e:
            print(f"⚠ 检查课程数据时出错: {str(e)}")
        
        print("\n6. 功能测试建议...")
        print("📋 手动测试步骤:")
        print("1. 启动智能课表系统")
        print("2. 点击'⏰ 提醒'按钮打开设置")
        print("3. 确保提醒功能已启用")
        print("4. 点击'🔔 测试提醒功能'按钮")
        print("5. 检查是否收到系统通知")
        
        print("\n🔧 如果提醒不工作，请检查:")
        print("• Windows通知权限是否开启")
        print("• 系统时间是否正确")
        print("• 是否在工作日（周一至周五）")
        print("• 课程数据是否正确")
        
        return True
        
    except Exception as e:
        print(f"❌ 测试失败: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    try:
        success = test_reminder_system()
        if success:
            print("\n✅ 提醒功能测试完成！")
            print("💡 系统会在课程开始前自动发送提醒，请保持程序运行。")
        else:
            print("\n❌ 提醒功能测试失败，请检查错误信息。")
    except KeyboardInterrupt:
        print("\n⚠ 测试被用户中断")
    except Exception as e:
        print(f"\n💥 测试过程中出现异常: {str(e)}")
    
    input("\n按回车键退出...") 