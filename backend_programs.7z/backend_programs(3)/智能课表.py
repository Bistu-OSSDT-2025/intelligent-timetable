# 智能课表.py
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import os
import csv
import re
import openpyxl
import app_pandes  # 确保这个模块存在
from datetime import datetime, timedelta
import logging
import threading
import time
import json
from tkcalendar import DateEntry  # 确保已安装tkcalendar包

# 尝试导入数据库相关模块
try:
    # 优先使用新的API模块
    from course_api import course_api
    DB_AVAILABLE = True
    
    # 兼容性函数
    def get_db_connection():
        return course_api.get_db_connection()
    
    def insert_course(*args, **kwargs):
        if len(args) == 7:  # 兼容旧调用方式
            name, place, time, week, teacher, day, term = args
            success, message, course_id = course_api.insert_course({
                'name': name,
                'place': place,
                'time': time,
                'week': week,
                'teacher': teacher,
                'day': day,
                'term': term
            })
            return success
        else:
            return course_api.insert_course(kwargs)[0]
    
    def get_all_courses():
        return course_api.get_all_courses()
    
    def get_courses_by_week(*args, **kwargs):
        if args:
            return course_api.get_courses_by_week(args[0])
        else:
            return course_api.get_courses_by_week(kwargs.get('week', 1))
    
    def update_course(*args, **kwargs):
        if len(args) >= 3:  # 兼容旧调用方式: update_course(course_id, field, value)
            course_id, field, value = args[0], args[1], args[2]
            success, message = course_api.update_course(course_id, {field: value})
            return success
        elif len(args) == 2:  # 新调用方式: update_course(course_id, data_dict)
            course_id, data_dict = args[0], args[1]
            success, message = course_api.update_course(course_id, data_dict)
            return success
        else:
            return False
    
    def delete_course(*args, **kwargs):
        if args:
            return course_api.delete_course(args[0])[0]
        else:
            return course_api.delete_course(kwargs.get('course_id'))[0]
    
    def delete_all_courses():
        return course_api.delete_all_courses()[0]
    
    def get_course_by_id(*args, **kwargs):
        if args:
            return course_api.get_course_by_id(args[0])
        else:
            return course_api.get_course_by_id(kwargs.get('course_id'))
    
    def update_courses_by_name(original_name, updates):
        """更新同名课程的基本信息"""
        success, message, count = course_api.update_courses_by_name(original_name, updates)
        return success

except ImportError as e:
    print(f"新的API模块导入失败，尝试使用旧模块: {e}")
    try:
        # 回退到旧的sqliteconnect模块
        from sqliteconnect import (
            get_db_connection,
            insert_course,
            get_all_courses,
            get_courses_by_week,
            update_course,
            delete_course,
            delete_all_courses,
            get_course_by_id
        )
        DB_AVAILABLE = True
        
        # 为旧模块添加update_courses_by_name函数
        def update_courses_by_name(original_name, updates):
            """更新同名课程的基本信息 - 旧模块版本"""
            try:
                from sqliteconnect import get_db_connection
                conn = get_db_connection()
                if conn is None:
                    return False
                
                cursor = conn.cursor()
                allowed_fields = ['name', 'teacher', 'place']
                update_fields = {}
                
                for field, value in updates.items():
                    if field in allowed_fields:
                        update_fields[field] = value
                
                if not update_fields:
                    return False
                
                set_clause = ', '.join([f"{field} = ?" for field in update_fields.keys()])
                sql = f"UPDATE courses SET {set_clause} WHERE name = ?"
                values = list(update_fields.values()) + [original_name]
                
                cursor.execute(sql, values)
                conn.commit()
                conn.close()
                
                return True
            except Exception as e:
                print(f"更新同名课程失败: {e}")
                return False
                
    except ImportError as e2:
        print(f"所有数据库模块导入失败: {e2}")
        DB_AVAILABLE = False
        
        # 创建虚拟函数以防止后续调用出错
        def get_db_connection():
            return None
        
        def insert_course(*args, **kwargs):
            return False
        
        def get_all_courses():
            return []
        
        def get_courses_by_week(*args, **kwargs):
            return []
        
        def update_course(*args, **kwargs):
            return False
        
        def delete_course(*args, **kwargs):
            return False
        
        def delete_all_courses():
            return False
        
        def get_course_by_id(*args, **kwargs):
            return None
        
        def update_courses_by_name(original_name, updates):
            return False


# 日志记录函数
def log_message(message_type, message):
    """记录消息到日志文件"""
    try:
        log_file = os.path.join(os.path.dirname(__file__), 'debug.log')
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S")} [{message_type}]: {message}\n')
    except Exception as e:
        print(f"日志记录失败: {str(e)}")


# 状态消息框
class StatusMessageBox:
    def __init__(self, app):
        self.app = app

    def showerror(self, title, message):
        log_message("ERROR", f"{title}: {message}")
        if hasattr(self.app, 'update_status'):
            self.app.update_status(f"错误: {message}", is_error=True)
        return None

    def showinfo(self, title, message):
        log_message("INFO", f"{title}: {message}")
        if hasattr(self.app, 'update_status'):
            self.app.update_status(f"成功: {message}")
        return None

    def showwarning(self, title, message):
        log_message("WARNING", f"{title}: {message}")
        if hasattr(self.app, 'update_status'):
            self.app.update_status(f"警告: {message}")
        return None

    def askyesno(self, title, message):
        log_message("QUESTION", f"{title}: {message} (默认: 是)")
        if hasattr(self.app, 'update_status'):
            self.app.update_status(f"确认: {message}")
        return True


# 课程编辑对话框
class CourseEditDialog:
    def __init__(self, parent, course_data=None, is_new=True):
        self.parent = parent
        self.course_data = course_data
        self.is_new = is_new
        self.result = None

        self.dialog = tk.Toplevel(parent.root)
        self.dialog.title("编辑课程" if not is_new else "添加课程")
        self.dialog.geometry("400x500")
        self.dialog.transient(parent.root)
        self.dialog.grab_set()

        # 居中显示
        self.dialog.update_idletasks()
        screen_width = self.dialog.winfo_screenwidth()
        screen_height = self.dialog.winfo_screenheight()
        x = (screen_width // 2) - (400 // 2)
        y = (screen_height // 2) - (500 // 2)
        self.dialog.geometry(f"400x500+{x}+{y}")

        self.setup_ui()
        
        # 如果是新建课程且有预填充数据，则设置默认值
        if self.is_new and self.course_data:
            self.set_default_values()

    def setup_ui(self):
        main_frame = tk.Frame(self.dialog, bg="#f0f2f5")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        title_label = tk.Label(main_frame,
                               text="编辑课程信息" if not self.is_new else "添加新课程",
                               font=("微软雅黑", 16, "bold"),
                               bg="#f0f2f5", fg="#2c3e50")
        title_label.pack(pady=(0, 20))

        # 创建字段
        self.create_field(main_frame, "课程名称:", "name")
        self.create_field(main_frame, "任课教师:", "teacher")
        self.create_field(main_frame, "上课地点:", "place")

        # 星期选择
        week_frame = tk.Frame(main_frame, bg="#f0f2f5")
        week_frame.pack(fill=tk.X, pady=5)
        tk.Label(week_frame, text="星期:", font=("微软雅黑", 10),
                 bg="#f0f2f5", fg="#34495e", width=12, anchor="w").pack(side=tk.LEFT)

        self.day_var = tk.StringVar(value="星期一")
        # 显示中文星期，但存储数字
        self.weekday_display_map = {
            "星期一": "0",
            "星期二": "1", 
            "星期三": "2",
            "星期四": "3",
            "星期五": "4"
        }
        self.weekday_value_map = {v: k for k, v in self.weekday_display_map.items()}
        
        day_combo = ttk.Combobox(week_frame, textvariable=self.day_var, width=20,
                                 values=list(self.weekday_display_map.keys()),
                                 font=("微软雅黑", 10), state="readonly")
        day_combo.pack(side=tk.LEFT, padx=(10, 0))

        # 节次选择
        time_frame = tk.Frame(main_frame, bg="#f0f2f5")
        time_frame.pack(fill=tk.X, pady=5)
        tk.Label(time_frame, text="上课时间:", font=("微软雅黑", 10),
                 bg="#f0f2f5", fg="#34495e", width=12, anchor="w").pack(side=tk.LEFT)

        self.time_var = tk.StringVar(value="第1节")
        time_values = [f"第{i}节" for i in range(1, 14)]
        time_values.extend(["1-2节", "3-4节", "5-6节", "7-8节", "9-10节", "11-12节"])
        time_combo = ttk.Combobox(time_frame, textvariable=self.time_var, width=20,
                                  values=time_values,
                                  font=("微软雅黑", 10), state="readonly")
        time_combo.pack(side=tk.LEFT, padx=(10, 0))

        # 其他字段
        self.create_field(main_frame, "上课周次:", "week")
        
        # 学期字段 - 自动设置且不可编辑
        term_frame = tk.Frame(main_frame, bg="#f0f2f5")
        term_frame.pack(fill=tk.X, pady=5)
        tk.Label(term_frame, text="学期:", font=("微软雅黑", 10),
                 bg="#f0f2f5", fg="#34495e", width=12, anchor="w").pack(side=tk.LEFT)
        
        # 自动生成学期名称
        current_year = datetime.now().year
        if datetime.now().month >= 9:
            term_name = f"{current_year}-{current_year+1}学年第一学期"
        else:
            term_name = f"{current_year-1}-{current_year}学年第二学期"
        
        self.term_var = tk.StringVar(value=term_name)
        term_label = tk.Label(term_frame, textvariable=self.term_var,
                              font=("微软雅黑", 10), bg="#ecf0f1", fg="#7f8c8d",
                              relief=tk.SUNKEN, bd=1, width=25, anchor="w")
        term_label.pack(side=tk.LEFT, padx=(10, 0))
        
        # 更新同名课程选项（仅编辑模式显示）
        if not self.is_new:
            update_frame = tk.Frame(main_frame, bg="#f0f2f5")
            update_frame.pack(fill=tk.X, pady=10)
            
            self.update_same_name_var = tk.BooleanVar(value=False)
            update_check = tk.Checkbutton(update_frame, 
                                          text="同时更新所有同名课程的基本信息（课程名称、教师、地点）",
                                          variable=self.update_same_name_var,
                                          font=("微软雅黑", 9),
                                          bg="#f0f2f5", fg="#34495e",
                                          selectcolor="#3498db")
            update_check.pack(anchor="w")
            
            # 提示信息
            tip_label = tk.Label(update_frame, 
                                 text="注意：时间相关信息（星期、节次、周次）不会更改",
                                 font=("微软雅黑", 8),
                                 bg="#f0f2f5", fg="#e74c3c")
            tip_label.pack(anchor="w", padx=(20, 0))

        # 按钮区域
        button_frame = tk.Frame(main_frame, bg="#f0f2f5")
        button_frame.pack(fill=tk.X, pady=(30, 0))

        save_btn = tk.Button(button_frame, text="保存",
                             command=self.save_course,
                             font=("微软雅黑", 12, "bold"),
                             bg="#3498db", fg="white",
                             relief=tk.FLAT, padx=20, pady=8)
        save_btn.pack(side=tk.LEFT, padx=(0, 10))

        if not self.is_new:
            delete_btn = tk.Button(button_frame, text="删除",
                                   command=self.delete_course,
                                   font=("微软雅黑", 12, "bold"),
                                   bg="#e74c3c", fg="white",
                                   relief=tk.FLAT, padx=20, pady=8)
            delete_btn.pack(side=tk.LEFT, padx=(0, 10))

        cancel_btn = tk.Button(button_frame, text="取消",
                               command=self.dialog.destroy,
                               font=("微软雅黑", 12),
                               bg="#95a5a6", fg="white",
                               relief=tk.FLAT, padx=20, pady=8)
        cancel_btn.pack(side=tk.RIGHT)

        # 填充数据
        if not self.is_new and self.course_data:
            self.load_course_data()

    def set_default_values(self):
        """设置新建课程时的默认值"""
        try:
            if self.course_data:
                # 设置星期
                if hasattr(self, 'day_var') and self.day_var:
                    day_num = str(self.course_data.get('day', '0'))
                    day_display = self.weekday_value_map.get(day_num, "星期一")
                    self.day_var.set(day_display)
                
                # 设置上课时间
                if hasattr(self, 'time_var') and self.time_var:
                    self.time_var.set(self.course_data.get('time', '第1节'))
                
                # 设置周次
                if hasattr(self, 'week_entry') and self.week_entry:
                    self.week_entry.insert(0, str(self.course_data.get('week', '1')))
        except Exception as e:
            print(f"设置默认值时出错: {str(e)}")

    def update_same_name_courses(self, new_name, new_teacher, new_place):
        """更新所有同名课程的基本信息"""
        try:
            if not DB_AVAILABLE:
                return False
                
            # 获取当前课程名称
            original_name = self.course_data.get('name', '')
            if not original_name:
                return False
                
            # 获取所有同名课程
            all_courses = get_all_courses()
            updated_count = 0
            
            for course in all_courses:
                if course['name'] == original_name:
                    # 只更新基本信息，不更新时间相关信息
                    success = True
                    success &= update_course(course['id'], 'name', new_name)
                    success &= update_course(course['id'], 'teacher', new_teacher)
                    success &= update_course(course['id'], 'place', new_place)
                    
                    if success:
                        updated_count += 1
                    else:
                        log_message("ERROR", f"更新同名课程失败: {course['id']}")
            
            log_message("INFO", f"更新了 {updated_count} 门同名课程")
            return updated_count > 0
            
        except Exception as e:
            log_message("ERROR", f"更新同名课程时出错: {str(e)}")
            return False

    def create_field(self, parent, label_text, field_name):
        frame = tk.Frame(parent, bg="#f0f2f5")
        frame.pack(fill=tk.X, pady=5)

        label = tk.Label(frame, text=label_text, font=("微软雅黑", 10),
                         bg="#f0f2f5", fg="#34495e", width=12, anchor="w")
        label.pack(side=tk.LEFT)

        entry = tk.Entry(frame, font=("微软雅黑", 10), width=25)
        entry.pack(side=tk.LEFT, padx=(10, 0))
        setattr(self, f"{field_name}_entry", entry)

    def load_course_data(self):
        if self.course_data:
            try:
                if hasattr(self, 'name_entry') and self.name_entry:
                    self.name_entry.insert(0, self.course_data.get('name', ''))
                if hasattr(self, 'teacher_entry') and self.teacher_entry:
                    self.teacher_entry.insert(0, self.course_data.get('teacher', ''))
                if hasattr(self, 'place_entry') and self.place_entry:
                    self.place_entry.insert(0, self.course_data.get('place', ''))
                if hasattr(self, 'day_var') and self.day_var:
                    day_num = str(self.course_data.get('day', '0'))
                    day_display = self.weekday_value_map.get(day_num, "星期一")
                    self.day_var.set(day_display)
                if hasattr(self, 'time_var') and self.time_var:
                    self.time_var.set(self.course_data.get('time', '第1节'))
                if hasattr(self, 'week_entry') and self.week_entry:
                    self.week_entry.insert(0, str(self.course_data.get('week', '1')))
                # 学期字段现在使用term_var，自动设置
            except Exception as e:
                print(f"加载课程数据时出错: {str(e)}")

    def save_course(self):
        try:
            # 获取表单数据
            name_val = self.name_entry.get().strip()
            teacher_val = self.teacher_entry.get().strip()
            place_val = self.place_entry.get().strip()
            day_display = self.day_var.get()
            day = self.weekday_display_map.get(day_display, "0")  # 转换为数字
            time = self.time_var.get()
            week = self.week_entry.get().strip()
            term = self.term_var.get()  # 使用自动设置的学期

            # 验证必填字段
            if not all([name_val, teacher_val, place_val, day, time, week, term]):
                self.parent.messagebox.showerror("错误", "请填写所有字段！")
                return

            if not DB_AVAILABLE:
                self.parent.messagebox.showerror("错误", "数据库模块不可用！")
                return

            if self.is_new:
                # 新增课程
                if insert_course(name_val, place_val, time, int(week), teacher_val, day, term):
                    self.parent.messagebox.showinfo("成功", "课程添加成功！")
                    self.result = 'success'
                    self.dialog.destroy()
                else:
                    self.parent.messagebox.showerror("错误", "添加课程失败！")
            else:
                # 更新课程
                if self.course_data and 'id' in self.course_data:
                    course_id = self.course_data['id']
                    
                    # 检查是否需要更新同名课程
                    if hasattr(self, 'update_same_name_var') and self.update_same_name_var.get():
                        # 更新同名课程的基本信息
                        success = self.update_same_name_courses(name_val, teacher_val, place_val)
                        if success:
                            # 同时更新当前课程的所有信息 - 使用新的API调用方式
                            update_data = {
                                'name': name_val,
                                'teacher': teacher_val,
                                'place': place_val,
                                'day': day,
                                'time': time,
                                'week': week,
                                'term': term
                            }
                            if update_course(course_id, update_data):
                                self.parent.messagebox.showinfo("成功", "课程及同名课程更新成功！")
                                self.result = 'success'
                                self.dialog.destroy()
                            else:
                                self.parent.messagebox.showerror("错误", "更新课程失败！")
                        else:
                            self.parent.messagebox.showerror("错误", "更新同名课程失败！")
                    else:
                        # 只更新当前课程 - 使用新的API调用方式
                        update_data = {
                            'name': name_val,
                            'teacher': teacher_val,
                            'place': place_val,
                            'day': day,
                            'time': time,
                            'week': week,
                            'term': term
                        }
                        if update_course(course_id, update_data):
                            self.parent.messagebox.showinfo("成功", "课程更新成功！")
                            self.result = 'success'
                            self.dialog.destroy()
                        else:
                            self.parent.messagebox.showerror("错误", "更新课程失败！")
                else:
                    self.parent.messagebox.showerror("错误", "课程数据无效！")

        except Exception as e:
            import traceback
            error_msg = f"保存失败：{str(e)}\n{traceback.format_exc()}"
            print(error_msg)  # 打印到控制台以便调试
            self.parent.messagebox.showerror("错误", f"保存失败：{str(e)}")

    def delete_course(self):
        if self.parent.messagebox.askyesno("确认删除", "确定要删除这门课程吗？"):
            try:
                if not DB_AVAILABLE:
                    self.parent.messagebox.showerror("错误", "数据库模块不可用！")
                    return

                course_id = self.course_data['id']
                if delete_course(course_id):
                    self.parent.messagebox.showinfo("成功", "课程删除成功！")
                    self.result = 'success'
                    self.dialog.destroy()
                else:
                    self.parent.messagebox.showerror("错误", "删除课程失败！")
            except Exception as e:
                self.parent.messagebox.showerror("错误", f"删除失败：{str(e)}")


# 主应用
class SmartTimetableApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("智能课表系统 v6.0 - 增强提醒版")
        self.root.geometry("1200x800")
        self.root.configure(bg="#f0f2f5")

        self.messagebox = StatusMessageBox(self)

        # 周数变量
        self.current_week = tk.IntVar(value=1)

        # 课程表网格
        self.course_grid = [[None for _ in range(5)] for _ in range(13)]
        self.course_buttons = []

        # 节次时间映射
        self.section_time_map = {
            "第1节": (8, 0), "第2节": (8, 50), "第3节": (9, 50),
            "第4节": (10, 40), "第5节": (11, 30), "第6节": (13, 30),
            "第7节": (14, 20), "第8节": (15, 20), "第9节": (16, 10),
            "第10节": (18, 30), "第11节": (19, 20), "第12节": (20, 10),
            "第13节": (21, 0),
            "1-2节": (8, 0), "3-4节": (10, 40), "5-6节": (13, 30),
            "7-8节": (15, 20), "9-10节": (18, 30), "11-12节": (20, 10)
        }

        # 提醒线程控制
        self.reminder_active = True
        self.reminded_courses = set()

        # 状态栏
        self.status_var = tk.StringVar(value="系统就绪")

        # 学期开始日期
        self.term_start_date = None
        self.load_term_settings()

        # 提醒提前时间（分钟）
        self.remind_minutes = 10

        # 设置UI
        self.setup_ui()

        # 加载课程数据
        self.load_courses()

        # 启动提醒线程
        self.start_reminder_thread()

        log_message("INFO", "智能课表系统启动")
        self.update_status("智能课表系统启动成功")

    def load_term_settings(self):
        """加载学期设置"""
        try:
            config_file = os.path.join(os.path.dirname(__file__), 'term_settings.json')
            if os.path.exists(config_file):
                with open(config_file, 'r', encoding='utf-8') as f:
                    settings = json.load(f)
                    self.term_start_date = datetime.strptime(settings['term_start'], "%Y-%m-%d").date()
                    self.remind_minutes = settings.get('remind_minutes', 10)
                    log_message("INFO",
                                f"加载学期设置: 开始日期={self.term_start_date}, 提前提醒={self.remind_minutes}分钟")
            else:
                # 默认设置：当前学期的9月1日
                self.term_start_date = datetime(datetime.now().year, 9, 1).date()
                self.remind_minutes = 10
                log_message("INFO", "使用默认学期设置")
        except Exception as e:
            log_message("ERROR", f"加载学期设置失败: {str(e)}")
            # 出错时使用默认值
            self.term_start_date = datetime(datetime.now().year, 9, 1).date()
            self.remind_minutes = 10

    def save_term_settings(self):
        """保存学期设置"""
        try:
            config_file = os.path.join(os.path.dirname(__file__), 'term_settings.json')
            settings = {
                'term_start': self.term_start_date.strftime("%Y-%m-%d"),
                'remind_minutes': self.remind_minutes
            }
            with open(config_file, 'w', encoding='utf-8') as f:
                json.dump(settings, f)
            log_message("INFO", "学期设置已保存")
        except Exception as e:
            log_message("ERROR", f"保存学期设置失败: {str(e)}")

    def start_reminder_thread(self):
        """启动提醒线程"""
        self.reminder_thread = threading.Thread(target=self.reminder_worker, daemon=True)
        self.reminder_thread.start()
        log_message("INFO", "课程提醒线程已启动")

    def stop_reminder_thread(self):
        """停止提醒线程"""
        self.reminder_active = False
        log_message("INFO", "课程提醒线程已停止")

    def reminder_worker(self):
        """提醒线程的工作函数"""
        while self.reminder_active:
            try:
                now = datetime.now()
                current_weekday = now.weekday()  # 0=周一, 1=周二, ... 6=周日

                # 只检查周一到周五 (0-4)
                if current_weekday < 5:
                    # 获取当前周当前星期的所有课程
                    courses = get_courses_by_week(self.current_week.get())

                    for course in courses:
                        # 检查课程是否在今天
                        if int(course['day']) != current_weekday:
                            continue

                        # 解析课程时间
                        time_str = course['time']
                        if time_str not in self.section_time_map:
                            continue

                        course_time = self.section_time_map[time_str]
                        course_datetime = datetime(now.year, now.month, now.day, course_time[0], course_time[1])

                        # 计算提前提醒的时间
                        remind_time = course_datetime - timedelta(minutes=self.remind_minutes)

                        # 生成唯一标识符
                        course_id = f"{course['id']}_{course_datetime.date()}_{time_str}"

                        # 检查是否需要提醒
                        if now >= remind_time and now < course_datetime and course_id not in self.reminded_courses:
                            self.show_system_notification("课程提醒",
                                                          f"即将开始: {course['name']}\n"
                                                          f"时间: {time_str}\n"
                                                          f"地点: {course['place']}\n"
                                                          f"教师: {course['teacher']}")
                            self.reminded_courses.add(course_id)
                            log_message("REMINDER",
                                        f"提醒课程: {course['name']}, 时间: {time_str}, 地点: {course['place']}")
            except Exception as e:
                log_message("ERROR", f"提醒线程错误: {str(e)}")

            # 每分钟检查一次
            time.sleep(60)

    def update_status(self, message, is_error=False, duration=3000):
        self.status_var.set(message)
        if is_error:
            self.status_label.config(fg="red")
        else:
            self.status_label.config(fg="green")

        if duration > 0:
            self.root.after(duration, lambda: self.status_var.set("系统就绪"))

    def setup_ui(self):
        style = ttk.Style()
        style.theme_use('clam')

        # 顶部控制面板
        control_frame = tk.Frame(self.root, bg="#4a6baf", height=70)
        control_frame.pack(fill=tk.X, padx=0, pady=0)
        control_frame.pack_propagate(False)

        title_label = tk.Label(control_frame,
                               text="智能课表系统 v6.0 - 增强提醒版",
                               font=("微软雅黑", 20, 'bold'),
                               bg="#4a6baf", fg="#FFFFFF")
        title_label.pack(side=tk.LEFT, padx=25, pady=10)

        right_frame = tk.Frame(control_frame, bg="#4a6baf")
        right_frame.pack(side=tk.RIGHT, padx=25, pady=10)

        # 控制按钮
        buttons = [
            ("导入课表", self.import_file, "#f39c12"),
            ("提醒设置", self.open_reminder_settings, "#9b59b6"),
            ("提醒列表", self.show_reminder_list, "#1abc9c"),  # 新增提醒列表按钮
            ("删除所有", self.delete_all_courses, "#e74c3c"),
            ("添加课程", self.add_course, "#27ae60"),
            ("刷新", self.load_courses, "#3498db")
        ]

        for text, command, color in buttons:
            btn = tk.Button(right_frame, text=text, command=command,
                            font=("微软雅黑", 10, "bold"), bg=color, fg="white",
                            relief=tk.FLAT, padx=10, pady=5)
            btn.pack(side=tk.RIGHT, padx=5)

        # 周数控制
        week_frame = tk.Frame(right_frame, bg="#4a6baf")
        week_frame.pack(side=tk.RIGHT, padx=(0, 20))

        prev_btn = tk.Button(week_frame, text="◀", command=self.prev_week,
                             font=("微软雅黑", 10, "bold"), bg="#34495e", fg="white",
                             relief=tk.FLAT, width=3)
        prev_btn.pack(side=tk.LEFT)

        self.week_label = tk.Label(week_frame, text=f"第 {self.current_week.get()} 周",
                                   font=("微软雅黑", 12, 'bold'),
                                   bg="#4a6baf", fg="#FFFFFF", width=8)
        self.week_label.pack(side=tk.LEFT, padx=5)

        next_btn = tk.Button(week_frame, text="▶", command=self.next_week,
                             font=("微软雅黑", 10, "bold"), bg="#34495e", fg="white",
                             relief=tk.FLAT, width=3)
        next_btn.pack(side=tk.LEFT)

        # 主内容区域
        main_container = tk.Frame(self.root, bg="#f0f2f5")
        main_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # 课表网格
        timetable_frame = tk.Frame(main_container, bg="#f0f2f5")
        timetable_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        self.create_timetable_grid(timetable_frame)

        # 状态栏
        status_frame = tk.Frame(main_container, bg="#ecf0f1", relief=tk.SUNKEN, bd=1)
        status_frame.pack(fill=tk.X)

        self.status_label = tk.Label(status_frame, textvariable=self.status_var,
                                     font=("微软雅黑", 10),
                                     bg="#ecf0f1", fg="black", anchor="w")
        self.status_label.pack(side=tk.LEFT, padx=10, pady=5)

    def create_timetable_grid(self, parent):
        # 使用统一的网格布局 - 整个表格使用同一个容器
        table_frame = tk.Frame(parent, bg="#f0f2f5")
        table_frame.pack(fill=tk.BOTH, expand=True)

        # 配置表格的列权重 - 确保所有列等宽
        for i in range(6):  # 6列（1个节次标签+5个星期）
            table_frame.grid_columnconfigure(i, weight=1, uniform="columns")

        # 配置表格的行权重
        for i in range(14):  # 14行（1个表头+13节课）
            table_frame.grid_rowconfigure(i, weight=1)

        # 表头部分 - 第0行
        # 左上角
        corner = tk.Label(table_frame, text="节次\\星期",
                          font=("微软雅黑", 10, "bold"),
                          bg="#34495e", fg="white",
                          relief=tk.RAISED, bd=1, height=2)
        corner.grid(row=0, column=0, sticky="nsew", padx=1, pady=1)

        # 星期标题
        weekdays = ["一", "二", "三", "四", "五"]
        for col, day in enumerate(weekdays, 1):
            day_label = tk.Label(table_frame, text=f"星期{day}",
                                 font=("微软雅黑", 10, "bold"),
                                 bg="#3498db", fg="white",
                                 relief=tk.RAISED, bd=1, height=2)
            day_label.grid(row=0, column=col, sticky="nsew", padx=1, pady=1)

        # 课程表主体 - 第1-13行
        for row in range(13):  # 13节课
            button_row = []

            # 节次标签
            section_label = tk.Label(table_frame, text=f"第{row + 1}节",
                                     font=("微软雅黑", 9),
                                     bg="#34495e", fg="white",
                                     relief=tk.RAISED, bd=1, height=2)
            section_label.grid(row=row + 1, column=0, sticky="nsew", padx=1, pady=1)

            # 课程按钮
            for col in range(5):  # 5天
                btn = tk.Button(table_frame, text="",
                                font=("微软雅黑", 8),
                                bg="#ecf0f1", fg="#2c3e50",
                                relief=tk.RAISED, bd=1,
                                wraplength=120,
                                justify=tk.CENTER,
                                command=lambda r=row, c=col: self.edit_course_cell(r, c))
                btn.grid(row=row + 1, column=col + 1, sticky="nsew", padx=1, pady=1)
                button_row.append(btn)

            self.course_buttons.append(button_row)

    # =================== 核心功能方法 ===================
    def load_courses(self):
        try:
            if not DB_AVAILABLE:
                self.update_status("数据库功能不可用 - 使用示例数据", is_error=True)
                # 加载示例数据
                self.load_sample_data()
                return

            self.update_status("正在加载课程数据...")

            # 清空当前课程网格
            for row in range(13):
                for col in range(5):
                    self.course_grid[row][col] = None
                    self.course_buttons[row][col].config(text="", bg="#ecf0f1")

            # 获取当前周的所有课程
            courses = get_courses_by_week(self.current_week.get())

            if not courses:
                self.update_status("本周没有课程")
                return

            loaded_count = 0
            for course in courses:
                self.add_course_to_grid(course)
                loaded_count += 1

            self.update_status(f"成功加载 {loaded_count} 门课程")
            log_message("INFO", f"课程加载完成，共 {loaded_count} 门课程")

        except Exception as e:
            error_msg = f"加载课程失败: {str(e)}"
            log_message("ERROR", error_msg)
            self.update_status(error_msg, is_error=True)

    def load_sample_data(self):
        """加载示例数据"""
        sample_courses = [
            {"name": "高等数学", "teacher": "张教授", "place": "教学楼A101",
             "time": "1-2节", "week": 1, "day": 0, "term": "2024秋"},
            {"name": "大学英语", "teacher": "李老师", "place": "外语楼201",
             "time": "3-4节", "week": 1, "day": 1, "term": "2024秋"},
            {"name": "计算机基础", "teacher": "王教授", "place": "计算机中心305",
             "time": "5-6节", "week": 1, "day": 2, "term": "2024秋"},
        ]

        for course in sample_courses:
            self.add_course_to_grid(course)

    def add_course_to_grid(self, course):
        try:
            day = int(course['day'])
            time_str = course['time']

            # 解析时间段
            sections = self.parse_section_from_time(time_str)

            for section in sections:
                section_num = int(section.replace('第', '').replace('节', '')) - 1
                if 0 <= section_num < 13 and 0 <= day < 5:
                    # 保存课程信息
                    self.course_grid[section_num][day] = course

                    # 更新按钮显示
                    display_text = f"{course['name']}\n{course['teacher']}\n{course['place']}"
                    self.course_buttons[section_num][day].config(
                        text=display_text,
                        bg="#d5f4e6",
                        fg="#27ae60"
                    )

        except Exception as e:
            log_message("ERROR", f"添加课程到网格失败: {str(e)}")

    def edit_course_cell(self, row, col):
        try:
            course_data = self.course_grid[row][col]

            if course_data:
                # 编辑现有课程
                dialog = CourseEditDialog(self, course_data, is_new=False)
                self.root.wait_window(dialog.dialog)
                if dialog.result == 'success':
                    self.load_courses()
            else:
                # 添加新课程
                default_data = {
                    'id': -1,
                    'name': '',
                    'teacher': '',
                    'place': '',
                    'day': str(col),
                    'time': f"第{row + 1}节",
                    'week': self.current_week.get(),
                    'term': '2024-2025学年第一学期'
                }
                dialog = CourseEditDialog(self, default_data, is_new=True)
                self.root.wait_window(dialog.dialog)
                if dialog.result == 'success':
                    self.load_courses()

        except Exception as e:
            error_msg = f"编辑课程失败: {str(e)}"
            log_message("ERROR", error_msg)
            self.update_status(error_msg, is_error=True)

    def add_course(self):
        try:
            if not DB_AVAILABLE:
                self.messagebox.showerror("错误", "数据库功能不可用！")
                return

            default_data = {
                'id': -1,
                'name': '',
                'teacher': '',
                'place': '',
                'day': '0',
                'time': '第1节',
                'week': self.current_week.get(),
                'term': '2024-2025学年第一学期'
            }
            dialog = CourseEditDialog(self, default_data, is_new=True)
            self.root.wait_window(dialog.dialog)
            if dialog.result == 'success':
                self.load_courses()

        except Exception as e:
            error_msg = f"添加课程失败: {str(e)}"
            log_message("ERROR", error_msg)
            self.update_status(error_msg, is_error=True)

    def delete_all_courses(self):
        try:
            if not DB_AVAILABLE:
                self.messagebox.showerror("错误", "数据库功能不可用！")
                return

            if self.messagebox.askyesno("确认删除", "确定要删除所有课程吗？此操作不可恢复！"):
                if delete_all_courses():
                    self.load_courses()
                    self.update_status("所有课程已删除")
                else:
                    self.update_status("删除课程失败", is_error=True)

        except Exception as e:
            error_msg = f"删除所有课程失败: {str(e)}"
            log_message("ERROR", error_msg)
            self.update_status(error_msg, is_error=True)

    def parse_week_str(self, week_str):
        """将周次字符串解析为周次列表
        例如: "1,3,5-10" -> [1,3,5,6,7,8,9,10]
        """
        weeks = []
        parts = week_str.split(',')
        for part in parts:
            part = part.strip()
            if '-' in part:
                start, end = part.split('-')
                try:
                    start_week = int(start)
                    end_week = int(end)
                    weeks.extend(range(start_week, end_week + 1))
                except:
                    pass
            else:
                try:
                    week_num = int(part)
                    weeks.append(week_num)
                except:
                    pass
        return weeks

    def import_file(self):
        try:
            if not DB_AVAILABLE:
                self.messagebox.showerror("错误", "数据库功能不可用！")
                return

            file_path = filedialog.askopenfilename(
                title="选择课表文件",
                filetypes=[("CSV文件", "*.csv"),
                           ("Excel文件", "*.xlsx"),
                           ("所有文件", "*.*")]
            )

            if not file_path:
                return

            self.update_status("正在导入课表文件...")
            imported_count = 0

            # 根据文件扩展名选择不同的读取方式
            if file_path.lower().endswith('.csv'):
                # 处理CSV文件
                with open(file_path, 'r', encoding='utf-8') as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        if '课程名称' in row and row['课程名称'].strip():
                            name = row['课程名称'].strip()
                            teacher = row.get('教师', '').strip()
                            place = row.get('地点', '').strip()
                            day = row.get('星期', '0').strip()
                            time = row.get('时间', '第1节').strip()
                            week = int(row.get('周次', '1'))
                            term = row.get('学期', '2024秋').strip()

                            if insert_course(name, place, time, week, teacher, day, term):
                                imported_count += 1

            elif file_path.lower().endswith('.xlsx'):
                # 处理Excel文件 - 尝试两种格式
                try:
                    # 尝试简单格式导入
                    workbook = openpyxl.load_workbook(file_path)
                    sheet = workbook.active

                    # 获取标题行（假设第一行是标题）
                    headers = [cell.value for cell in sheet[1]]

                    # 检查是否是简单格式
                    simple_format = True
                    required_headers = ['课程名称', '教师', '地点', '星期', '时间', '周次', '学期']
                    for header in required_headers:
                        if header not in headers:
                            simple_format = False
                            break

                    if simple_format:
                        # 简单格式导入
                        for row in sheet.iter_rows(min_row=2, values_only=True):
                            row_data = dict(zip(headers, row))

                            if '课程名称' in row_data and row_data['课程名称']:
                                name = str(row_data['课程名称']).strip()
                                teacher = str(row_data.get('教师', '')).strip()
                                place = str(row_data.get('地点', '')).strip()
                                day = str(row_data.get('星期', '0')).strip()
                                time = str(row_data.get('时间', '第1节')).strip()
                                week = int(row_data.get('周次', 1))
                                term = str(row_data.get('学期', '2024秋')).strip()

                                if insert_course(name, place, time, week, teacher, day, term):
                                    imported_count += 1
                    else:
                        # 原始课表格式 - 使用app_pandes解析
                        courses_2d = app_pandes.parse_course_schedule(file_path)

                        if len(courses_2d) <= 1:
                            self.update_status("解析原始课表失败：未找到课程数据", is_error=True)
                            return

                        # 表头检查
                        header = courses_2d[0]
                        expected_headers = ['课程名称', '任课教师', '上课周次', '上课时间', '上课地点', '星期']
                        if header != expected_headers:
                            log_message("WARNING", f"解析出的表头为: {header}, 期望: {expected_headers}")

                        # 遍历课程数据
                        for course_data in courses_2d[1:]:
                            if len(course_data) < 6:
                                continue

                            name = course_data[0]
                            teacher = course_data[1]
                            week_str = course_data[2]  # 周次字符串，如"1,3,5-10"
                            period = course_data[3]  # 时间字符串，如"1-2"
                            location = course_data[4]
                            weekday = course_data[5]  # 数字，0代表星期一
                            term = "2024秋"  # 默认学期

                            # 解析周次字符串
                            week_list = self.parse_week_str(week_str)

                            # 转换时间字符串为统一格式
                            if not period.startswith("第"):
                                period = f"第{period}节"

                            # 对于每个周次，插入一条记录
                            for week_num in week_list:
                                if insert_course(name, location, period, week_num, teacher, str(weekday), term):
                                    imported_count += 1
                except Exception as e:
                    error_msg = f"导入Excel文件失败: {str(e)}"
                    log_message("ERROR", error_msg)
                    self.update_status(error_msg, is_error=True)
                    return

            self.load_courses()
            self.update_status(f"成功导入 {imported_count} 门课程")
            log_message("INFO", f"导入文件: {file_path}, 成功导入 {imported_count} 门课程")

        except Exception as e:
            error_msg = f"导入文件失败: {str(e)}"
            log_message("ERROR", error_msg)
            self.update_status(error_msg, is_error=True)

    def prev_week(self):
        if self.current_week.get() > 1:
            self.current_week.set(self.current_week.get() - 1)
            self.week_label.config(text=f"第 {self.current_week.get()} 周")
            self.load_courses()
            self.update_status(f"切换到第 {self.current_week.get()} 周")

    def next_week(self):
        if self.current_week.get() < 30:
            self.current_week.set(self.current_week.get() + 1)
            self.week_label.config(text=f"第 {self.current_week.get()} 周")
            self.load_courses()
            self.update_status(f"切换到第 {self.current_week.get()} 周")

    def parse_section_from_time(self, time_str):
        if not time_str:
            return []

        # 处理多种时间格式
        if '节' not in time_str:
            # 格式如 "1-2"
            if '-' in time_str:
                parts = time_str.split('-')
                if len(parts) == 2:
                    try:
                        start = int(parts[0])
                        end = int(parts[1])
                        return [f"第{i}节" for i in range(start, end + 1)]
                    except:
                        pass
            else:
                # 单个节次
                try:
                    section_num = int(time_str)
                    return [f"第{section_num}节"]
                except:
                    pass

        # 标准格式处理
        if '-' in time_str:
            parts = time_str.replace('第', '').replace('节', '').split('-')
            start_section = int(parts[0])
            end_section = int(parts[1])
            return [f"第{i}节" for i in range(start_section, end_section + 1)]
        else:
            if '第' in time_str and '节' in time_str:
                return [time_str]
            else:
                # 尝试提取数字
                match = re.search(r'(\d+)', time_str)
                if match:
                    section_num = match.group(1)
                    return [f"第{section_num}节"]
                else:
                    return [time_str]

    def open_reminder_settings(self):
        try:
            settings_window = tk.Toplevel(self.root)
            settings_window.title("⏰ 课程提醒设置")
            settings_window.geometry("450x400")
            settings_window.configure(bg="#f0f2f5")
            settings_window.resizable(False, False)

            # 居中显示
            settings_window.update_idletasks()
            x = (settings_window.winfo_screenwidth() // 2) - (450 // 2)
            y = (settings_window.winfo_screenheight() // 2) - (400 // 2)
            settings_window.geometry(f"450x400+{x}+{y}")

            main_frame = tk.Frame(settings_window, bg="#f0f2f5")
            main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

            title_label = tk.Label(main_frame, text="📚 智能课程提醒设置",
                                   font=("微软雅黑", 16, "bold"),
                                   bg="#f0f2f5", fg="#2c3e50")
            title_label.pack(pady=(0, 20))

            # 学期开始日期设置
            date_frame = tk.Frame(main_frame, bg="#f0f2f5")
            date_frame.pack(fill=tk.X, pady=10)

            tk.Label(date_frame, text="学期开始日期:",
                     font=("微软雅黑", 10), bg="#f0f2f5", fg="#34495e", anchor="w").pack(side=tk.LEFT, padx=(0, 10))

            # 使用日期选择器
            self.term_start_var = tk.StringVar()
            if self.term_start_date:
                self.term_start_var.set(self.term_start_date.strftime("%Y-%m-%d"))
            else:
                self.term_start_var.set(datetime.now().strftime("%Y-%m-%d"))

            date_entry = DateEntry(date_frame, textvariable=self.term_start_var,
                                   font=("微软雅黑", 10), width=12,
                                   date_pattern="yyyy-mm-dd")
            date_entry.pack(side=tk.LEFT)

            # 提醒提前时间设置
            time_frame = tk.Frame(main_frame, bg="#f0f2f5")
            time_frame.pack(fill=tk.X, pady=10)

            tk.Label(time_frame, text="提前提醒时间(分钟):",
                     font=("微软雅黑", 10), bg="#f0f2f5", fg="#34495e").pack(side=tk.LEFT, padx=(0, 10))

            self.remind_minutes_var = tk.StringVar(value=str(self.remind_minutes))
            time_entry = tk.Entry(time_frame, textvariable=self.remind_minutes_var, width=5,
                                  font=("微软雅黑", 10))
            time_entry.pack(side=tk.LEFT, padx=5)

            # 按钮区域
            button_frame = tk.Frame(main_frame, bg="#f0f2f5")
            button_frame.pack(fill=tk.X, pady=20)

            save_btn = tk.Button(button_frame, text="保存设置",
                                 command=self.save_reminder_settings,
                                 font=("微软雅黑", 11, "bold"),
                                 bg="#3498db", fg="white",
                                 relief=tk.FLAT, padx=15, pady=6)
            save_btn.pack(side=tk.LEFT, padx=5)

            demo_btn = tk.Button(button_frame, text="演示提醒",
                                 command=self.demo_reminder,
                                 font=("微软雅黑", 11),
                                 bg="#9b59b6", fg="white",
                                 relief=tk.FLAT, padx=15, pady=6)
            demo_btn.pack(side=tk.LEFT, padx=5)

            close_btn = tk.Button(button_frame, text="关闭",
                                  command=settings_window.destroy,
                                  font=("微软雅黑", 11),
                                  bg="#95a5a6", fg="white",
                                  relief=tk.FLAT, padx=15, pady=6)
            close_btn.pack(side=tk.RIGHT)

        except Exception as e:
            log_message("ERROR", f"打开提醒设置失败: {str(e)}")

    def save_reminder_settings(self):
        """保存提醒设置"""
        try:
            # 获取学期开始日期
            self.term_start_date = datetime.strptime(self.term_start_var.get(), "%Y-%m-%d").date()

            # 获取提醒时间
            self.remind_minutes = int(self.remind_minutes_var.get())

            # 保存设置
            self.save_term_settings()

            self.messagebox.showinfo("成功", "提醒设置已保存")
        except ValueError:
            self.messagebox.showerror("错误", "请输入有效的数字")
        except Exception as e:
            self.messagebox.showerror("错误", f"保存设置失败: {str(e)}")

    def demo_reminder(self):
        """演示提醒功能"""
        try:
            self.show_system_notification("演示提醒",
                                          "这是一个课程提醒演示\n"
                                          "课程名称: 高等数学\n"
                                          "时间: 第1节 (08:00)\n"
                                          "地点: 教学楼A101\n"
                                          "教师: 张教授")
            self.update_status("演示提醒已发送", duration=3000)
        except Exception as e:
            log_message("ERROR", f"演示提醒失败: {str(e)}")

    def show_reminder_list(self):
        """显示提醒列表"""
        try:
            if not DB_AVAILABLE:
                self.messagebox.showerror("错误", "数据库功能不可用！")
                return

            # 获取当前周的所有课程
            courses = get_courses_by_week(self.current_week.get())

            if not courses:
                self.messagebox.showinfo("提示", "本周没有需要提醒的课程")
                return

            # 创建提醒列表窗口
            list_window = tk.Toplevel(self.root)
            list_window.title("📅 本周课程提醒列表")
            list_window.geometry("600x500")
            list_window.configure(bg="#f0f2f5")
            list_window.resizable(True, True)

            # 居中显示
            list_window.update_idletasks()
            x = (list_window.winfo_screenwidth() // 2) - (600 // 2)
            y = (list_window.winfo_screenheight() // 2) - (500 // 2)
            list_window.geometry(f"600x500+{x}+{y}")

            # 主框架
            main_frame = tk.Frame(list_window, bg="#f0f2f5")
            main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

            # 标题
            title_label = tk.Label(main_frame, text=f"第 {self.current_week.get()} 周课程提醒列表",
                                   font=("微软雅黑", 14, "bold"),
                                   bg="#f0f2f5", fg="#2c3e50")
            title_label.pack(pady=(0, 15))

            # 创建表格
            columns = ("课程名称", "教师", "地点", "时间", "星期")
            tree = ttk.Treeview(main_frame, columns=columns, show="headings", height=15)

            # 设置列宽
            tree.column("课程名称", width=150, anchor="w")
            tree.column("教师", width=100, anchor="w")
            tree.column("地点", width=120, anchor="w")
            tree.column("时间", width=80, anchor="center")
            tree.column("星期", width=60, anchor="center")

            # 设置表头
            for col in columns:
                tree.heading(col, text=col)

            # 添加滚动条
            scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=tree.yview)
            tree.configure(yscrollcommand=scrollbar.set)

            # 添加数据
            weekdays = ["一", "二", "三", "四", "五"]
            for course in courses:
                day = int(course['day'])
                weekday = f"星期{weekdays[day]}" if 0 <= day < 5 else str(day)
                tree.insert("", "end", values=(
                    course['name'],
                    course['teacher'],
                    course['place'],
                    course['time'],
                    weekday
                ))

            # 布局
            tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
            scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

            # 状态标签
            count_label = tk.Label(main_frame, text=f"共 {len(courses)} 门课程",
                                   font=("微软雅黑", 10),
                                   bg="#f0f2f5", fg="#7f8c8d")
            count_label.pack(pady=(10, 0))

        except Exception as e:
            self.messagebox.showerror("错误", f"显示提醒列表失败: {str(e)}")

    def show_system_notification(self, title, message):
        """显示系统通知 - 美化版"""
        try:
            # 创建通知窗口
            notif_window = tk.Toplevel(self.root)
            notif_window.title(title)
            notif_window.geometry("400x220")
            notif_window.resizable(False, False)
            notif_window.attributes('-topmost', True)
            notif_window.configure(bg="#2c3e50")

            # 添加应用图标
            try:
                icon_path = os.path.join(os.path.dirname(__file__), 'icon.ico')
                if os.path.exists(icon_path):
                    notif_window.iconbitmap(icon_path)
            except:
                pass

            # 居中显示
            notif_window.update_idletasks()
            screen_width = notif_window.winfo_screenwidth()
            screen_height = notif_window.winfo_screenheight()
            x = (screen_width // 2) - (400 // 2)
            y = (screen_height // 2) - (220 // 2)
            notif_window.geometry(f"400x220+{x}+{y}")

            # 标题区域
            title_frame = tk.Frame(notif_window, bg="#3498db", height=50)
            title_frame.pack(fill=tk.X)

            title_label = tk.Label(title_frame, text=title,
                                   font=("微软雅黑", 14, "bold"),
                                   fg="white", bg="#3498db")
            title_label.pack(pady=15)

            # 图标
            icon_label = tk.Label(title_frame, text="⏰",
                                  font=("Arial", 18),
                                  bg="#3498db", fg="white")
            icon_label.place(x=20, y=15)

            # 内容区域
            content_frame = tk.Frame(notif_window, bg="#ecf0f1")
            content_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))

            # 消息内容
            message_label = tk.Label(content_frame, text=message,
                                     font=("微软雅黑", 12), bg="#ecf0f1",
                                     wraplength=380, justify=tk.LEFT)
            message_label.pack(pady=20, padx=20)

            # 关闭按钮
            close_btn = tk.Button(notif_window, text="知道了", width=10,
                                  command=notif_window.destroy,
                                  font=("微软雅黑", 10, "bold"),
                                  bg="#3498db", fg="white",
                                  relief=tk.FLAT, bd=0)
            close_btn.pack(pady=(0, 15))

            # 自动关闭
            notif_window.after(8000, notif_window.destroy)

        except Exception as e:
            log_message("ERROR", f"显示通知失败: {str(e)}")

    def run(self):
        try:
            self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
            self.root.mainloop()
        except Exception as e:
            log_message("ERROR", f"运行错误: {str(e)}")

    def on_closing(self):
        """窗口关闭时的处理"""
        self.stop_reminder_thread()
        self.root.destroy()


if __name__ == "__main__":
    try:
        app = SmartTimetableApp()
        app.run()
    except Exception as e:
        print(f"程序启动失败: {str(e)}")
        log_message("CRITICAL", f"程序启动失败: {str(e)}")
        input("按回车键退出...")