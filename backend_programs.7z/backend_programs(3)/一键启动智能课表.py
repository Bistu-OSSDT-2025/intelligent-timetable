#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
智能课表系统 - 一键启动程序
自动检查并安装依赖包，然后启动主程序
"""

import sys
import subprocess
import importlib
import os
import time
from pathlib import Path

def print_banner():
    """打印启动横幅"""
    banner = """
╔══════════════════════════════════════════════════════════════╗
║                    智能课表系统 v6.0                          ║
║                    一键启动程序                               ║
║                                                              ║
║  正在检查系统环境和依赖包...                                  ║
╚══════════════════════════════════════════════════════════════╝
    """
    print(banner)

def check_python_version():
    """检查Python版本"""
    print("🔍 检查Python版本...")
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 7):
        print(f"❌ Python版本过低: {version.major}.{version.minor}")
        print("   需要Python 3.7或更高版本")
        return False
    else:
        print(f"✅ Python版本: {version.major}.{version.minor}.{version.micro}")
        return True

def install_package(package_name, pip_name=None):
    """安装Python包"""
    if pip_name is None:
        pip_name = package_name
    
    print(f"📦 正在安装 {package_name}...")
    try:
        # 使用pip安装包
        result = subprocess.run([
            sys.executable, "-m", "pip", "install", pip_name, "--quiet"
        ], capture_output=True, text=True, timeout=60)
        
        if result.returncode == 0:
            print(f"✅ {package_name} 安装成功")
            return True
        else:
            print(f"❌ {package_name} 安装失败: {result.stderr}")
            return False
    except subprocess.TimeoutExpired:
        print(f"❌ {package_name} 安装超时")
        return False
    except Exception as e:
        print(f"❌ {package_name} 安装出错: {str(e)}")
        return False

def check_and_install_package(package_name, pip_name=None):
    """检查包是否已安装，如果没有则安装"""
    print(f"🔍 检查 {package_name}...")
    
    try:
        importlib.import_module(package_name)
        print(f"✅ {package_name} 已安装")
        return True
    except ImportError:
        print(f"⚠️  {package_name} 未安装，正在安装...")
        return install_package(package_name, pip_name)

def check_required_packages():
    """检查并安装所需的包"""
    print("\n📋 检查依赖包...")
    
    # 定义需要检查的包
    required_packages = [
        ("tkinter", None),  # 通常随Python一起安装
        ("openpyxl", "openpyxl"),
        ("tkcalendar", "tkcalendar"),
        ("sqlite3", None),  # 通常随Python一起安装
        ("json", None),     # 通常随Python一起安装
        ("csv", None),      # 通常随Python一起安装
        ("re", None),       # 通常随Python一起安装
        ("datetime", None), # 通常随Python一起安装
        ("threading", None), # 通常随Python一起安装
        ("time", None),     # 通常随Python一起安装
        ("logging", None),  # 通常随Python一起安装
        ("os", None),       # 通常随Python一起安装
        ("pathlib", None),  # 通常随Python一起安装
    ]
    
    all_installed = True
    
    for package, pip_name in required_packages:
        if not check_and_install_package(package, pip_name):
            all_installed = False
    
    return all_installed

def check_main_files():
    """检查主程序文件是否存在"""
    print("\n📁 检查程序文件...")
    
    required_files = [
        "智能课表.py",
        "sqliteconnect.py",
        "app_pandes.py"
    ]
    
    missing_files = []
    
    for file_name in required_files:
        if os.path.exists(file_name):
            print(f"✅ {file_name} 存在")
        else:
            print(f"❌ {file_name} 缺失")
            missing_files.append(file_name)
    
    if missing_files:
        print(f"\n⚠️  缺少以下文件: {', '.join(missing_files)}")
        print("   请确保所有程序文件都在同一目录下")
        return False
    
    return True

def start_main_program():
    """启动主程序"""
    print("\n🚀 启动智能课表系统...")
    print("=" * 60)
    
    try:
        # 导入并运行主程序
        import 智能课表
        app = 智能课表.SmartTimetableApp()
        app.run()
    except KeyboardInterrupt:
        print("\n\n👋 程序被用户中断")
    except Exception as e:
        print(f"\n❌ 程序启动失败: {str(e)}")
        print("\n请检查错误信息并重试")
        input("\n按回车键退出...")

def main():
    """主函数"""
    try:
        # 打印横幅
        print_banner()
        
        # 检查Python版本
        if not check_python_version():
            input("\n按回车键退出...")
            return
        
        # 检查并安装依赖包
        if not check_required_packages():
            print("\n❌ 依赖包安装失败，程序无法启动")
            input("按回车键退出...")
            return
        
        # 检查程序文件
        if not check_main_files():
            print("\n❌ 程序文件缺失，无法启动")
            input("按回车键退出...")
            return
        
        # 启动主程序
        start_main_program()
        
    except Exception as e:
        print(f"\n❌ 启动程序时发生错误: {str(e)}")
        input("按回车键退出...")

if __name__ == "__main__":
    main() 