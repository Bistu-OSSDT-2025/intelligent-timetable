#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试数据库连接和更新功能
"""

import sys
import os

# 添加当前目录到Python路径
sys.path.insert(0, os.path.dirname(__file__))

try:
    from sqliteconnect import get_db_connection, insert_course, update_course, get_all_courses, get_course_by_id
    
    print("=== 数据库连接测试 ===")
    
    # 测试数据库连接
    conn = get_db_connection()
    if conn:
        print("✅ 数据库连接成功")
        conn.close()
    else:
        print("❌ 数据库连接失败")
        sys.exit(1)
    
    # 测试插入课程
    print("\n=== 测试插入课程 ===")
    success = insert_course("测试课程", "测试地点", "第1节", 1, "测试教师", "0", "2024秋")
    if success:
        print("✅ 插入课程成功")
    else:
        print("❌ 插入课程失败")
    
    # 获取所有课程
    print("\n=== 获取所有课程 ===")
    courses = get_all_courses()
    print(f"当前共有 {len(courses)} 门课程")
    
    if courses:
        # 测试更新课程
        print("\n=== 测试更新课程 ===")
        course_id = courses[0]['id']
        print(f"更新课程ID: {course_id}")
        
        success = update_course(course_id, name="更新后的课程名称", place="更新后的地点")
        if success:
            print("✅ 更新课程成功")
            
            # 验证更新结果
            updated_course = get_course_by_id(course_id)
            if updated_course:
                print(f"更新后的课程信息: {updated_course}")
            else:
                print("❌ 无法获取更新后的课程信息")
        else:
            print("❌ 更新课程失败")
    
    print("\n=== 测试完成 ===")
    
except ImportError as e:
    print(f"❌ 导入模块失败: {e}")
except Exception as e:
    print(f"❌ 测试过程中出错: {e}")
    import traceback
    traceback.print_exc() 