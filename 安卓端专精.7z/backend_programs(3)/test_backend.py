#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
后端API功能测试脚本
"""

import sys
import os
from course_api import CourseAPI

def test_backend_functions():
    """测试后端功能"""
    print("=" * 50)
    print("开始测试后端API功能")
    print("=" * 50)
    
    # 创建API实例
    api = CourseAPI()
    
    # 测试1: 插入课程
    print("\n1. 测试插入课程...")
    course_data = {
        'name': '测试课程',
        'place': '测试教室',
        'time': '第1-2节',
        'week': 1,
        'teacher': '测试教师',
        'day': 1,
        'term': '2024-2025-1'
    }
    
    success, message, course_id = api.insert_course(course_data)
    print(f"插入结果: {success}, 消息: {message}, 课程ID: {course_id}")
    
    if not success or course_id is None:
        print("插入课程失败，停止测试")
        return
    
    # 测试2: 获取课程
    print("\n2. 测试获取课程...")
    course = api.get_course_by_id(course_id)
    if course:
        print(f"获取课程成功: {course}")
    else:
        print("获取课程失败")
    
    # 测试3: 更新课程
    print("\n3. 测试更新课程...")
    update_data = {
        'name': '更新后的测试课程',
        'place': '更新后的教室'
    }
    success, message = api.update_course(course_id, update_data)
    print(f"更新结果: {success}, 消息: {message}")
    
    # 验证更新
    updated_course = api.get_course_by_id(course_id)
    if updated_course:
        print(f"更新后的课程: {updated_course}")
    
    # 测试4: 插入同名课程
    print("\n4. 测试插入同名课程...")
    course_data2 = {
        'name': '更新后的测试课程',
        'place': '另一个教室',
        'time': '第3-4节',
        'week': 2,
        'teacher': '另一个教师',
        'day': 2,
        'term': '2024-2025-1'
    }
    success2, message2, course_id2 = api.insert_course(course_data2)
    print(f"插入同名课程结果: {success2}, 消息: {message2}, 课程ID: {course_id2}")
    
    # 测试5: 更新同名课程
    print("\n5. 测试更新同名课程...")
    if success2:
        update_data2 = {
            'teacher': '统一教师',
            'place': '统一教室'
        }
        success, message, count = api.update_courses_by_name('更新后的测试课程', update_data2)
        print(f"更新同名课程结果: {success}, 消息: {message}, 更新数量: {count}")
    
    # 测试6: 获取所有课程
    print("\n6. 测试获取所有课程...")
    all_courses = api.get_all_courses()
    print(f"总课程数: {len(all_courses)}")
    for course in all_courses:
        print(f"  - {course}")
    
    # 测试7: 按周获取课程
    print("\n7. 测试按周获取课程...")
    week_courses = api.get_courses_by_week(1)
    print(f"第1周课程数: {len(week_courses)}")
    for course in week_courses:
        print(f"  - {course}")
    
    # 测试8: 搜索课程
    print("\n8. 测试搜索课程...")
    search_results = api.search_courses('测试')
    print(f"搜索结果数量: {len(search_results)}")
    for course in search_results:
        print(f"  - {course}")
    
    # 测试9: 获取统计信息
    print("\n9. 测试获取统计信息...")
    stats = api.get_course_statistics()
    print(f"统计信息: {stats}")
    
    # 测试10: 删除课程
    print("\n10. 测试删除课程...")
    success, message = api.delete_course(course_id)
    print(f"删除课程结果: {success}, 消息: {message}")
    
    if success2 and course_id2 is not None:
        success, message = api.delete_course(course_id2)
        print(f"删除同名课程结果: {success}, 消息: {message}")
    
    # 验证删除
    remaining_courses = api.get_all_courses()
    print(f"删除后剩余课程数: {len(remaining_courses)}")
    
    print("\n" + "=" * 50)
    print("后端API功能测试完成")
    print("=" * 50)

def test_compatibility_functions():
    """测试兼容性函数"""
    print("\n" + "=" * 50)
    print("开始测试兼容性函数")
    print("=" * 50)
    
    from course_api import insert_course, update_course, delete_course, get_all_courses, get_courses_by_week, get_course_by_id
    
    # 测试兼容性插入
    print("\n1. 测试兼容性插入...")
    success = insert_course('兼容性测试课程', '兼容性教室', '第1-2节', 1, '兼容性教师', 1, '2024-2025-1')
    print(f"兼容性插入结果: {success}")
    
    # 测试兼容性获取
    print("\n2. 测试兼容性获取...")
    courses = get_all_courses()
    print(f"兼容性获取课程数: {len(courses)}")
    
    if courses:
        course_id = courses[0]['id']
        course = get_course_by_id(course_id)
        print(f"兼容性获取单个课程: {course}")
        
        # 测试兼容性更新
        print("\n3. 测试兼容性更新...")
        success = update_course(course_id, name='更新后的兼容性课程')
        print(f"兼容性更新结果: {success}")
        
        # 测试兼容性删除
        print("\n4. 测试兼容性删除...")
        success = delete_course(course_id)
        print(f"兼容性删除结果: {success}")
    
    print("\n" + "=" * 50)
    print("兼容性函数测试完成")
    print("=" * 50)

if __name__ == "__main__":
    try:
        test_backend_functions()
        test_compatibility_functions()
        print("\n所有测试完成！")
    except Exception as e:
        print(f"测试过程中出现错误: {e}")
        import traceback
        traceback.print_exc() 