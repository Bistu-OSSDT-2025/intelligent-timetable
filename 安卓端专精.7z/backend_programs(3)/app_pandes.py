import re
from openpyxl import load_workbook

def parse_course_schedule(file_path):
    # 加载Excel工作簿
    wb = load_workbook(file_path)
    sheet = wb.active

    # 获取星期列名
    weekdays = ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日']
    weekday_map = {day: idx for idx, day in enumerate(weekdays)}  # 创建星期映射表

    # 创建二维数组（列表的列表）来存储课程数据
    courses_2d = []

    # 添加表头作为二维数组的第一行
    header = ['课程名称', '任课教师', '上课周次', '上课时间', '上课地点', '星期']
    courses_2d.append(header)

    # 遍历每一行
    for row in sheet.iter_rows(values_only=True):
        # 获取时间节次（A列）
        time_slot = row[0] if row[0] else ""

        # 只处理包含"节"的时间行
        if "节" not in str(time_slot):
            continue

        # 遍历每个工作日列
        for col_idx, weekday_str in enumerate(weekdays, 1):
            # 跳过超出列范围的索引
            if col_idx >= len(row):
                continue

            cell_value = row[col_idx]
            if not cell_value:
                continue

            # 分割多个课程（按逗号分隔）
            raw_courses = [c.strip() for c in str(cell_value).split(',') if c.strip()]

            for course_str in raw_courses:
                # 分割课程详细信息（按<br>或换行符）
                parts = [p.strip() for p in re.split('<br>|\n', course_str) if p.strip()]

                if len(parts) < 3:
                    continue

                course_name = parts[0]
                teacher = parts[1]
                time_location = parts[2]

                # 解析时间和地点
                location = ""
                time_info = ""

                # 尝试分割时间和地点 - 处理带空格和不带空格的情况
                if ', ' in time_location:
                    time_info, location = time_location.split(', ', 1)
                elif ',' in time_location:
                    time_info, location = time_location.split(',', 1)
                elif '， ' in time_location:  # 中文逗号加空格
                    time_info, location = time_location.split('， ', 1)
                elif '，' in time_location:  # 中文逗号
                    time_info, location = time_location.split('，', 1)
                else:
                    time_info = time_location

                # 解析周次和节次
                week_match = re.search(r'(\d+)周', time_info)
                period_match = re.search(r'(\d+-\d+)节', time_info)

                week_num = week_match.group(1) if week_match else ""
                period = period_match.group(1) if period_match else ""

                # 将星期字符串转换为数字
                weekday_num = weekday_map.get(weekday_str, -1)  # 默认-1表示无效值

                # 将课程信息添加到二维数组
                course_data = [
                    course_name,
                    teacher,
                    week_num,
                    period,
                    location.strip(),
                    weekday_num  # 存储为数字
                ]
                courses_2d.append(course_data)

    return courses_2d


# 新增：合并相同课程信息的函数
def merge_duplicate_courses(courses_list):
    """
    合并完全相同的课程记录
    :param courses_list: 二维课程列表，第一行为表头
    :return: 去重后的课程列表
    """
    if len(courses_list) <= 1:
        return courses_list

    # 保留表头
    header = courses_list[0]
    courses_data = courses_list[1:]

    # 使用集合跟踪已出现的课程（使用元组因为可哈希）
    seen = set()
    unique_courses = []

    for course in courses_data:
        # 创建课程的元组表示（用于比较）
        course_tuple = tuple(course)

        if course_tuple not in seen:
            seen.add(course_tuple)
            unique_courses.append(course)

    # 重新组合表头和去重后的数据
    return [header] + unique_courses


# 示例用法
if __name__ == "__main__":
    file_path = 'data.xlsx'  # 替换为实际的Excel文件路径
    try:
        print("开始解析课程表...")
        courses_2d = parse_course_schedule(file_path)

        # 新增：合并相同的课程记录
        print("合并重复课程信息...")
        original_count = len(courses_2d) - 1  # 减去表头
        courses_2d = merge_duplicate_courses(courses_2d)
        new_count = len(courses_2d) - 1
        duplicate_count = original_count - new_count

        if duplicate_count > 0:
            print(f"合并了 {duplicate_count} 条重复课程记录")

        if len(courses_2d) <= 1:  # 只有表头没有数据
            print("警告: 未解析到任何课程信息")
        else:
            print(f"解析出的课程总数: {len(courses_2d) - 1}")  # 减去表头行

            # 演示如何访问二维数组中的元素
            print("\n二维数组结构说明:")
            print("courses_2d[0] 是表头:", courses_2d[0])
            print("courses_2d[1:] 是课程数据")

            # 示例：访问第一门课程的信息
            if len(courses_2d) > 1:
                first_course = courses_2d[1]
                print("\n第一门课程信息:")
                print(f"课程名称: {first_course[0]}")
                print(f"任课教师: {first_course[1]}")
                print(f"上课周次: {first_course[2]}")
                print(f"上课时间: {first_course[3]}")
                print(f"上课地点: {first_course[4]}")
                print(f"星期(数字): {first_course[5]}")

                # 也可以通过列名对应的索引访问
                COLUMN_INDEX = {name: idx for idx, name in enumerate(courses_2d[0])}
                print("\n使用列名索引访问:")
                print(f"课程名称: {first_course[COLUMN_INDEX['课程名称']]}")
                print(f"任课教师: {first_course[COLUMN_INDEX['任课教师']]}")

                # 注意：这里不再进行数据库插入，因为已经移除了MySQL操作

    except Exception as e:
        print(f"解析过程中发生错误: {str(e)}")
        # 打印更详细的错误信息
        import traceback

        traceback.print_exc()