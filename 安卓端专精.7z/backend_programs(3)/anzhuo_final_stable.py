#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
智能课表 - 安卓版（最终稳定版本）
完全修复所有问题，确保正常运行和数据加载
"""

import os
import json
import threading
import time
from datetime import datetime, timedelta
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, Rectangle
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.core.text import LabelBase
from kivy.properties import StringProperty
from plyer import notification
from kivy.uix.widget import Widget
from kivy.metrics import dp

# 设置窗口大小
Window.size = (400, 600)

# 尝试导入数据库相关模块
try:
    from mysqlconnect import (
        get_db_connection,
        insert_into_table,
        get_all_table_names,
        query_by_id_and_table,
        update_field,
        delete_by_id_and_table
    )
    DB_AVAILABLE = True
    print("数据库模块加载成功")
except ImportError as e:
    print(f"数据库模块加载失败: {e}")
    DB_AVAILABLE = False

# 注册中文字体
def setup_chinese_font():
    """设置中文字体支持"""
    try:
        font_paths = [
            "C:/Windows/Fonts/msyh.ttc",  # 微软雅黑
            "C:/Windows/Fonts/simsun.ttc",  # 宋体
            "C:/Windows/Fonts/simhei.ttf",  # 黑体
        ]
        
        for font_path in font_paths:
            if os.path.exists(font_path):
                LabelBase.register(name="Chinese", fn_regular=font_path)
                print(f"已加载中文字体: {font_path}")
                return True
        
        print("未找到系统中文字体，使用默认字体")
        return False
    except Exception as e:
        print(f"字体加载失败: {e}")
        return False

# 设置中文字体
FONT_LOADED = setup_chinese_font()
FONT_NAME = "Chinese" if FONT_LOADED else "Roboto"

# 日志记录函数
def log_message(message_type, message):
    """记录消息到日志文件"""
    try:
        log_file = os.path.join(os.path.dirname(__file__), 'debug.log')
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S")} [{message_type}]: {message}\n')
    except Exception as e:
        print(f"日志记录失败: {str(e)}")

# 状态消息框类
class StatusMessageBox:
    def __init__(self, app):
        self.app = app

    def showerror(self, title, message):
        log_message("ERROR", f"{title}: {message}")
        if hasattr(self.app, 'update_status'):
            self.app.update_status(f"错误: {message}", is_error=True)
        return None

    def showinfo(self, title, message):
        log_message("INFO", f"{title}: {message}")
        if hasattr(self.app, 'update_status'):
            self.app.update_status(f"成功: {message}")
        return None

    def showwarning(self, title, message):
        log_message("WARNING", f"{title}: {message}")
        if hasattr(self.app, 'update_status'):
            self.app.update_status(f"警告: {message}")
        return None

    def askyesno(self, title, message):
        log_message("QUESTION", f"{title}: {message} (默认: 是)")
        return True

# 课程编辑对话框类
class CourseEditDialog(BoxLayout):
    def __init__(self, parent, course_data=None, is_new=True, **kwargs):
        super().__init__(**kwargs)
        self.parent = parent
        self.course_data = course_data or {}
        self.is_new = is_new
        self.result = None
        self.orientation = 'vertical'
        self.spacing = 10
        self.padding = 20
        
        self.setup_ui()
        if not is_new:
            self.load_course_data()
        else:
            self.set_default_values()

    def setup_ui(self):
        """设置UI界面"""
        # 标题
        title_text = "编辑课程" if not self.is_new else "添加课程"
        title_label = Label(
            text=title_text,
            font_size=20,
            bold=True,
            size_hint_y=None,
            height=40,
            font_name=FONT_NAME
        )
        self.add_widget(title_label)

        # 课程名称
        self.name_input = self.create_field("课程名称", "name")
        
        # 教师
        self.teacher_input = self.create_field("教师", "teacher")
        
        # 地点
        self.place_input = self.create_field("地点", "place")
        
        # 星期选择
        week_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=40)
        week_layout.add_widget(Label(text="星期:", font_name=FONT_NAME))
        self.day_spinner = Spinner(
            text='星期一',
            values=('星期一', '星期二', '星期三', '星期四', '星期五'),
            size_hint=(None, None),
            size=(100, 40),
            pos_hint={'center_x': .5, 'center_y': .5}
        )
        week_layout.add_widget(self.day_spinner)
        self.add_widget(week_layout)
        
        # 时间选择
        time_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=40)
        time_layout.add_widget(Label(text="时间:", font_name=FONT_NAME))
        self.time_spinner = Spinner(
            text='第1节',
            values=('第1节', '第2节', '第3节', '第4节', '第5节', '第6节', '第7节', '第8节', '第9节', '第10节', '第11节', '第12节'),
            size_hint=(None, None),
            size=(100, 40),
            pos_hint={'center_x': .5, 'center_y': .5}
        )
        time_layout.add_widget(self.time_spinner)
        self.add_widget(time_layout)
        
        # 周次
        self.week_input = self.create_field("周次", "week")
        
        # 学期
        self.term_input = self.create_field("学期", "term")
        
        # 按钮
        button_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=50, spacing=10)
        
        save_btn = Button(
            text="保存",
            background_color=(0.2, 0.6, 0.86, 1),
            color=(1, 1, 1, 1),
            font_name=FONT_NAME
        )
        save_btn.bind(on_press=self.save_course)
        
        cancel_btn = Button(
            text="取消",
            background_color=(0.8, 0.8, 0.8, 1),
            color=(0.3, 0.3, 0.3, 1),
            font_name=FONT_NAME
        )
        cancel_btn.bind(on_press=self.cancel)
        
        button_layout.add_widget(save_btn)
        button_layout.add_widget(cancel_btn)
        self.add_widget(button_layout)

    def create_field(self, label_text, field_name):
        """创建输入字段"""
        field_layout = BoxLayout(orientation='vertical', size_hint_y=None, height=60)
        
        label = Label(
            text=label_text,
            size_hint_y=None,
            height=20,
            font_name=FONT_NAME
        )
        field_layout.add_widget(label)
        
        text_input = TextInput(
            multiline=False,
            size_hint_y=None,
            height=35,
            font_name=FONT_NAME
        )
        field_layout.add_widget(text_input)
        
        self.add_widget(field_layout)
        return text_input

    def set_default_values(self):
        """设置默认值"""
        self.name_input.text = ""
        self.teacher_input.text = ""
        self.place_input.text = ""
        self.day_spinner.text = "星期一"
        self.time_spinner.text = "第1节"
        self.week_input.text = str(self.parent.current_week)
        self.term_input.text = "2024-2025学年第一学期"

    def load_course_data(self):
        """加载课程数据"""
        self.name_input.text = str(self.course_data.get('name', ''))
        self.teacher_input.text = str(self.course_data.get('teacher', ''))
        self.place_input.text = str(self.course_data.get('place', ''))
        
        day_mapping = {0: '星期一', 1: '星期二', 2: '星期三', 3: '星期四', 4: '星期五'}
        day_value = self.course_data.get('day', 0)
        if isinstance(day_value, str):
            try:
                day_value = int(day_value)
            except ValueError:
                day_value = 0
        self.day_spinner.text = day_mapping.get(day_value, '星期一')
        
        self.time_spinner.text = str(self.course_data.get('time', '第1节'))
        self.week_input.text = str(self.course_data.get('week', self.parent.current_week))
        self.term_input.text = str(self.course_data.get('term', '2024-2025学年第一学期'))

    def save_course(self, instance):
        """保存课程"""
        try:
            if not DB_AVAILABLE:
                self.parent.messagebox.showerror("错误", "数据库功能不可用！")
                return

            # 获取输入数据
            course_name = self.name_input.text.strip()
            teacher = self.teacher_input.text.strip()
            place = self.place_input.text.strip()
            
            # 转换星期
            day_mapping = {'星期一': 0, '星期二': 1, '星期三': 2, '星期四': 3, '星期五': 4}
            day = day_mapping.get(self.day_spinner.text, 0)
            
            time_slot = self.time_spinner.text
            week = self.week_input.text.strip()
            term = self.term_input.text.strip()

            # 验证数据
            if not course_name:
                self.parent.messagebox.showerror("错误", "请输入课程名称！")
                return

            if not teacher:
                self.parent.messagebox.showerror("错误", "请输入教师姓名！")
                return

            if not place:
                self.parent.messagebox.showerror("错误", "请输入上课地点！")
                return

            # 转换周次为整数
            try:
                week_int = int(week)
            except ValueError:
                self.parent.messagebox.showerror("错误", "周次必须是数字！")
                return

            # 保存到数据库
            success = insert_into_table(course_name, place, time_slot, week_int, teacher, str(day), term)
            
            if success:
                self.parent.messagebox.showinfo("成功", "课程添加成功！")
                if hasattr(self, 'popup'):
                    self.popup.dismiss()
                self.parent.load_courses()
            else:
                self.parent.messagebox.showerror("错误", "保存失败！")

        except Exception as e:
            error_msg = f"保存失败：{str(e)}"
            log_message("ERROR", error_msg)
            self.parent.messagebox.showerror("错误", error_msg)

    def cancel(self, instance):
        """取消操作"""
        if hasattr(self, 'popup'):
            self.popup.dismiss()

class SmartTimetableApp(App):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.courses = []
        self.current_week = 1
        self.reminder_thread = None
        self.reminder_running = False
        self.messagebox = StatusMessageBox(self)
        
        # 启动提醒线程
        self.start_reminder_thread()
        
        log_message("INFO", "智能课表系统启动")

    def start_reminder_thread(self):
        """启动提醒线程"""
        if not self.reminder_running:
            self.reminder_running = True
            self.reminder_thread = threading.Thread(target=self.reminder_worker, daemon=True)
            self.reminder_thread.start()
            log_message("INFO", "课程提醒线程已启动")

    def stop_reminder_thread(self):
        """停止提醒线程"""
        self.reminder_running = False
        if self.reminder_thread:
            self.reminder_thread.join(timeout=1)
        log_message("INFO", "课程提醒线程已停止")

    def reminder_worker(self):
        """提醒工作线程"""
        while self.reminder_running:
            try:
                now = datetime.now()
                current_time = now.strftime("%H:%M")
                current_weekday = now.weekday()  # 0=周一, 6=周日
                
                # 检查是否有课程提醒
                for course in self.courses:
                    if (course.get('time', '').startswith('第') and 
                        course.get('day', 0) == current_weekday):
                        # 简单的提醒逻辑
                        self.show_system_notification("课程提醒", f"即将上课：{course.get('name', '')}")
                
                time.sleep(60)  # 每分钟检查一次
            except Exception as e:
                print(f"提醒线程错误: {e}")
                time.sleep(60)

    def update_status(self, message, is_error=False, duration=3000):
        """更新状态栏"""
        try:
            if hasattr(self, 'status_label'):
                self.status_label.text = message
                if is_error:
                    self.status_label.color = (1, 0, 0, 1)  # 红色
                else:
                    self.status_label.color = (0, 0, 0, 1)  # 黑色
                
                # 3秒后清除状态
                Clock.schedule_once(lambda dt: self.clear_status(), duration)
        except Exception as e:
            print(f"状态更新失败: {e}")

    def clear_status(self):
        """清除状态栏"""
        if hasattr(self, 'status_label'):
            self.status_label.text = ""

    def build(self):
        """构建主界面"""
        main_layout = BoxLayout(orientation='vertical')
        # 顶部按钮栏
        top_bar = BoxLayout(orientation='horizontal', size_hint_y=None, height=dp(48), spacing=dp(8), padding=[dp(8), dp(4), dp(8), dp(4)])
        self.prev_button = Button(text="上周", size_hint_x=None, width=dp(100))
        self.next_button = Button(text="下周", size_hint_x=None, width=dp(100))
        self.week_label = Label(text=f"第{getattr(self, 'current_week', 1)}周", font_size=dp(18), size_hint_x=1, halign='center', valign='middle')
        self.week_label.bind(size=lambda instance, value: setattr(instance, 'text_size', instance.size))
        top_bar.add_widget(self.prev_button)
        top_bar.add_widget(self.week_label)
        top_bar.add_widget(self.next_button)
        main_layout.add_widget(top_bar)
        # 课表区域
        self.course_area = BoxLayout(orientation='vertical')
        main_layout.add_widget(self.course_area)
        # 绑定按钮事件
        self.prev_button.bind(on_release=self.prev_week)
        self.next_button.bind(on_release=self.next_week)
        # 创建课表
        self.create_course_list(self.course_area)
        # 加载课程
        Clock.schedule_once(self.load_courses, 0.5)
        return main_layout

    def create_course_list(self, parent):
        """创建美化后的周历课程表格（八色底，黑色字体，黑色网格，固定行高，单元格内容垂直居中，空白单元格留白，行间无空隙）"""
        color_blocks = [
            (0.95, 0.95, 0.95, 1),  # 灰白
            (0.93, 0.98, 0.96, 1),  # 浅绿
            (0.98, 0.97, 0.93, 1),  # 浅黄
            (0.96, 0.94, 0.98, 1),  # 浅紫
            (0.98, 0.96, 0.93, 1),  # 浅橙
            (0.93, 0.96, 0.98, 1),  # 浅蓝
            (0.98, 0.93, 0.93, 1),  # 浅粉
            (0.94, 0.98, 0.93, 1),  # 浅青
        ]
        table_layout = GridLayout(cols=1, size_hint_y=None, spacing=0, row_default_height=dp(48), row_force_default=True)
        table_layout.bind(minimum_height=table_layout.setter('height'))
        # 表头
        header = GridLayout(cols=6, size_hint_y=None, height=dp(48), spacing=0)
        empty_cell = BoxLayout(size_hint_x=None, width=dp(60))
        def draw_bg(instance, value):
            instance.canvas.before.clear()
            with instance.canvas.before:
                Color(*color_blocks[0])
                Rectangle(pos=instance.pos, size=instance.size)
                Color(0, 0, 0, 1)
                Rectangle(pos=instance.pos, size=(instance.width, 1))
                Rectangle(pos=instance.pos, size=(1, instance.height))
                Rectangle(pos=(instance.x + instance.width - 1, instance.y), size=(1, instance.height))
                Rectangle(pos=(instance.x, instance.y + instance.height - 1), size=(instance.width, 1))
        empty_cell.bind(pos=draw_bg, size=draw_bg)
        draw_bg(empty_cell, None)
        header.add_widget(empty_cell)
        days_cn = ["周一", "周二", "周三", "周四", "周五"]
        for idx, day in enumerate(days_cn):
            day_cell = BoxLayout()
            def make_draw_bg(cell, color):
                def _draw(instance, value):
                    instance.canvas.before.clear()
                    with instance.canvas.before:
                        Color(*color)
                        Rectangle(pos=instance.pos, size=instance.size)
                        Color(0, 0, 0, 1)
                        Rectangle(pos=instance.pos, size=(instance.width, 1))
                        Rectangle(pos=instance.pos, size=(1, instance.height))
                        Rectangle(pos=(instance.x + instance.width - 1, instance.y), size=(1, instance.height))
                        Rectangle(pos=(instance.x, instance.y + instance.height - 1), size=(instance.width, 1))
                return _draw
            day_cell.bind(pos=make_draw_bg(day_cell, color_blocks[(idx+1)%8]), size=make_draw_bg(day_cell, color_blocks[(idx+1)%8]))
            make_draw_bg(day_cell, color_blocks[(idx+1)%8])(day_cell, None)
            day_label = Label(
                text=day,
                font_name=FONT_NAME,
                bold=True,
                color=(0, 0, 0, 1),
                font_size=dp(18)
            )
            day_cell.add_widget(day_label)
            header.add_widget(day_cell)
        table_layout.add_widget(header)
        # 课程表格
        self.grid_cells = []
        for i in range(1, 14):
            row = GridLayout(cols=6, size_hint_y=None, height=dp(48), spacing=0)
            # 节次列
            period_cell = BoxLayout(size_hint_x=None, width=dp(60))
            period_cell.bind(pos=draw_bg, size=draw_bg)
            draw_bg(period_cell, None)
            period_label = Label(
                text=f"第{i}节",
                font_name=FONT_NAME,
                bold=True,
                color=(0, 0, 0, 1),
                font_size=dp(16)
            )
            period_cell.add_widget(period_label)
            row.add_widget(period_cell)
            # 5天
            cell_row = []
            for j in range(5):
                # cell自动填满row，内容垂直居中
                cell = BoxLayout(orientation='vertical', padding=0, spacing=0, size_hint_y=1)
                def make_cell_bg(instance, value, color=color_blocks[(j+1)%8]):
                    instance.canvas.before.clear()
                    with instance.canvas.before:
                        Color(*color)
                        Rectangle(pos=instance.pos, size=instance.size)
                        Color(0, 0, 0, 1)
                        Rectangle(pos=instance.pos, size=(instance.width, 1))
                        Rectangle(pos=instance.pos, size=(1, instance.height))
                        Rectangle(pos=(instance.x + instance.width - 1, instance.y), size=(1, instance.height))
                        Rectangle(pos=(instance.x, instance.y + instance.height - 1), size=(instance.width, 1))
                cell.bind(pos=lambda inst, val, c=color_blocks[(j+1)%8]: make_cell_bg(inst, val, c), size=lambda inst, val, c=color_blocks[(j+1)%8]: make_cell_bg(inst, val, c))
                make_cell_bg(cell, None, color_blocks[(j+1)%8])
                row.add_widget(cell)
                cell_row.append(cell)
            self.grid_cells.append(cell_row)
            table_layout.add_widget(row)
        parent.clear_widgets()
        scroll_view = ScrollView(size_hint=(1, 1))
        scroll_view.add_widget(table_layout)
        parent.add_widget(scroll_view)

    def load_courses(self, instance=None):
        """加载课程数据并填充到美化后的周历表格，单元格只显示一行课程信息，切换周功能可用"""
        try:
            if not DB_AVAILABLE:
                self.update_status("数据库功能不可用 - 使用示例数据", is_error=True)
                self.load_sample_data()
                return
            self.update_status(f"正在加载第{self.current_week}周课程数据...")
            # 清空所有单元格
            for row in getattr(self, 'grid_cells', []):
                for cell in row:
                    cell.clear_widgets()
            self.courses = self.get_courses_by_week(self.current_week)
            # 构建每个cell的课程信息（合并为一行）
            cell_course_map = [[[] for _ in range(5)] for _ in range(13)]
            if self.courses:
                for course in self.courses:
                    try:
                        day = int(course.get('day', 0))
                        time_str = course.get('time', '第1节')
                        # 解析节次，支持"第X节"、"X"、"X-Y"
                        period_list = []
                        if isinstance(time_str, str):
                            s = time_str.replace('第', '').replace('节', '')
                            if '-' in s:
                                start, end = s.split('-')
                                start, end = int(start), int(end)
                                period_list = list(range(start-1, end))
                            else:
                                period_list = [int(s)-1]
                        else:
                            period_list = [int(time_str)-1]
                        for period in period_list:
                            if 0 <= day < 5 and 0 <= period < 13:
                                info = f"{course.get('name', '')} {course.get('teacher', '')} | {course.get('location', '')}"
                                cell_course_map[period][day].append(info)
                    except Exception as e:
                        print(f"填充课程到表格出错: {e}")
            # 填充到表格，每cell只显示一行
            for period in range(13):
                for day in range(5):
                    cell = self.grid_cells[period][day]
                    infos = cell_course_map[period][day]
                    if infos:
                        text = infos[0]  # 只显示第一门课
                        info_label = Label(
                            text=text,
                            font_size=dp(14),
                            color=(0, 0, 0, 1),
                            font_name=FONT_NAME,
                            halign='center',
                            valign='middle',
                            size_hint=(1, 1),
                            shorten=True,
                            max_lines=1,
                            text_size=(None, None)
                        )
                        def update_text_size(instance, value):
                            instance.text_size = instance.size
                        info_label.bind(size=update_text_size)
                        cell.add_widget(info_label)
            self.update_status(f"成功加载第{self.current_week}周 {len(self.courses) if self.courses else 0} 门课程")
            log_message("INFO", f"课程加载完成，第{self.current_week}周，共 {len(self.courses) if self.courses else 0} 门课程")
        except Exception as e:
            error_msg = f"加载课程失败: {str(e)}"
            log_message("ERROR", error_msg)
            self.update_status(error_msg, is_error=True)

    def get_courses_by_week(self, week):
        """获取指定周的课程"""
        try:
            if not DB_AVAILABLE:
                return []
            
            all_courses = []
            table_names = get_all_table_names()
            
            for table_name in table_names:
                # 跳过系统表
                if table_name.lower() in ['course_schedule', 'courses', 'system_config']:
                    continue
                    
                try:
                    conn = get_db_connection()
                    if conn:
                        cursor = conn.cursor()
                        # 检查表结构
                        cursor.execute(f"DESCRIBE `{table_name}`")
                        columns = [col[0] for col in cursor.fetchall()]
                        
                        # 根据表结构构建查询
                        if 'week' in columns:
                            cursor.execute(f"SELECT * FROM `{table_name}` WHERE week = %s", (week,))
                        else:
                            # 如果没有week字段，获取所有记录
                            cursor.execute(f"SELECT * FROM `{table_name}`")
                            
                        records = cursor.fetchall()
                        
                        for record in records:
                            course = {
                                'id': record[0],
                                'name': table_name,
                                'teacher': record[4] if len(record) > 4 else '',
                                'location': record[1] if len(record) > 1 else '',
                                'day': record[5] if len(record) > 5 else 0,
                                'time': record[2] if len(record) > 2 else '',
                                'week': record[3] if len(record) > 3 else 1,
                                'term': record[6] if len(record) > 6 else '',
                                'weeks': [week]
                            }
                            all_courses.append(course)
                        
                        cursor.close()
                        conn.close()
                        
                except Exception as e:
                    print(f"查询表 {table_name} 失败: {e}")
                    
            return all_courses
            
        except Exception as e:
            print(f"获取课程数据失败: {e}")
            return []

    def load_sample_data(self):
        """加载示例数据到美化后的周历表格"""
        for row in getattr(self, 'grid_cells', []):
            for cell in row:
                cell.clear_widgets()
        sample_courses = [
            {"name": "高等数学", "teacher": "张教授", "location": "教学楼A101", "time": "第1节", "week": 1, "day": 0, "term": "2024秋", "weeks": [1]},
            {"name": "大学英语", "teacher": "李老师", "location": "外语楼201", "time": "第3节", "week": 1, "day": 1, "term": "2024秋", "weeks": [1]},
            {"name": "计算机基础", "teacher": "王教授", "location": "计算机中心305", "time": "第5节", "week": 1, "day": 2, "term": "2024秋", "weeks": [1]},
            {"name": "物理实验", "teacher": "刘老师", "location": "物理楼实验室", "time": "第7节", "week": 1, "day": 3, "term": "2024秋", "weeks": [1]},
            {"name": "体育课", "teacher": "陈老师", "location": "体育馆", "time": "第9节", "week": 1, "day": 4, "term": "2024秋", "weeks": [1]},
            {"name": "大物实验", "teacher": "李四", "location": "实验楼", "time": "1-8", "week": 1, "day": 2, "term": "2024秋", "weeks": [1]},
            {"name": "晚自习", "teacher": "班主任", "location": "教室", "time": "9-12", "week": 1, "day": 0, "term": "2024秋", "weeks": [1]},
        ]
        self.courses = sample_courses
        for course in sample_courses:
            try:
                day = int(course.get('day', 0))
                time_str = course.get('time', '第1节')
                period_list = []
                if isinstance(time_str, str):
                    s = time_str.replace('第', '').replace('节', '')
                    if '-' in s:
                        start, end = s.split('-')
                        start, end = int(start), int(end)
                        period_list = list(range(start-1, end))
                    else:
                        period_list = [int(s)-1]
                else:
                    period_list = [int(time_str)-1]
                for period in period_list:
                    if 0 <= day < 5 and 0 <= period < 13:
                        cell = self.grid_cells[period][day]
                        card = BoxLayout(orientation='vertical', padding=[2, 1, 2, 1], size_hint_y=None, height=dp(36), spacing=1)
                        with card.canvas.before:
                            Color(1, 1, 1, 0.95)
                            Rectangle(pos=card.pos, size=card.size)
                            Color(0, 0, 0, 1)
                            Rectangle(pos=card.pos, size=(card.width, 1))
                            Rectangle(pos=card.pos, size=(1, card.height))
                            Rectangle(pos=(card.x + card.width - 1, card.y), size=(1, card.height))
                            Rectangle(pos=(card.x, card.y + card.height - 1), size=(card.width, 1))
                        name_label = Label(
                            text=course.get('name', ''),
                            font_size=dp(13),
                            bold=True,
                            color=(0, 0, 0, 1),
                            size_hint_y=None,
                            height=dp(16),
                            font_name=FONT_NAME
                        )
                        card.add_widget(name_label)
                        details_label = Label(
                            text=f"{course.get('teacher', '')} | {course.get('location', '')}",
                            font_size=dp(10),
                            color=(0, 0, 0, 1),
                            size_hint_y=None,
                            height=dp(14),
                            font_name=FONT_NAME
                        )
                        card.add_widget(details_label)
                        cell.add_widget(card)
            except Exception as e:
                print(f"填充示例课程到表格出错: {e}")

    def add_course(self, instance):
        """添加课程"""
        try:
            if not DB_AVAILABLE:
                self.messagebox.showerror("错误", "数据库功能不可用！")
                return

            default_data = {
                'id': -1,
                'name': '',
                'teacher': '',
                'place': '',
                'day': '0',
                'time': '第1节',
                'week': self.current_week,
                'term': '2024-2025学年第一学期'
            }
            self.show_course_dialog(default_data, is_new=True)

        except Exception as e:
            error_msg = f"添加课程失败: {str(e)}"
            log_message("ERROR", error_msg)
            self.update_status(error_msg, is_error=True)

    def show_course_dialog(self, course_data, is_new=True):
        """显示课程编辑对话框"""
        content = CourseEditDialog(self, course_data, is_new)
        popup = Popup(
            title="编辑课程" if not is_new else "添加课程",
            content=content,
            size_hint=(0.9, 0.8)
        )
        content.popup = popup
        popup.open()

    def prev_week(self, instance=None):
        if hasattr(self, 'current_week'):
            self.current_week = max(1, self.current_week - 1)
            if hasattr(self, 'week_label'):
                self.week_label.text = f"第{self.current_week}周"
            self.load_courses()

    def next_week(self, instance=None):
        if hasattr(self, 'current_week'):
            self.current_week = min(25, self.current_week + 1)
            if hasattr(self, 'week_label'):
                self.week_label.text = f"第{self.current_week}周"
            self.load_courses()

    def show_system_notification(self, title, message):
        """显示系统通知"""
        try:
            notification.notify(
                title=title,
                message=message,
                app_name="智能课表",
                timeout=10
            )
        except Exception as e:
            print("通知发送失败:", e)

    def on_stop(self):
        """应用停止时"""
        self.stop_reminder_thread()

if __name__ == '__main__':
    SmartTimetableApp().run() 