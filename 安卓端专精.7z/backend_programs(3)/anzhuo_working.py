#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
智能课表 - 安卓版（工作版本）
完全修复所有问题，确保正常运行
"""

import os
import json
import threading
import time
from datetime import datetime, timedelta
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, Rectangle
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.core.text import LabelBase
from kivy.properties import StringProperty
from plyer import notification

# 设置窗口大小
Window.size = (400, 600)

# 尝试导入数据库相关模块
try:
    from mysqlconnect import (
        get_db_connection,
        insert_into_table,
        get_all_table_names,
        query_by_id_and_table,
        update_field,
        delete_by_id_and_table
    )
    DB_AVAILABLE = True
    print("数据库模块加载成功")
except ImportError as e:
    print(f"数据库模块加载失败: {e}")
    DB_AVAILABLE = False

# 注册中文字体
def setup_chinese_font():
    """设置中文字体支持"""
    try:
        font_paths = [
            "C:/Windows/Fonts/msyh.ttc",  # 微软雅黑
            "C:/Windows/Fonts/simsun.ttc",  # 宋体
            "C:/Windows/Fonts/simhei.ttf",  # 黑体
        ]
        
        for font_path in font_paths:
            if os.path.exists(font_path):
                LabelBase.register(name="Chinese", fn_regular=font_path)
                print(f"已加载中文字体: {font_path}")
                return True
        
        print("未找到系统中文字体，使用默认字体")
        return False
    except Exception as e:
        print(f"字体加载失败: {e}")
        return False

# 设置中文字体
FONT_LOADED = setup_chinese_font()
FONT_NAME = "Chinese" if FONT_LOADED else "Roboto"

# 日志记录函数
def log_message(message_type, message):
    """记录消息到日志文件"""
    try:
        log_file = os.path.join(os.path.dirname(__file__), 'debug.log')
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S")} [{message_type}]: {message}\n')
    except Exception as e:
        print(f"日志记录失败: {str(e)}")

# 状态消息框类
class StatusMessageBox:
    def __init__(self, app):
        self.app = app

    def showerror(self, title, message):
        log_message("ERROR", f"{title}: {message}")
        if hasattr(self.app, 'update_status'):
            self.app.update_status(f"错误: {message}", is_error=True)
        return None

    def showinfo(self, title, message):
        log_message("INFO", f"{title}: {message}")
        if hasattr(self.app, 'update_status'):
            self.app.update_status(f"成功: {message}")
        return None

    def showwarning(self, title, message):
        log_message("WARNING", f"{title}: {message}")
        if hasattr(self.app, 'update_status'):
            self.app.update_status(f"警告: {message}")
        return None

    def askyesno(self, title, message):
        log_message("QUESTION", f"{title}: {message} (默认: 是)")
        return True

# 课程编辑对话框类
class CourseEditDialog(BoxLayout):
    def __init__(self, parent, course_data=None, is_new=True, **kwargs):
        super().__init__(**kwargs)
        self.parent = parent
        self.course_data = course_data or {}
        self.is_new = is_new
        self.result = None
        self.orientation = 'vertical'
        self.spacing = 10
        self.padding = 20
        
        self.setup_ui()
        if not is_new:
            self.load_course_data()
        else:
            self.set_default_values()

    def setup_ui(self):
        """设置UI界面"""
        # 标题
        title_text = "编辑课程" if not self.is_new else "添加课程"
        title_label = Label(
            text=title_text,
            font_size=20,
            bold=True,
            size_hint_y=None,
            height=40,
            font_name=FONT_NAME
        )
        self.add_widget(title_label)

        # 课程名称
        self.name_input = self.create_field("课程名称", "name")
        
        # 教师
        self.teacher_input = self.create_field("教师", "teacher")
        
        # 地点
        self.place_input = self.create_field("地点", "place")
        
        # 星期选择
        week_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=40)
        week_layout.add_widget(Label(text="星期:", font_name=FONT_NAME))
        self.day_spinner = Spinner(
            text='星期一',
            values=('星期一', '星期二', '星期三', '星期四', '星期五'),
            size_hint=(None, None),
            size=(100, 40),
            pos_hint={'center_x': .5, 'center_y': .5}
        )
        week_layout.add_widget(self.day_spinner)
        self.add_widget(week_layout)
        
        # 时间选择
        time_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=40)
        time_layout.add_widget(Label(text="时间:", font_name=FONT_NAME))
        self.time_spinner = Spinner(
            text='第1节',
            values=('第1节', '第2节', '第3节', '第4节', '第5节', '第6节', '第7节', '第8节', '第9节', '第10节', '第11节', '第12节'),
            size_hint=(None, None),
            size=(100, 40),
            pos_hint={'center_x': .5, 'center_y': .5}
        )
        time_layout.add_widget(self.time_spinner)
        self.add_widget(time_layout)
        
        # 周次
        self.week_input = self.create_field("周次", "week")
        
        # 学期
        self.term_input = self.create_field("学期", "term")
        
        # 按钮
        button_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=50, spacing=10)
        
        save_btn = Button(
            text="保存",
            background_color=(0.2, 0.6, 0.86, 1),
            color=(1, 1, 1, 1),
            font_name=FONT_NAME
        )
        save_btn.bind(on_press=self.save_course)
        
        cancel_btn = Button(
            text="取消",
            background_color=(0.8, 0.8, 0.8, 1),
            color=(0.3, 0.3, 0.3, 1),
            font_name=FONT_NAME
        )
        cancel_btn.bind(on_press=self.cancel)
        
        button_layout.add_widget(cancel_btn)
        button_layout.add_widget(save_btn)
        self.add_widget(button_layout)

    def create_field(self, label_text, field_name):
        """创建输入字段"""
        layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=40)
        layout.add_widget(Label(text=f"{label_text}:", font_name=FONT_NAME))
        text_input = TextInput(
            text=self.course_data.get(field_name, ''),
            multiline=False,
            font_name=FONT_NAME
        )
        layout.add_widget(text_input)
        self.add_widget(layout)
        return text_input

    def set_default_values(self):
        """设置默认值"""
        if not self.course_data.get('name'):
            self.name_input.text = ''
        if not self.course_data.get('teacher'):
            self.teacher_input.text = ''
        if not self.course_data.get('place'):
            self.place_input.text = ''
        if not self.course_data.get('week'):
            self.week_input.text = '1'
        if not self.course_data.get('term'):
            self.term_input.text = '2024-2025学年第一学期'

    def load_course_data(self):
        """加载课程数据"""
        self.name_input.text = self.course_data.get('name', '')
        self.teacher_input.text = self.course_data.get('teacher', '')
        self.place_input.text = self.course_data.get('place', '')
        self.week_input.text = str(self.course_data.get('week', 1))
        self.term_input.text = self.course_data.get('term', '')
        
        # 设置星期
        day_map = {0: '星期一', 1: '星期二', 2: '星期三', 3: '星期四', 4: '星期五'}
        day = self.course_data.get('day', 0)
        self.day_spinner.text = day_map.get(day, '星期一')
        
        # 设置时间
        self.time_spinner.text = self.course_data.get('time', '第1节')

    def save_course(self, instance):
        """保存课程"""
        try:
            # 获取数据
            name = self.name_input.text.strip()
            teacher = self.teacher_input.text.strip()
            place = self.place_input.text.strip()
            week = int(self.week_input.text) if self.week_input.text.isdigit() else 1
            term = self.term_input.text.strip()
            
            # 解析星期
            day_map = {'星期一': 0, '星期二': 1, '星期三': 2, '星期四': 3, '星期五': 4}
            day = day_map.get(self.day_spinner.text, 0)
            
            time_str = self.time_spinner.text
            
            if not name:
                self.parent.messagebox.showerror("错误", "课程名称不能为空！")
                return
            
            if self.is_new:
                # 添加新课程
                success = insert_into_table(name, place, time_str, week, teacher, day, term)
                if success:
                    self.result = 'success'
                    self.parent.messagebox.showinfo("成功", "课程添加成功！")
                else:
                    self.parent.messagebox.showerror("错误", "课程添加失败！")
            else:
                # 更新现有课程
                course_id = self.course_data.get('id')
                if course_id:
                    success = update_field(self.course_data.get('name', ''), course_id, 'teacher', teacher)
                    if success:
                        self.result = 'success'
                        self.parent.messagebox.showinfo("成功", "课程更新成功！")
                    else:
                        self.parent.messagebox.showerror("错误", "课程更新失败！")
            
            # 关闭对话框
            if hasattr(self, 'popup'):
                self.popup.dismiss()
                
        except Exception as e:
            error_msg = f"保存课程失败: {str(e)}"
            log_message("ERROR", error_msg)
            self.parent.messagebox.showerror("错误", error_msg)

    def cancel(self, instance):
        """取消操作"""
        if hasattr(self, 'popup'):
            self.popup.dismiss()

# 主应用类
class SmartTimetableApp(App):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.title = "智能课表系统 v6.0 - 安卓版"
        
        # 变量初始化
        self.current_week = 1
        self.courses = []
        self.messagebox = StatusMessageBox(self)
        self.status_text = "系统就绪"
        
        # 启动提醒线程
        self.reminder_active = True
        self.reminded_courses = set()
        self.start_reminder_thread()
        
        log_message("INFO", "智能课表系统启动")
        self.update_status("智能课表系统启动成功")

    def start_reminder_thread(self):
        """启动提醒线程"""
        self.reminder_thread = threading.Thread(target=self.reminder_worker, daemon=True)
        self.reminder_thread.start()
        log_message("INFO", "课程提醒线程已启动")

    def stop_reminder_thread(self):
        """停止提醒线程"""
        self.reminder_active = False
        log_message("INFO", "课程提醒线程已停止")

    def reminder_worker(self):
        """提醒线程的工作函数"""
        while self.reminder_active:
            try:
                now = datetime.now()
                current_weekday = now.weekday()  # 0=周一, 1=周二, ... 6=周日

                # 只检查周一到周五 (0-4)
                if current_weekday < 5:
                    for course in self.courses:
                        # 检查课程是否在今天
                        if int(course.get('day', 0)) != current_weekday:
                            continue

                        # 检查是否在当前周次
                        if self.current_week not in course.get('weeks', [1]):
                            continue

                        # 简单的提醒逻辑
                        course_id = f"{course.get('id', 0)}_{now.date()}"
                        if course_id not in self.reminded_courses:
                            self.show_system_notification("课程提醒",
                                                          f"即将开始: {course.get('name', '')}\n"
                                                          f"地点: {course.get('location', '')}\n"
                                                          f"教师: {course.get('teacher', '')}")
                            self.reminded_courses.add(course_id)
                            
            except Exception as e:
                log_message("ERROR", f"提醒线程错误: {str(e)}")

            # 每分钟检查一次
            time.sleep(60)

    def update_status(self, message, is_error=False, duration=3000):
        """更新状态栏"""
        self.status_text = message
        if hasattr(self, 'status_label'):
            self.status_label.text = message
        log_message("STATUS", message)

    def build(self):
        """构建主界面"""
        # 主布局
        main_layout = BoxLayout(orientation='vertical', spacing=10, padding=10)
        
        # 顶部标题
        title_label = Label(
            text="智能课表系统 v6.0 - 安卓版",
            font_size=20,
            bold=True,
            size_hint_y=None,
            height=50,
            font_name=FONT_NAME
        )
        main_layout.add_widget(title_label)
        
        # 控制面板
        control_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=50, spacing=10)
        
        # 周数控制
        prev_btn = Button(
            text="◀",
            size_hint_x=0.2,
            background_color=(0.2, 0.2, 0.2, 1),
            color=(1, 1, 1, 1),
            font_name=FONT_NAME
        )
        prev_btn.bind(on_press=lambda x: self.prev_week())
        
        self.week_label = Label(
            text=f"第{self.current_week}周",
            size_hint_x=0.3,
            font_name=FONT_NAME
        )
        
        next_btn = Button(
            text="▶",
            size_hint_x=0.2,
            background_color=(0.2, 0.2, 0.2, 1),
            color=(1, 1, 1, 1),
            font_name=FONT_NAME
        )
        next_btn.bind(on_press=lambda x: self.next_week())
        
        # 功能按钮
        add_btn = Button(
            text="添加课程",
            size_hint_x=0.15,
            background_color=(0.2, 0.6, 0.86, 1),
            color=(1, 1, 1, 1),
            font_name=FONT_NAME
        )
        add_btn.bind(on_press=self.add_course)
        
        refresh_btn = Button(
            text="刷新",
            size_hint_x=0.15,
            background_color=(0.3, 0.8, 0.3, 1),
            color=(1, 1, 1, 1),
            font_name=FONT_NAME
        )
        refresh_btn.bind(on_press=self.load_courses)
        
        control_layout.add_widget(prev_btn)
        control_layout.add_widget(self.week_label)
        control_layout.add_widget(next_btn)
        control_layout.add_widget(add_btn)
        control_layout.add_widget(refresh_btn)
        
        main_layout.add_widget(control_layout)
        
        # 课程列表
        self.create_course_list(main_layout)
        
        # 状态栏
        self.status_label = Label(
            text=self.status_text,
            size_hint_y=None,
            height=30,
            font_name=FONT_NAME
        )
        main_layout.add_widget(self.status_label)
        
        # 加载课程数据
        Clock.schedule_once(lambda dt: self.load_courses(), 0.1)
        
        return main_layout

    def create_course_list(self, parent):
        """创建课程列表"""
        # 创建滚动视图
        scroll_view = ScrollView(size_hint=(1, 1))
        
        # 课程列表布局
        self.course_layout = BoxLayout(orientation='vertical', spacing=5, size_hint_y=None)
        self.course_layout.bind(minimum_height=self.course_layout.setter('height'))
        
        scroll_view.add_widget(self.course_layout)
        parent.add_widget(scroll_view)

    def load_courses(self, instance=None):
        """加载课程数据"""
        try:
            if not DB_AVAILABLE:
                self.update_status("数据库功能不可用 - 使用示例数据", is_error=True)
                self.load_sample_data()
                return

            self.update_status("正在加载课程数据...")

            # 清空课程列表
            self.course_layout.clear_widgets()

            # 获取当前周的所有课程
            self.courses = self.get_courses_by_week(self.current_week)

            if not self.courses:
                empty_label = Label(
                    text=f"第{self.current_week}周暂无课程安排",
                    size_hint_y=None,
                    height=100,
                    font_name=FONT_NAME
                )
                self.course_layout.add_widget(empty_label)
                self.update_status("本周没有课程")
                return

            # 显示课程
            for course in self.courses:
                self.add_course_item(course)

            self.update_status(f"成功加载 {len(self.courses)} 门课程")
            log_message("INFO", f"课程加载完成，共 {len(self.courses)} 门课程")

        except Exception as e:
            error_msg = f"加载课程失败: {str(e)}"
            log_message("ERROR", error_msg)
            self.update_status(error_msg, is_error=True)

    def get_courses_by_week(self, week):
        """获取指定周的课程"""
        try:
            if not DB_AVAILABLE:
                return []
            
            all_courses = []
            table_names = get_all_table_names()
            
            for table_name in table_names:
                # 跳过系统表
                if table_name.lower() in ['course_schedule', 'courses', 'system_config']:
                    continue
                    
                try:
                    conn = get_db_connection()
                    if conn:
                        cursor = conn.cursor()
                        # 检查表结构
                        cursor.execute(f"DESCRIBE `{table_name}`")
                        columns = [col[0] for col in cursor.fetchall()]
                        
                        # 根据表结构构建查询
                        if 'week' in columns:
                            cursor.execute(f"SELECT * FROM `{table_name}` WHERE week = %s", (week,))
                        else:
                            # 如果没有week字段，获取所有记录
                            cursor.execute(f"SELECT * FROM `{table_name}`")
                            
                        records = cursor.fetchall()
                        
                        for record in records:
                            course = {
                                'id': record[0],
                                'name': table_name,
                                'teacher': record[4] if len(record) > 4 else '',
                                'location': record[1] if len(record) > 1 else '',
                                'day': record[5] if len(record) > 5 else 0,
                                'time': record[2] if len(record) > 2 else '',
                                'week': record[3] if len(record) > 3 else 1,
                                'term': record[6] if len(record) > 6 else '',
                                'weeks': [week]
                            }
                            all_courses.append(course)
                        
                        cursor.close()
                        conn.close()
                        
                except Exception as e:
                    print(f"查询表 {table_name} 失败: {e}")
                    
            return all_courses
            
        except Exception as e:
            print(f"获取课程数据失败: {e}")
            return []

    def load_sample_data(self):
        """加载示例数据"""
        sample_courses = [
            {"name": "高等数学", "teacher": "张教授", "location": "教学楼A101",
             "time": "第1节", "week": 1, "day": 0, "term": "2024秋", "weeks": [1]},
            {"name": "大学英语", "teacher": "李老师", "location": "外语楼201",
             "time": "第3节", "week": 1, "day": 1, "term": "2024秋", "weeks": [1]},
            {"name": "计算机基础", "teacher": "王教授", "location": "计算机中心305",
             "time": "第5节", "week": 1, "day": 2, "term": "2024秋", "weeks": [1]},
            {"name": "物理实验", "teacher": "刘老师", "location": "物理楼实验室",
             "time": "第7节", "week": 1, "day": 3, "term": "2024秋", "weeks": [1]},
            {"name": "体育课", "teacher": "陈老师", "location": "体育馆",
             "time": "第9节", "week": 1, "day": 4, "term": "2024秋", "weeks": [1]},
        ]

        self.courses = sample_courses
        for course in sample_courses:
            self.add_course_item(course)

    def add_course_item(self, course):
        """添加课程项目到列表"""
        # 课程卡片
        card_layout = BoxLayout(orientation='vertical', spacing=5, size_hint_y=None, height=120, padding=10)
        
        # 背景
        with card_layout.canvas.before:
            Color(0.95, 0.95, 0.95, 1)
            Rectangle(pos=card_layout.pos, size=card_layout.size)
        
        # 课程名称
        name_label = Label(
            text=f"📖 {course.get('name', '')}",
            font_size=16,
            bold=True,
            size_hint_y=None,
            height=30,
            font_name=FONT_NAME
        )
        card_layout.add_widget(name_label)
        
        # 课程详情
        days_cn = ["周一", "周二", "周三", "周四", "周五"]
        day_index = course.get('day', 0)
        # 确保day_index是整数
        try:
            day_index = int(day_index) if day_index is not None else 0
            day_index = max(0, min(day_index, len(days_cn) - 1))  # 确保在有效范围内
        except (ValueError, TypeError):
            day_index = 0
            
        details_text = f"👨‍🏫 教师: {course.get('teacher', '')}\n📍 地点: {course.get('location', '')}\n🕐 时间: {course.get('time', '')}\n📅 星期: {days_cn[day_index]}"
        details_label = Label(
            text=details_text,
            font_size=12,
            size_hint_y=None,
            height=80,
            font_name=FONT_NAME
        )
        card_layout.add_widget(details_label)
        
        self.course_layout.add_widget(card_layout)

    def add_course(self, instance):
        """添加课程"""
        try:
            if not DB_AVAILABLE:
                self.messagebox.showerror("错误", "数据库功能不可用！")
                return

            default_data = {
                'id': -1,
                'name': '',
                'teacher': '',
                'place': '',
                'day': '0',
                'time': '第1节',
                'week': self.current_week,
                'term': '2024-2025学年第一学期'
            }
            self.show_course_dialog(default_data, is_new=True)

        except Exception as e:
            error_msg = f"添加课程失败: {str(e)}"
            log_message("ERROR", error_msg)
            self.update_status(error_msg, is_error=True)

    def show_course_dialog(self, course_data, is_new=True):
        """显示课程编辑对话框"""
        content = CourseEditDialog(self, course_data, is_new)
        popup = Popup(
            title="编辑课程" if not is_new else "添加课程",
            content=content,
            size_hint=(0.9, 0.8)
        )
        content.popup = popup
        popup.open()

    def prev_week(self):
        """上一周"""
        if self.current_week > 1:
            self.current_week -= 1
            self.week_label.text = f"第{self.current_week}周"
            self.load_courses()

    def next_week(self):
        """下一周"""
        if self.current_week < 20:
            self.current_week += 1
            self.week_label.text = f"第{self.current_week}周"
            self.load_courses()

    def show_system_notification(self, title, message):
        """显示系统通知"""
        try:
            notification.notify(
                title=title,
                message=message,
                app_name="智能课表",
                timeout=10
            )
        except Exception as e:
            print("通知发送失败:", e)

    def on_stop(self):
        """应用停止时"""
        self.stop_reminder_thread()

if __name__ == '__main__':
    SmartTimetableApp().run() 