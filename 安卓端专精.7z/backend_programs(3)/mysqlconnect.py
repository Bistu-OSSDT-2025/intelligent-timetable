#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
智能课表 - 数据库连接模块
提供MySQL数据库连接和操作功能
兼容安卓端和桌面端
"""

import pymysql
import logging
import os
from datetime import datetime

# 设置日志配置
def setup_logging():
    """设置日志配置"""
    try:
        log_file = os.path.join(os.path.dirname(__file__), 'app.log')
        logging.basicConfig(
            filename=log_file,
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            encoding='utf-8'
        )
    except:
        pass

# 初始化日志
setup_logging()

def get_db_connection():
    """获取数据库连接"""
    try:
        return pymysql.connect(
            host='localhost',
            user='root',
            password='password',
            database='smart timetable',
            charset='utf8mb4'
        )
    except pymysql.Error as e:
        try:
            logging.error(f"数据库连接失败: {e}")
        except:
            pass
        return None

def check_table_exists(table_name):
    """检查表是否存在"""
    try:
        conn = get_db_connection()
        if conn is None:
            return False
        cursor = conn.cursor()
        cursor.execute(f"SHOW TABLES LIKE '{table_name}'")
        result = cursor.fetchone() is not None
        cursor.close()
        conn.close()
        return result
    except Exception as e:
        try:
            logging.error(f"检查表存在性失败: {e}")
        except:
            pass
        return False

def get_all_table_names():
    """获取所有表名"""
    try:
        conn = get_db_connection()
        if conn is None:
            return []
        cursor = conn.cursor()
        cursor.execute("SHOW TABLES")
        tables = [row[0] for row in cursor.fetchall()]
        cursor.close()
        conn.close()
        return tables
    except Exception as e:
        try:
            logging.error(f"获取表名失败: {e}")
        except:
            pass
        return []

def query_by_id_and_table(table_name, record_id):
    """根据ID和表名查询记录"""
    try:
        conn = get_db_connection()
        if conn is None:
            return None
        cursor = conn.cursor()
        cursor.execute(f"SELECT * FROM `{table_name}` WHERE id = %s", (record_id,))
        result = cursor.fetchone()
        cursor.close()
        conn.close()
        return result
    except Exception as e:
        try:
            logging.error(f"查询记录失败: {e}")
        except:
            pass
        return None

def update_field(table_name, record_id, field_name, new_value):
    """更新指定字段"""
    try:
        conn = get_db_connection()
        if conn is None:
            return False
        cursor = conn.cursor()
        sql = f"UPDATE `{table_name}` SET `{field_name}` = %s WHERE id = %s"
        cursor.execute(sql, (new_value, record_id))
        conn.commit()
        cursor.close()
        conn.close()
        try:
            logging.info(f"更新课程ID {record_id} 成功")
        except:
            pass
        return True
    except Exception as e:
        try:
            logging.error(f"更新字段失败: {e}")
        except:
            pass
        return False

def insert_into_table(table_name, place, time, week, teacher, day, term):
    """插入数据到指定课程表"""
    try:
        if not check_table_exists(table_name):
            # 创建新表
            create_table_sql = f"""
            CREATE TABLE `{table_name}` (
                id INT PRIMARY KEY AUTO_INCREMENT,
                place VARCHAR(255),
                time VARCHAR(255),
                week INT,
                teacher VARCHAR(255),
                day VARCHAR(255),
                term VARCHAR(255)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """
            conn = get_db_connection()
            if conn is None:
                return False
            cursor = conn.cursor()
            try:
                cursor.execute(create_table_sql)
                conn.commit()
                try:
                    logging.info(f"成功创建表 {table_name}")
                except:
                    pass
            except Exception as e:
                conn.rollback()
                try:
                    logging.error(f"创建表失败: {e}")
                except:
                    pass
                return False
            finally:
                cursor.close()
                conn.close()

        # 插入数据
        conn = get_db_connection()
        if conn is None:
            return False
        cursor = conn.cursor()
        sql = f"""
        INSERT INTO `{table_name}` (place, time, week, teacher, day, term) 
        VALUES (%s, %s, %s, %s, %s, %s)
        """
        data = (place, time, week, teacher, day, term)

        try:
            cursor.execute(sql, data)
            conn.commit()
            try:
                logging.info(f"成功插入课程: {table_name}")
            except:
                pass
            return True
        except Exception as e:
            conn.rollback()
            try:
                logging.error(f"插入失败: {e}")
            except:
                pass
            return False
        finally:
            cursor.close()
            conn.close()
    except Exception as e:
        try:
            logging.error(f"插入操作失败: {e}")
        except:
            pass
        return False

def delete_by_id_and_table(table_name, record_id):
    """根据ID和表名删除记录"""
    try:
        conn = get_db_connection()
        if conn is None:
            return False
        cursor = conn.cursor()
        cursor.execute(f"DELETE FROM `{table_name}` WHERE id = %s", (record_id,))
        conn.commit()
        cursor.close()
        conn.close()
        try:
            logging.info(f"删除课程ID: {record_id}")
        except:
            pass
        return True
    except Exception as e:
        try:
            logging.error(f"删除记录失败: {e}")
        except:
            pass
        return False

def delete_all_tables():
    """删除所有课程表"""
    try:
        conn = get_db_connection()
        if conn is None:
            return False
        cursor = conn.cursor()
        cursor.execute("SHOW TABLES")
        tables = [row[0] for row in cursor.fetchall()]
        
        for table in tables:
            if table.lower() not in ['course_schedule', 'courses']:
                cursor.execute(f"DROP TABLE `{table}`")
        
        conn.commit()
        cursor.close()
        conn.close()
        try:
            logging.info("删除所有课程成功")
        except:
            pass
        return True
    except Exception as e:
        try:
            logging.error(f"删除所有表失败: {e}")
        except:
            pass
        return False

# 初始化数据库
def init_database():
    """初始化数据库"""
    try:
        conn = get_db_connection()
        if conn is None:
            return False
        cursor = conn.cursor()
        
        # 创建主课程表（如果不存在）
        create_main_table_sql = """
        CREATE TABLE IF NOT EXISTS `course_schedule` (
            id INT PRIMARY KEY AUTO_INCREMENT,
            name VARCHAR(255) NOT NULL,
            teacher VARCHAR(255),
            location VARCHAR(255),
            day INT,
            start_time VARCHAR(10),
            end_time VARCHAR(10),
            weeks TEXT,
            reminder INT DEFAULT 15,
            term VARCHAR(50),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        """
        
        cursor.execute(create_main_table_sql)
        conn.commit()
        cursor.close()
        conn.close()
        
        try:
            logging.info("数据库初始化成功")
        except:
            pass
        return True
    except Exception as e:
        try:
            logging.error(f"数据库初始化失败: {e}")
        except:
            pass
        return False

# 程序启动时初始化数据库
if __name__ == "__main__":
    init_database() 