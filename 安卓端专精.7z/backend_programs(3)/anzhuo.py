from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.uix.popup import Popup
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, Rectangle, Line
from kivy.clock import Clock
from kivy.utils import platform
from kivy.core.window import Window
import requests
from plyer import notification
from datetime import datetime, timedelta
import threading
import json

# English database example with week information
ENGLISH_COURSES = [
    {
        "id": 1,
        "name": "Advanced Mathematics",
        "teacher": "Prof. Zhang",
        "location": "Building A101",
        "day": 0,  # Monday
        "start": "08:00",
        "end": "09:40",
        "reminder": 15,
        "weeks": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]  # Weeks the course is active
    },
    {
        "id": 2,
        "name": "College English",
        "teacher": "Ms. Li",
        "location": "Foreign Languages Bldg 203",
        "day": 1,  # Tuesday
        "start": "10:00",
        "end": "11:40",
        "reminder": 10,
        "weeks": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    },
    {
        "id": 3,
        "name": "Computer Fundamentals",
        "teacher": "Prof. Wang",
        "location": "Computer Center 305",
        "day": 2,  # Wednesday
        "start": "14:00",
        "end": "15:40",
        "reminder": 20,
        "weeks": [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
    },
    {
        "id": 4,
        "name": "Physics Lab",
        "teacher": "Prof. Zhao",
        "location": "Lab Building B102",
        "day": 3,  # Thursday
        "start": "08:00",
        "end": "09:40",
        "reminder": 15,
        "weeks": [1, 3, 5, 7, 9, 11, 13, 15]  # Alternate weeks
    },
    {
        "id": 5,
        "name": "Physical Education",
        "teacher": "Coach Liu",
        "location": "Gymnasium",
        "day": 4,  # Friday
        "start": "10:00",
        "end": "11:40",
        "reminder": 5,
        "weeks": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    }
]

# Set app theme colors
PRIMARY_COLOR = (0.2, 0.5, 0.8, 1)  # Blue
SECONDARY_COLOR = (0.9, 0.3, 0.3, 1)  # Red
ACCENT_COLOR = (0.2, 0.7, 0.3, 1)  # Green
BACKGROUND_COLOR = (0.95, 0.95, 0.95, 1)  # Light gray
CARD_COLOR = (1, 1, 1, 1)  # White
WEEK_ACTIVE_COLOR = (0.3, 0.7, 0.3, 1)  # Green for active week
WEEK_INACTIVE_COLOR = (0.8, 0.8, 0.8, 1)  # Gray for inactive week


class CourseForm(BoxLayout):
    def __init__(self, course=None, **kwargs):
        super().__init__(orientation='vertical', spacing=15, padding=20, **kwargs)
        self.course = course

        # Create English form fields
        self.name = TextInput(hint_text="Course Name", multiline=False, size_hint_y=None, height=45)
        self.teacher = TextInput(hint_text="Instructor Name", multiline=False, size_hint_y=None, height=45)
        self.location = TextInput(hint_text="Location", multiline=False, size_hint_y=None, height=45)

        self.day = Spinner(
            text="Select Day",
            values=("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"),
            size_hint_y=None, height=45
        )

        self.start = TextInput(hint_text="Start Time (HH:MM)", multiline=False, size_hint_y=None, height=45)
        self.end = TextInput(hint_text="End Time (HH:MM)", multiline=False, size_hint_y=None, height=45)
        self.reminder = TextInput(
            hint_text="Reminder Before (minutes)",
            input_filter='int',
            multiline=False,
            size_hint_y=None, height=45
        )

        # Add form fields with English labels
        self.add_widget(Label(text="Course Information", size_hint_y=None, height=30, bold=True, color=PRIMARY_COLOR))
        self.add_widget(self.name)
        self.add_widget(self.teacher)
        self.add_widget(self.location)

        self.add_widget(Label(text="Schedule", size_hint_y=None, height=30, bold=True, color=PRIMARY_COLOR))
        self.add_widget(self.day)

        time_layout = BoxLayout(spacing=10, size_hint_y=None, height=45)
        time_layout.add_widget(self.start)
        time_layout.add_widget(self.end)
        self.add_widget(time_layout)

        self.add_widget(
            Label(text="Notification Settings", size_hint_y=None, height=30, bold=True, color=PRIMARY_COLOR))
        self.add_widget(self.reminder)

        # Week selector for the course
        self.add_widget(Label(text="Active Weeks", size_hint_y=None, height=30, bold=True, color=PRIMARY_COLOR))
        self.week_layout = BoxLayout(orientation='horizontal', spacing=5, size_hint_y=None, height=40)
        self.week_buttons = []

        # Create buttons for 16 weeks (a typical semester)
        for week in range(1, 17):
            btn = Button(
                text=str(week),
                size_hint_x=None,
                width=30,
                background_normal='',
                background_color=WEEK_INACTIVE_COLOR,
                color=(0.2, 0.2, 0.2, 1),
                font_size=12
            )
            btn.bind(on_press=lambda instance, w=week: self.toggle_week(instance, w))
            self.week_layout.add_widget(btn)
            self.week_buttons.append(btn)

        self.add_widget(self.week_layout)

        if course:
            self.load_data()

    def toggle_week(self, button, week):
        if button.background_color == WEEK_INACTIVE_COLOR:
            button.background_color = WEEK_ACTIVE_COLOR
        else:
            button.background_color = WEEK_INACTIVE_COLOR

    def load_data(self):
        days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        self.name.text = self.course['name']
        self.teacher.text = self.course['teacher']
        self.location.text = self.course['location']
        self.day.text = days[self.course['day']]
        self.start.text = self.course['start']
        self.end.text = self.course['end']
        self.reminder.text = str(self.course['reminder'])

        # Set active weeks
        for i, btn in enumerate(self.week_buttons):
            week_num = i + 1
            if week_num in self.course.get('weeks', []):
                btn.background_color = WEEK_ACTIVE_COLOR
            else:
                btn.background_color = WEEK_INACTIVE_COLOR

    def get_data(self):
        # Get selected weeks
        active_weeks = []
        for i, btn in enumerate(self.week_buttons):
            if btn.background_color == WEEK_ACTIVE_COLOR:
                active_weeks.append(i + 1)

        return {
            'name': self.name.text,
            'teacher': self.teacher.text,
            'location': self.location.text,
            'day': self.day.values.index(self.day.text),
            'start': self.start.text,
            'end': self.end.text,
            'reminder': int(self.reminder.text) if self.reminder.text else 15,
            'weeks': active_weeks
        }


class CourseItem(BoxLayout):
    def __init__(self, course, main_app, **kwargs):
        super().__init__(orientation='horizontal', size_hint_y=None, height=70, spacing=10, padding=(10, 5))
        self.course = course
        self.main_app = main_app

        # Card-style background
        with self.canvas.before:
            # Color based on whether course is active in current week
            if self.main_app.current_week in course.get('weeks', []):
                Color(0.95, 0.95, 0.95, 1)  # Light background for active courses
            else:
                Color(0.9, 0.9, 0.9, 0.7)  # Semi-transparent for inactive courses

            self.rect = Rectangle(pos=self.pos, size=self.size)
            Color(0.8, 0.8, 0.8, 1)
            self.line = Line(points=[self.x, self.y, self.x + self.width, self.y], width=1)

        self.bind(pos=self.update_graphics, size=self.update_graphics)

        # Course information layout
        info_layout = BoxLayout(orientation='vertical', size_hint_x=0.7)

        # Course name and instructor
        name_layout = BoxLayout(size_hint_y=None, height=30)
        name_layout.add_widget(Label(
            text=f"[b]{course['name']}[/b]",
            markup=True,
            size_hint_x=0.7,
            halign='left',
            color=(0.2, 0.2, 0.2, 1)))
        name_layout.add_widget(Label(
            text=f"Instructor: [b]{course['teacher']}[/b]",
            markup=True,
            size_hint_x=0.3,
            halign='right',
            color=(0.4, 0.4, 0.4, 1)))
        info_layout.add_widget(name_layout)

        # Location and time
        detail_layout = BoxLayout(size_hint_y=None, height=30)
        detail_layout.add_widget(Label(
            text=f"Location: [b]{course['location']}[/b]",
            markup=True,
            size_hint_x=0.5,
            halign='left',
            color=(0.4, 0.4, 0.4, 1)))

        # Day display
        days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        day_label = Label(
            text=f"{days[course['day']]} {course['start']}-{course['end']}",
            size_hint_x=0.5,
            halign='right',
            color=(0.3, 0.3, 0.3, 1))
        detail_layout.add_widget(day_label)

        info_layout.add_widget(detail_layout)

        # Reminder information
        reminder_layout = BoxLayout(size_hint_y=None, height=30)
        reminder_layout.add_widget(Label(
            text=f"Reminder {course['reminder']} min before",
            color=(0.5, 0.5, 0.5, 1),
            size_hint_x=0.7,
            halign='left'))

        # Week indicator
        week_text = "Weeks: " + ", ".join(map(str, course.get('weeks', [])))
        week_label = Label(
            text=week_text,
            color=(0.5, 0.5, 0.5, 1),
            size_hint_x=0.3,
            halign='right',
            font_size=10)
        reminder_layout.add_widget(week_label)

        info_layout.add_widget(reminder_layout)

        self.add_widget(info_layout)

        # Action buttons
        btn_layout = BoxLayout(size_hint_x=0.3, spacing=10)

        edit_btn = Button(
            text="Edit",
            size_hint_x=0.5,
            background_normal='',
            background_color=PRIMARY_COLOR,
            color=(1, 1, 1, 1))
        edit_btn.bind(on_press=self.edit)
        btn_layout.add_widget(edit_btn)

        del_btn = Button(
            text="Delete",
            size_hint_x=0.5,
            background_normal='',
            background_color=SECONDARY_COLOR,
            color=(1, 1, 1, 1))
        del_btn.bind(on_press=self.delete)
        btn_layout.add_widget(del_btn)

        self.add_widget(btn_layout)

    def update_graphics(self, *args):
        self.rect.pos = self.pos
        self.rect.size = self.size
        self.line.points = [self.x, self.y, self.x + self.width, self.y]

    def edit(self, instance):
        self.main_app.show_form(self.course)

    def delete(self, instance):
        threading.Thread(target=self._delete).start()

    def _delete(self):
        # Simulate delete operation
        if self.course in self.main_app.courses:
            self.main_app.courses.remove(self.course)
        self.main_app.load_courses()


class TimetableApp(App):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.courses = ENGLISH_COURSES.copy()
        self.current_week = 1  # Default to week 1
        self.current_day = None

    def build(self):
        self.title = "Course Timetable"
        Window.clearcolor = BACKGROUND_COLOR
        self.layout = BoxLayout(orientation='vertical', spacing=10, padding=10)

        # Header
        header = BoxLayout(size_hint_y=None, height=70)
        with header.canvas.before:
            Color(*PRIMARY_COLOR)
            header.rect = Rectangle(pos=header.pos, size=header.size)

        header.bind(pos=self.update_header_rect, size=self.update_header_rect)

        header.add_widget(Label(
            text="My Course Schedule",
            font_size=28,
            bold=True,
            color=(1, 1, 1, 1))
        )
        self.layout.add_widget(header)

        # Week selector
        week_selector = BoxLayout(size_hint_y=None, height=50, spacing=10, padding=(10, 5))
        week_selector.add_widget(Label(
            text="Current Week:",
            size_hint_x=None,
            width=100,
            bold=True,
            color=PRIMARY_COLOR))

        # Week navigation buttons
        week_nav = BoxLayout(size_hint_x=0.4, spacing=5)

        prev_week_btn = Button(
            text="◀",
            size_hint_x=None,
            width=40,
            background_normal='',
            background_color=PRIMARY_COLOR,
            color=(1, 1, 1, 1))
        prev_week_btn.bind(on_press=lambda x: self.change_week(-1))
        week_nav.add_widget(prev_week_btn)

        self.week_label = Label(
            text=f"Week {self.current_week}",
            size_hint_x=None,
            width=100,
            bold=True,
            color=PRIMARY_COLOR,
            font_size=18)
        week_nav.add_widget(self.week_label)

        next_week_btn = Button(
            text="▶",
            size_hint_x=None,
            width=40,
            background_normal='',
            background_color=PRIMARY_COLOR,
            color=(1, 1, 1, 1))
        next_week_btn.bind(on_press=lambda x: self.change_week(1))
        week_nav.add_widget(next_week_btn)

        week_selector.add_widget(week_nav)

        # Week selector dropdown
        self.week_spinner = Spinner(
            text=str(self.current_week),
            values=[str(i) for i in range(1, 17)],
            size_hint_x=0.2,
            background_normal='',
            background_color=ACCENT_COLOR,
            color=(1, 1, 1, 1))
        self.week_spinner.bind(text=self.select_week)
        week_selector.add_widget(self.week_spinner)

        self.layout.add_widget(week_selector)

        # Action buttons
        btn_layout = BoxLayout(size_hint_y=None, height=60, spacing=15, padding=(0, 10))

        add_btn = Button(
            text="＋ Add Course",
            background_normal='',
            background_color=ACCENT_COLOR,
            color=(1, 1, 1, 1),
            font_size=16)
        add_btn.bind(on_press=self.show_form)
        btn_layout.add_widget(add_btn)

        import_btn = Button(
            text="📤 Import Courses",
            background_normal='',
            background_color=PRIMARY_COLOR,
            color=(1, 1, 1, 1),
            font_size=16)
        import_btn.bind(on_press=self.show_importer)
        btn_layout.add_widget(import_btn)

        self.layout.add_widget(btn_layout)

        # Week view selector
        week_layout = BoxLayout(size_hint_y=None, height=40, spacing=5)
        days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        for i, day in enumerate(days):
            btn = Button(
                text=day,
                background_normal='',
                background_color=(0.85, 0.85, 0.85, 1) if i < 5 else (0.75, 0.75, 0.75, 1),
                color=(0.3, 0.3, 0.3, 1),
                size_hint_x=None,
                width=80)
            btn.bind(on_press=lambda instance, d=i: self.show_day(d))
            week_layout.add_widget(btn)
        self.layout.add_widget(week_layout)

        # Course list header
        list_header = BoxLayout(size_hint_y=None, height=40, spacing=10, padding=(10, 0))
        list_header.add_widget(Label(text="Course Information", size_hint_x=0.7, bold=True, color=PRIMARY_COLOR))
        list_header.add_widget(Label(text="Actions", size_hint_x=0.3, bold=True, color=PRIMARY_COLOR))
        self.layout.add_widget(list_header)

        # Course list
        self.list_layout = BoxLayout(orientation='vertical', spacing=10, size_hint_y=None)
        self.list_layout.bind(minimum_height=self.list_layout.setter('height'))

        self.scroll_view = ScrollView(bar_width=10, bar_color=PRIMARY_COLOR)
        self.scroll_view.add_widget(self.list_layout)
        self.layout.add_widget(self.scroll_view)

        # Status bar
        self.status_bar = Label(
            text=f"Ready | Week {self.current_week} | Total 0 courses",
            size_hint_y=None,
            height=35,
            color=(0.5, 0.5, 0.5, 1))
        self.layout.add_widget(self.status_bar)

        # Initialize data
        self.load_courses()

        # Start reminder checker
        Clock.schedule_interval(self.check_reminders, 60)

        return self.layout

    def update_header_rect(self, instance, value):
        instance.rect.pos = instance.pos
        instance.rect.size = instance.size

    def change_week(self, delta):
        new_week = self.current_week + delta
        if 1 <= new_week <= 16:  # Assuming 16-week semester
            self.current_week = new_week
            self.week_label.text = f"Week {self.current_week}"
            self.week_spinner.text = str(self.current_week)
            self.load_courses()

    def select_week(self, spinner, text):
        if text.isdigit():
            week_num = int(text)
            if 1 <= week_num <= 16:
                self.current_week = week_num
                self.week_label.text = f"Week {self.current_week}"
                self.load_courses()

    def show_day(self, day_index):
        self.current_day = day_index
        self.load_courses()
        days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        self.status_bar.text = f"Week {self.current_week} | Showing: {days[day_index]} courses"

    def show_form(self, instance, course=None):
        form = CourseForm(course)
        popup = Popup(
            title="Edit Course" if course else "Add New Course",
            content=form,
            size_hint=(0.85, 0.85),
            separator_color=PRIMARY_COLOR)

        btn_layout = BoxLayout(size_hint_y=None, height=60, spacing=10)

        cancel_btn = Button(
            text="Cancel",
            background_normal='',
            background_color=(0.8, 0.8, 0.8, 1),
            color=(0.3, 0.3, 0.3, 1))
        cancel_btn.bind(on_press=lambda x: popup.dismiss())

        save_btn = Button(
            text="Save Course",
            background_normal='',
            background_color=ACCENT_COLOR,
            color=(1, 1, 1, 1))
        save_btn.bind(on_press=lambda x: self.save_form(form, popup, course))

        btn_layout.add_widget(cancel_btn)
        btn_layout.add_widget(save_btn)
        form.add_widget(btn_layout)

        popup.open()

    def save_form(self, form, popup, course):
        data = form.get_data()
        if course:
            # Update existing course
            course.update(data)
        else:
            # Add new course
            new_id = max(c['id'] for c in self.courses) + 1 if self.courses else 1
            data['id'] = new_id
            self.courses.append(data)

        popup.dismiss()
        self.load_courses()
        self.status_bar.text = "Course saved successfully"

    def load_courses(self):
        # Show courses based on current week and day filter
        if hasattr(self, 'current_day'):
            display_courses = [
                c for c in self.courses
                if c['day'] == self.current_day and self.current_week in c.get('weeks', [])
            ]
        else:
            display_courses = [
                c for c in self.courses
                if self.current_week in c.get('weeks', [])
            ]

        self.status_bar.text = f"Week {self.current_week} | Total {len(display_courses)} courses"
        Clock.schedule_once(lambda dt: self.update_list(display_courses))

    def update_list(self, courses):
        self.list_layout.clear_widgets()
        if not courses:
            empty_label = Label(
                text=f"No courses scheduled for week {self.current_week}\nClick to add courses",
                halign='center',
                italic=True,
                font_size=20,
                color=(0.7, 0.7, 0.7, 1),
                size_hint_y=None,
                height=200)
            self.list_layout.add_widget(empty_label)
            return

        for course in courses:
            self.list_layout.add_widget(CourseItem(course, self))

    def show_importer(self, instance):
        content = BoxLayout(orientation='vertical', spacing=10, padding=10)
        file_chooser = FileChooserListView()
        content.add_widget(file_chooser)

        btn_layout = BoxLayout(size_hint_y=None, height=50, spacing=10)

        import_btn = Button(
            text="Import Selected File",
            background_normal='',
            background_color=PRIMARY_COLOR,
            color=(1, 1, 1, 1))
        import_btn.bind(on_press=lambda x: self.import_file(file_chooser, popup))

        cancel_btn = Button(
            text="Cancel",
            background_normal='',
            background_color=(0.8, 0.8, 0.8, 1),
            color=(0.3, 0.3, 0.3, 1))
        cancel_btn.bind(on_press=lambda x: popup.dismiss())

        btn_layout.add_widget(cancel_btn)
        btn_layout.add_widget(import_btn)
        content.add_widget(btn_layout)

        popup = Popup(
            title="Import Course File",
            content=content,
            size_hint=(0.9, 0.9),
            separator_color=PRIMARY_COLOR)
        popup.open()

    def import_file(self, file_chooser, popup):
        if file_chooser.selection:
            popup.dismiss()
            self.status_bar.text = "Importing course data..."
            # Simulate import operation
            Clock.schedule_once(lambda dt: self.simulate_import(), 1)

    def simulate_import(self):
        # Simulate importing more courses
        new_courses = [
            {
                "id": 6,
                "name": "Art Appreciation",
                "teacher": "Prof. Chen",
                "location": "Art Building 101",
                "day": 1,  # Tuesday
                "start": "14:00",
                "end": "15:40",
                "reminder": 10,
                "weeks": [1, 3, 5, 7, 9, 11, 13, 15]
            },
            {
                "id": 7,
                "name": "Philosophy Intro",
                "teacher": "Prof. Sun",
                "location": "Humanities Building 305",
                "day": 3,  # Thursday
                "start": "10:00",
                "end": "11:40",
                "reminder": 15,
                "weeks": [2, 4, 6, 8, 10, 12, 14, 16]
            }
        ]

        self.courses.extend(new_courses)
        self.load_courses()
        self.status_bar.text = "Successfully imported 2 new courses"

    def check_reminders(self, dt):
        now = datetime.now()
        current_day = now.weekday()  # Monday=0, Sunday=6
        current_time = now.time()

        for course in self.courses:
            # Check if course is active in current week
            if self.current_week not in course.get('weeks', []):
                continue

            if course['day'] == current_day:
                start_time = datetime.strptime(course['start'], '%H:%M').time()
                reminder_time = self.calculate_reminder_time(start_time, course['reminder'])

                if self.is_time_between(current_time, reminder_time, start_time):
                    self.send_notification(course)

    def calculate_reminder_time(self, start_time, minutes_before):
        start_dt = datetime.combine(datetime.today(), start_time)
        reminder_dt = start_dt - timedelta(minutes=minutes_before)
        return reminder_dt.time()

    def is_time_between(self, check_time, start_time, end_time):
        if start_time < end_time:
            return start_time <= check_time <= end_time
        else:  # Crosses midnight
            return check_time >= start_time or check_time <= end_time

    def send_notification(self, course):
        title = f"Class Reminder: {course['name']}"
        message = f"{course['start']} at {course['location']}\nInstructor: {course['teacher']}\nWeek {self.current_week}"

        try:
            notification.notify(
                title=title,
                message=message,
                app_name="Timetable App",
                timeout=10
            )
        except Exception as e:
            print("Notification failed:", e)


if __name__ == '__main__':
    TimetableApp().run()