#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据库测试脚本
检查数据库连接和数据状态
"""

import pymysql
from mysqlconnect import get_db_connection, get_all_table_names, check_table_exists

def test_db_connection():
    """测试数据库连接"""
    try:
        conn = get_db_connection()
        print("✅ 数据库连接成功!")
        conn.close()
        return True
    except Exception as e:
        print(f"❌ 数据库连接失败: {e}")
        return False

def show_all_tables():
    """显示所有表"""
    try:
        table_names = get_all_table_names()
        print(f"\n📋 数据库中的所有表 ({len(table_names)}个):")
        for i, table_name in enumerate(table_names, 1):
            print(f"  {i}. {table_name}")
        return table_names
    except Exception as e:
        print(f"❌ 获取表列表失败: {e}")
        return []

def show_table_data(table_name):
    """显示指定表的数据"""
    try:
        if not check_table_exists(table_name):
            print(f"❌ 表 {table_name} 不存在")
            return
        
        conn = get_db_connection()
        cursor = conn.cursor(pymysql.cursors.DictCursor)
        cursor.execute(f"SELECT * FROM `{table_name}`")
        records = cursor.fetchall()
        cursor.close()
        conn.close()
        
        print(f"\n📊 表 '{table_name}' 的数据 ({len(records)}条记录):")
        if records:
            for i, record in enumerate(records, 1):
                print(f"  记录 {i}:")
                for key, value in record.items():
                    print(f"    {key}: {value}")
                print()
        else:
            print("  (无数据)")
            
    except Exception as e:
        print(f"❌ 查询表 {table_name} 失败: {e}")

def main():
    print("🔍 智能课表数据库诊断")
    print("=" * 50)
    
    # 测试连接
    if not test_db_connection():
        return
    
    # 显示所有表
    tables = show_all_tables()
    
    if not tables:
        print("\n⚠️ 数据库中没有任何表，可能需要先导入课程数据")
        print("💡 建议运行: python app_pandes.py")
        return
    
    # 显示每个表的数据
    for table_name in tables:
        show_table_data(table_name)
    
    print("🎯 诊断完成!")

if __name__ == "__main__":
    main() 