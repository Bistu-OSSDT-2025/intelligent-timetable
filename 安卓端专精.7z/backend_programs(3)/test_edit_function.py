#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试编辑功能脚本
"""

import sys
import os
from course_api import CourseAPI

def test_edit_function():
    """测试编辑功能"""
    print("=" * 50)
    print("开始测试编辑功能")
    print("=" * 50)
    
    # 创建API实例
    api = CourseAPI()
    
    # 1. 先插入一个测试课程
    print("\n1. 插入测试课程...")
    course_data = {
        'name': '测试编辑课程',
        'place': '测试教室A',
        'time': '第1-2节',
        'week': 1,
        'teacher': '测试教师A',
        'day': 1,
        'term': '2024-2025-1'
    }
    
    success, message, course_id = api.insert_course(course_data)
    print(f"插入结果: {success}, 消息: {message}, 课程ID: {course_id}")
    
    if not success or course_id is None:
        print("插入课程失败，停止测试")
        return
    
    # 2. 获取课程信息
    print("\n2. 获取课程信息...")
    course = api.get_course_by_id(course_id)
    if course:
        print(f"原始课程信息: {course}")
    else:
        print("获取课程失败")
        return
    
    # 3. 测试更新课程
    print("\n3. 测试更新课程...")
    update_data = {
        'name': '更新后的测试课程',
        'place': '更新后的教室B',
        'teacher': '更新后的教师B',
        'time': '第3-4节',
        'week': 2,
        'day': 2
    }
    
    success, message = api.update_course(course_id, update_data)
    print(f"更新结果: {success}, 消息: {message}")
    
    # 4. 验证更新结果
    print("\n4. 验证更新结果...")
    updated_course = api.get_course_by_id(course_id)
    if updated_course:
        print(f"更新后的课程信息: {updated_course}")
        
        # 检查字段是否正确更新
        for field, expected_value in update_data.items():
            actual_value = updated_course.get(field)
            if actual_value == expected_value:
                print(f"  ✓ {field}: {actual_value}")
            else:
                print(f"  ✗ {field}: 期望 {expected_value}, 实际 {actual_value}")
    else:
        print("获取更新后的课程失败")
    
    # 5. 测试部分字段更新
    print("\n5. 测试部分字段更新...")
    partial_update = {
        'place': '部分更新教室C',
        'teacher': '部分更新教师C'
    }
    
    success, message = api.update_course(course_id, partial_update)
    print(f"部分更新结果: {success}, 消息: {message}")
    
    # 6. 验证部分更新结果
    print("\n6. 验证部分更新结果...")
    partial_updated_course = api.get_course_by_id(course_id)
    if partial_updated_course:
        print(f"部分更新后的课程信息: {partial_updated_course}")
        
        # 检查部分更新的字段
        for field, expected_value in partial_update.items():
            actual_value = partial_updated_course.get(field)
            if actual_value == expected_value:
                print(f"  ✓ {field}: {actual_value}")
            else:
                print(f"  ✗ {field}: 期望 {expected_value}, 实际 {actual_value}")
        
        # 检查其他字段是否保持不变
        unchanged_fields = ['name', 'time', 'week', 'day', 'term']
        for field in unchanged_fields:
            if partial_updated_course.get(field) == updated_course.get(field):
                print(f"  ✓ {field} 保持不变: {partial_updated_course.get(field)}")
            else:
                print(f"  ✗ {field} 意外改变")
    
    # 7. 测试更新不存在的课程
    print("\n7. 测试更新不存在的课程...")
    success, message = api.update_course(99999, {'name': '不存在的课程'})
    print(f"更新不存在课程结果: {success}, 消息: {message}")
    
    # 8. 测试更新无效字段
    print("\n8. 测试更新无效字段...")
    invalid_update = {
        'invalid_field': '无效值',
        'name': '有效更新'
    }
    success, message = api.update_course(course_id, invalid_update)
    print(f"更新无效字段结果: {success}, 消息: {message}")
    
    # 9. 清理测试数据
    print("\n9. 清理测试数据...")
    success, message = api.delete_course(course_id)
    print(f"删除测试课程结果: {success}, 消息: {message}")
    
    # 验证删除
    remaining_course = api.get_course_by_id(course_id)
    if remaining_course is None:
        print("  ✓ 课程已成功删除")
    else:
        print("  ✗ 课程删除失败")
    
    print("\n" + "=" * 50)
    print("编辑功能测试完成")
    print("=" * 50)

def test_same_name_update():
    """测试同名课程更新功能"""
    print("\n" + "=" * 50)
    print("开始测试同名课程更新功能")
    print("=" * 50)
    
    api = CourseAPI()
    
    # 1. 插入多个同名课程
    print("\n1. 插入多个同名课程...")
    courses_data = [
        {
            'name': '同名测试课程',
            'place': '教室A',
            'time': '第1-2节',
            'week': 1,
            'teacher': '教师A',
            'day': 1,
            'term': '2024-2025-1'
        },
        {
            'name': '同名测试课程',
            'place': '教室B',
            'time': '第3-4节',
            'week': 2,
            'teacher': '教师B',
            'day': 2,
            'term': '2024-2025-1'
        },
        {
            'name': '同名测试课程',
            'place': '教室C',
            'time': '第5-6节',
            'week': 3,
            'teacher': '教师C',
            'day': 3,
            'term': '2024-2025-1'
        }
    ]
    
    course_ids = []
    for course_data in courses_data:
        success, message, course_id = api.insert_course(course_data)
        if success and course_id is not None:
            course_ids.append(course_id)
            print(f"插入课程成功: ID={course_id}")
        else:
            print(f"插入课程失败: {message}")
    
    if not course_ids:
        print("没有成功插入课程，停止测试")
        return
    
    # 2. 查看插入的同名课程
    print("\n2. 查看插入的同名课程...")
    same_name_courses = api.get_courses_by_name('同名测试课程')
    print(f"同名课程数量: {len(same_name_courses)}")
    for course in same_name_courses:
        print(f"  - ID: {course['id']}, 教师: {course['teacher']}, 地点: {course['place']}")
    
    # 3. 测试更新同名课程
    print("\n3. 测试更新同名课程...")
    updates = {
        'teacher': '统一教师',
        'place': '统一教室'
    }
    
    success, message, count = api.update_courses_by_name('同名测试课程', updates)
    print(f"更新同名课程结果: {success}, 消息: {message}, 更新数量: {count}")
    
    # 4. 验证更新结果
    print("\n4. 验证更新结果...")
    updated_courses = api.get_courses_by_name('同名测试课程')
    print(f"更新后同名课程数量: {len(updated_courses)}")
    for course in updated_courses:
        print(f"  - ID: {course['id']}, 教师: {course['teacher']}, 地点: {course['place']}")
        
        # 检查基本信息是否更新
        if course['teacher'] == '统一教师' and course['place'] == '统一教室':
            print(f"    ✓ 基本信息已更新")
        else:
            print(f"    ✗ 基本信息更新失败")
        
        # 检查时间信息是否保持不变
        original_course = next((c for c in same_name_courses if c['id'] == course['id']), None)
        if original_course:
            time_fields = ['time', 'week', 'day']
            for field in time_fields:
                if course[field] == original_course[field]:
                    print(f"    ✓ {field} 保持不变: {course[field]}")
                else:
                    print(f"    ✗ {field} 意外改变")
    
    # 5. 清理测试数据
    print("\n5. 清理测试数据...")
    for course_id in course_ids:
        success, message = api.delete_course(course_id)
        print(f"删除课程 {course_id}: {success}")
    
    print("\n" + "=" * 50)
    print("同名课程更新功能测试完成")
    print("=" * 50)

if __name__ == "__main__":
    try:
        test_edit_function()
        test_same_name_update()
        print("\n所有测试完成！")
    except Exception as e:
        print(f"测试过程中出现错误: {e}")
        import traceback
        traceback.print_exc() 