#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
课程管理后端API模块
提供完整的课程增删改查功能
"""

import sqlite3
import os
import logging
import traceback
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Any


class CourseAPI:
    """课程管理API类"""
    
    def __init__(self, db_path: Optional[str] = None):
        """初始化API"""
        if db_path is None:
            db_path = os.path.join(os.path.dirname(__file__), 'smart_timetable.db')
        
        self.db_path = db_path
        self.setup_logging()
        self.init_database()
    
    def setup_logging(self):
        """设置日志"""
        try:
            log_file = os.path.join(os.path.dirname(__file__), 'course_api.log')
            logging.basicConfig(
                filename=log_file,
                level=logging.INFO,
                format='%(asctime)s - %(levelname)s - %(message)s',
                encoding='utf-8'
            )
        except Exception as e:
            print(f"日志设置失败: {e}")
    
    def get_db_connection(self) -> Optional[sqlite3.Connection]:
        """获取数据库连接"""
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            return conn
        except Exception as e:
            logging.error(f"数据库连接失败: {e}")
            return None
    
    def init_database(self):
        """初始化数据库表结构"""
        try:
            conn = self.get_db_connection()
            if conn:
                cursor = conn.cursor()
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS courses (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT NOT NULL,
                        place TEXT,
                        time TEXT,
                        week INTEGER,
                        teacher TEXT,
                        day INTEGER,
                        term TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                conn.commit()
                conn.close()
                logging.info("数据库初始化成功")
        except Exception as e:
            logging.error(f"数据库初始化失败: {e}")
    
    def insert_course(self, course_data: Dict[str, Any]) -> Tuple[bool, str, Optional[int]]:
        """
        插入新课程
        返回: (成功标志, 消息, 课程ID)
        """
        try:
            # 验证必填字段
            required_fields = ['name', 'place', 'time', 'week', 'teacher', 'day', 'term']
            for field in required_fields:
                if field not in course_data or not course_data[field]:
                    return False, f"缺少必填字段: {field}", None
            
            conn = self.get_db_connection()
            if conn is None:
                return False, "数据库连接失败", None
            
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO courses (name, place, time, week, teacher, day, term)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                course_data['name'],
                course_data['place'],
                course_data['time'],
                course_data['week'],
                course_data['teacher'],
                course_data['day'],
                course_data['term']
            ))
            
            course_id = cursor.lastrowid
            conn.commit()
            conn.close()
            
            logging.info(f"成功插入课程: {course_data['name']}, ID: {course_id}")
            return True, "课程添加成功", course_id
            
        except Exception as e:
            logging.error(f"插入课程失败: {e}\n{traceback.format_exc()}")
            return False, f"插入课程失败: {str(e)}", None
    
    def update_course(self, course_id: int, course_data: Dict[str, Any]) -> Tuple[bool, str]:
        """
        更新课程
        返回: (成功标志, 消息)
        """
        try:
            conn = self.get_db_connection()
            if conn is None:
                return False, "数据库连接失败"
            
            cursor = conn.cursor()
            
            # 构建更新语句
            valid_fields = ['name', 'place', 'time', 'week', 'teacher', 'day', 'term']
            update_fields = []
            values = []
            
            for field, value in course_data.items():
                if field in valid_fields and value is not None:
                    update_fields.append(f"{field} = ?")
                    values.append(value)
            
            if not update_fields:
                return False, "没有有效的更新字段"
            
            # 添加更新时间
            update_fields.append("updated_at = CURRENT_TIMESTAMP")
            values.append(course_id)
            
            sql = f"UPDATE courses SET {', '.join(update_fields)} WHERE id = ?"
            cursor.execute(sql, values)
            
            if cursor.rowcount == 0:
                conn.close()
                return False, f"课程ID {course_id} 不存在"
            
            conn.commit()
            conn.close()
            
            logging.info(f"成功更新课程ID: {course_id}")
            return True, "课程更新成功"
            
        except Exception as e:
            logging.error(f"更新课程失败: {e}\n{traceback.format_exc()}")
            return False, f"更新课程失败: {str(e)}"
    
    def delete_course(self, course_id: int) -> Tuple[bool, str]:
        """
        删除课程
        返回: (成功标志, 消息)
        """
        try:
            conn = self.get_db_connection()
            if conn is None:
                return False, "数据库连接失败"
            
            cursor = conn.cursor()
            cursor.execute('DELETE FROM courses WHERE id = ?', (course_id,))
            
            if cursor.rowcount == 0:
                conn.close()
                return False, f"课程ID {course_id} 不存在"
            
            conn.commit()
            conn.close()
            
            logging.info(f"成功删除课程ID: {course_id}")
            return True, "课程删除成功"
            
        except Exception as e:
            logging.error(f"删除课程失败: {e}\n{traceback.format_exc()}")
            return False, f"删除课程失败: {str(e)}"
    
    def get_course_by_id(self, course_id: int) -> Optional[Dict[str, Any]]:
        """根据ID获取课程"""
        try:
            conn = self.get_db_connection()
            if conn is None:
                return None
            
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM courses WHERE id = ?', (course_id,))
            course = cursor.fetchone()
            conn.close()
            
            return dict(course) if course else None
            
        except Exception as e:
            logging.error(f"获取课程失败: {e}\n{traceback.format_exc()}")
            return None
    
    def get_all_courses(self) -> List[Dict[str, Any]]:
        """获取所有课程"""
        try:
            conn = self.get_db_connection()
            if conn is None:
                return []
            
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM courses ORDER BY week, day, time')
            courses = [dict(row) for row in cursor.fetchall()]
            conn.close()
            
            return courses
            
        except Exception as e:
            logging.error(f"获取所有课程失败: {e}\n{traceback.format_exc()}")
            return []
    
    def get_courses_by_week(self, week: int) -> List[Dict[str, Any]]:
        """按周获取课程"""
        try:
            conn = self.get_db_connection()
            if conn is None:
                return []
            
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM courses WHERE week = ? ORDER BY day, time', (week,))
            courses = [dict(row) for row in cursor.fetchall()]
            conn.close()
            
            return courses
            
        except Exception as e:
            logging.error(f"按周获取课程失败: {e}\n{traceback.format_exc()}")
            return []
    
    def get_courses_by_name(self, name: str) -> List[Dict[str, Any]]:
        """按课程名称获取课程"""
        try:
            conn = self.get_db_connection()
            if conn is None:
                return []
            
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM courses WHERE name = ? ORDER BY week, day, time', (name,))
            courses = [dict(row) for row in cursor.fetchall()]
            conn.close()
            
            return courses
            
        except Exception as e:
            logging.error(f"按名称获取课程失败: {e}\n{traceback.format_exc()}")
            return []
    
    def update_courses_by_name(self, original_name: str, updates: Dict[str, Any]) -> Tuple[bool, str, int]:
        """
        更新所有同名课程的基本信息
        返回: (成功标志, 消息, 更新数量)
        """
        try:
            # 只允许更新基本信息，不更新时间相关信息
            allowed_fields = ['name', 'teacher', 'place']
            update_fields = {}
            
            for field, value in updates.items():
                if field in allowed_fields:
                    update_fields[field] = value
            
            if not update_fields:
                return False, "没有有效的更新字段", 0
            
            conn = self.get_db_connection()
            if conn is None:
                return False, "数据库连接失败", 0
            
            cursor = conn.cursor()
            
            # 构建更新语句
            set_clause = ', '.join([f"{field} = ?" for field in update_fields.keys()])
            set_clause += ", updated_at = CURRENT_TIMESTAMP"
            
            sql = f"UPDATE courses SET {set_clause} WHERE name = ?"
            values = list(update_fields.values()) + [original_name]
            
            cursor.execute(sql, values)
            updated_count = cursor.rowcount
            
            conn.commit()
            conn.close()
            
            logging.info(f"成功更新 {updated_count} 门同名课程: {original_name}")
            return True, f"成功更新 {updated_count} 门同名课程", updated_count
            
        except Exception as e:
            logging.error(f"更新同名课程失败: {e}\n{traceback.format_exc()}")
            return False, f"更新同名课程失败: {str(e)}", 0
    
    def delete_all_courses(self) -> Tuple[bool, str]:
        """删除所有课程"""
        try:
            conn = self.get_db_connection()
            if conn is None:
                return False, "数据库连接失败"
            
            cursor = conn.cursor()
            cursor.execute('DELETE FROM courses')
            deleted_count = cursor.rowcount
            
            conn.commit()
            conn.close()
            
            logging.info(f"成功删除所有课程，共 {deleted_count} 门")
            return True, f"成功删除所有课程，共 {deleted_count} 门"
            
        except Exception as e:
            logging.error(f"删除所有课程失败: {e}\n{traceback.format_exc()}")
            return False, f"删除所有课程失败: {str(e)}"
    
    def search_courses(self, keyword: str) -> List[Dict[str, Any]]:
        """搜索课程"""
        try:
            conn = self.get_db_connection()
            if conn is None:
                return []
            
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM courses 
                WHERE name LIKE ? OR teacher LIKE ? OR place LIKE ?
                ORDER BY week, day, time
            ''', (f'%{keyword}%', f'%{keyword}%', f'%{keyword}%'))
            
            courses = [dict(row) for row in cursor.fetchall()]
            conn.close()
            
            return courses
            
        except Exception as e:
            logging.error(f"搜索课程失败: {e}\n{traceback.format_exc()}")
            return []
    
    def get_course_statistics(self) -> Dict[str, Any]:
        """获取课程统计信息"""
        try:
            conn = self.get_db_connection()
            if conn is None:
                return {}
            
            cursor = conn.cursor()
            
            # 总课程数
            cursor.execute('SELECT COUNT(*) as total FROM courses')
            total_courses = cursor.fetchone()['total']
            
            # 按周统计
            cursor.execute('SELECT week, COUNT(*) as count FROM courses GROUP BY week ORDER BY week')
            weekly_stats = [dict(row) for row in cursor.fetchall()]
            
            # 按教师统计
            cursor.execute('SELECT teacher, COUNT(*) as count FROM courses GROUP BY teacher ORDER BY count DESC')
            teacher_stats = [dict(row) for row in cursor.fetchall()]
            
            conn.close()
            
            return {
                'total_courses': total_courses,
                'weekly_stats': weekly_stats,
                'teacher_stats': teacher_stats
            }
            
        except Exception as e:
            logging.error(f"获取课程统计失败: {e}\n{traceback.format_exc()}")
            return {}


# 创建全局API实例
course_api = CourseAPI()


# 兼容性函数，保持与原有代码的兼容性
def insert_course(name, place, time, week, teacher, day, term):
    """兼容性函数：插入课程"""
    success, message, course_id = course_api.insert_course({
        'name': name,
        'place': place,
        'time': time,
        'week': week,
        'teacher': teacher,
        'day': day,
        'term': term
    })
    return success

def update_course(course_id, **fields):
    """兼容性函数：更新课程"""
    success, message = course_api.update_course(course_id, fields)
    return success

def delete_course(course_id):
    """兼容性函数：删除课程"""
    success, message = course_api.delete_course(course_id)
    return success

def get_all_courses():
    """兼容性函数：获取所有课程"""
    return course_api.get_all_courses()

def get_courses_by_week(week):
    """兼容性函数：按周获取课程"""
    return course_api.get_courses_by_week(week)

def get_course_by_id(course_id):
    """兼容性函数：根据ID获取课程"""
    return course_api.get_course_by_id(course_id)

def delete_all_courses():
    """兼容性函数：删除所有课程"""
    success, message = course_api.delete_all_courses()
    return success 