#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
智能课表 - 安卓版（数据库版本）
支持与桌面端MySQL数据库同步
解决字符显示和界面结构问题
"""

import os
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, Rectangle, Line
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.core.text import LabelBase
from plyer import notification
from datetime import datetime, timedelta
import threading

# 注册中文字体 - 解决字符显示问题
def setup_chinese_font():
    """设置中文字体支持"""
    try:
        # Windows系统字体路径
        font_paths = [
            "C:/Windows/Fonts/msyh.ttc",  # 微软雅黑
            "C:/Windows/Fonts/simsun.ttc",  # 宋体
            "C:/Windows/Fonts/simhei.ttf",  # 黑体
            "/System/Library/Fonts/PingFang.ttc",  # macOS
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"  # Linux
        ]
        
        for font_path in font_paths:
            if os.path.exists(font_path):
                LabelBase.register(name="Chinese", fn_regular=font_path)
                print(f"已加载中文字体: {font_path}")
                return True
        
        print("未找到系统中文字体，使用默认字体")
        return False
    except Exception as e:
        print(f"字体加载失败: {e}")
        return False

# 设置中文字体
FONT_LOADED = setup_chinese_font()
FONT_NAME = "Chinese" if FONT_LOADED else "Roboto"

# 尝试导入数据库模块
try:
    from mysqlconnect import get_db_connection, check_table_exists, get_all_table_names, query_by_id_and_table, \
        update_field, insert_into_table, delete_by_id_and_table
    import pymysql
    DB_AVAILABLE = True
    print("数据库模块加载成功")
except ImportError as e:
    print(f"数据库模块加载失败: {e}")
    DB_AVAILABLE = False

# 应用主题配色方案 - 优化颜色搭配
class Theme:
    PRIMARY = (0.2, 0.6, 0.86, 1)      # 主色调 - 蓝色
    SECONDARY = (0.96, 0.26, 0.21, 1)  # 次要色 - 红色
    SUCCESS = (0.3, 0.8, 0.3, 1)       # 成功色 - 绿色
    WARNING = (1.0, 0.76, 0.03, 1)     # 警告色 - 橙色
    LIGHT = (0.98, 0.98, 0.98, 1)     # 浅色背景
    DARK = (0.2, 0.2, 0.2, 1)         # 深色文字
    CARD = (1, 1, 1, 1)               # 卡片背景
    BORDER = (0.9, 0.9, 0.9, 1)       # 边框色

# 保持兼容性的颜色定义
PRIMARY_COLOR = Theme.PRIMARY
SECONDARY_COLOR = Theme.SECONDARY
ACCENT_COLOR = Theme.SUCCESS
BACKGROUND_COLOR = Theme.LIGHT
CARD_COLOR = Theme.CARD
WEEK_ACTIVE_COLOR = Theme.SUCCESS
WEEK_INACTIVE_COLOR = (0.8, 0.8, 0.8, 1)

# 数据库操作类
class DatabaseManager:
    def __init__(self):
        self.db_available = DB_AVAILABLE
        print(f"数据库连接状态: {'可用' if self.db_available else '不可用'}")
        
    def get_all_courses(self):
        """获取所有课程数据"""
        if not self.db_available:
            print("数据库不可用，使用演示数据")
            return self.get_demo_courses()
        
        try:
            courses = []
            table_names = get_all_table_names()
            print(f"找到 {len(table_names)} 个课程表")
            
            for table_name in table_names:
                if table_name.lower() in ['course_schedule', 'courses']:
                    continue
                    
                try:
                    conn = get_db_connection()
                    cursor = conn.cursor(pymysql.cursors.DictCursor)
                    cursor.execute(f"SELECT * FROM `{table_name}`")
                    records = cursor.fetchall()
                    
                    for record in records:
                        course = {
                            'id': record['id'],
                            'name': table_name,
                            'teacher': record.get('teacher', ''),
                            'location': record.get('place', ''),
                            'day': self.parse_day(record.get('day', '0')),
                            'start': self.parse_time(record.get('time', '第1节')),
                            'end': self.parse_end_time(record.get('time', '第1节')),
                            'reminder': 15,
                            'weeks': self.parse_weeks(record.get('week', '1')),
                            'term': record.get('term', ''),
                            'table_name': table_name,
                            'record_id': record['id']
                        }
                        courses.append(course)
                        
                    cursor.close()
                    conn.close()
                    
                except Exception as e:
                    print(f"查询表 {table_name} 失败: {e}")
                    
            print(f"从数据库加载了 {len(courses)} 门课程")
            return courses
            
        except Exception as e:
            print(f"获取课程数据失败: {e}")
            return self.get_demo_courses()
    
    def get_demo_courses(self):
        """获取演示课程数据"""
        return [
            {
                "id": 1,
                "name": "高等数学",
                "teacher": "张教授",
                "location": "A座101",
                "day": 0,
                "start": "08:00",
                "end": "09:40",
                "reminder": 15,
                "weeks": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
            },
            {
                "id": 2,
                "name": "大学英语",
                "teacher": "李老师",
                "location": "外语楼203",
                "day": 1,
                "start": "10:00",
                "end": "11:40",
                "reminder": 10,
                "weeks": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
            }
        ]
    
    def parse_day(self, day_str):
        """解析星期"""
        day_map = {'0': 0, '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6}
        return day_map.get(str(day_str), 0)
    
    def parse_time(self, time_str):
        """解析开始时间"""
        time_map = {
            '第1节': '08:00', '第2节': '08:50', '第3节': '10:00', '第4节': '10:50',
            '第5节': '14:00', '第6节': '14:50', '第7节': '16:00', '第8节': '16:50',
            '第9节': '19:00', '第10节': '19:50', '第11节': '20:40', '第12节': '21:30',
            '1-2节': '08:00', '3-4节': '10:00', '5-6节': '14:00', '7-8节': '16:00',
            '9-10节': '19:00', '11-12节': '20:40'
        }
        return time_map.get(str(time_str), '08:00')
    
    def parse_end_time(self, time_str):
        """解析结束时间"""
        time_map = {
            '第1节': '08:40', '第2节': '09:30', '第3节': '10:40', '第4节': '11:30',
            '第5节': '14:40', '第6节': '15:30', '第7节': '16:40', '第8节': '17:30',
            '第9节': '19:40', '第10节': '20:30', '第11节': '21:20', '第12节': '22:10',
            '1-2节': '09:30', '3-4节': '11:30', '5-6节': '15:30', '7-8节': '17:30',
            '9-10节': '20:30', '11-12节': '22:10'
        }
        return time_map.get(str(time_str), '08:40')
    
    def parse_weeks(self, week_str):
        """解析周次"""
        try:
            if '-' in str(week_str):
                start, end = map(int, str(week_str).split('-'))
                return list(range(start, end + 1))
            else:
                return [int(week_str)]
        except:
            return [1]
    
    def save_course(self, course_data):
        """保存课程数据"""
        if not self.db_available:
            return False
        
        try:
            table_name = course_data['name']
            place = course_data['location']
            time = self.format_time_for_db(course_data['start'])
            week = self.format_weeks_for_db(course_data['weeks'])
            teacher = course_data['teacher']
            day = str(course_data['day'])
            term = course_data.get('term', '2024-1')
            
            return insert_into_table(table_name, place, time, week, teacher, day, term)
        except Exception as e:
            print(f"保存课程失败: {e}")
            return False
    
    def format_time_for_db(self, start_time):
        """格式化时间为数据库格式"""
        time_map = {
            '08:00': '第1节', '08:50': '第2节', '10:00': '第3节', '10:50': '第4节',
            '14:00': '第5节', '14:50': '第6节', '16:00': '第7节', '16:50': '第8节',
            '19:00': '第9节', '19:50': '第10节', '20:40': '第11节', '21:30': '第12节'
        }
        return time_map.get(start_time, '第1节')
    
    def format_weeks_for_db(self, weeks):
        """格式化周次为数据库格式"""
        if not weeks:
            return '1'
        if len(weeks) == 1:
            return str(weeks[0])
        return f"{min(weeks)}-{max(weeks)}"

class CourseForm(BoxLayout):
    def __init__(self, course=None, **kwargs):
        super().__init__(orientation='vertical', spacing=15, padding=20, **kwargs)
        self.course = course

        # 创建表单字段
        self.name = TextInput(hint_text="课程名称", multiline=False, size_hint_y=None, height=45)
        self.teacher = TextInput(hint_text="任课教师", multiline=False, size_hint_y=None, height=45)
        self.location = TextInput(hint_text="上课地点", multiline=False, size_hint_y=None, height=45)

        self.day = Spinner(
            text="选择星期",
            values=("周一", "周二", "周三", "周四", "周五", "周六", "周日"),
            size_hint_y=None, height=45
        )

        self.start = TextInput(hint_text="开始时间 (HH:MM)", multiline=False, size_hint_y=None, height=45)
        self.end = TextInput(hint_text="结束时间 (HH:MM)", multiline=False, size_hint_y=None, height=45)
        self.reminder = TextInput(
            hint_text="提前提醒 (分钟)",
            input_filter='int',
            multiline=False,
            size_hint_y=None, height=45
        )

        # 添加表单字段
        self.add_widget(Label(text="课程信息", size_hint_y=None, height=30, bold=True, color=PRIMARY_COLOR))
        self.add_widget(self.name)
        self.add_widget(self.teacher)
        self.add_widget(self.location)

        self.add_widget(Label(text="课程安排", size_hint_y=None, height=30, bold=True, color=PRIMARY_COLOR))
        self.add_widget(self.day)

        time_layout = BoxLayout(spacing=10, size_hint_y=None, height=45)
        time_layout.add_widget(self.start)
        time_layout.add_widget(self.end)
        self.add_widget(time_layout)

        self.add_widget(Label(text="提醒设置", size_hint_y=None, height=30, bold=True, color=PRIMARY_COLOR))
        self.add_widget(self.reminder)

        # 周次选择器
        self.add_widget(Label(text="上课周次", size_hint_y=None, height=30, bold=True, color=PRIMARY_COLOR))
        self.week_layout = BoxLayout(orientation='horizontal', spacing=5, size_hint_y=None, height=40)
        self.week_buttons = []

        # 创建16周的按钮
        for week in range(1, 17):
            btn = Button(
                text=str(week),
                size_hint_x=None,
                width=30,
                background_normal='',
                background_color=WEEK_INACTIVE_COLOR,
                color=(0.2, 0.2, 0.2, 1),
                font_size=12
            )
            btn.bind(on_press=lambda instance, w=week: self.toggle_week(instance, w))
            self.week_layout.add_widget(btn)
            self.week_buttons.append(btn)

        self.add_widget(self.week_layout)

        if course:
            self.load_data()

    def toggle_week(self, button, week):
        if button.background_color == WEEK_INACTIVE_COLOR:
            button.background_color = WEEK_ACTIVE_COLOR
        else:
            button.background_color = WEEK_INACTIVE_COLOR

    def load_data(self):
        days = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
        self.name.text = self.course['name']
        self.teacher.text = self.course['teacher']
        self.location.text = self.course['location']
        self.day.text = days[self.course['day']]
        self.start.text = self.course['start']
        self.end.text = self.course['end']
        self.reminder.text = str(self.course['reminder'])

        # 设置活动周次
        for i, btn in enumerate(self.week_buttons):
            week_num = i + 1
            if week_num in self.course.get('weeks', []):
                btn.background_color = WEEK_ACTIVE_COLOR
            else:
                btn.background_color = WEEK_INACTIVE_COLOR

    def get_data(self):
        # 获取选中的周次
        active_weeks = []
        for i, btn in enumerate(self.week_buttons):
            if btn.background_color == WEEK_ACTIVE_COLOR:
                active_weeks.append(i + 1)

        return {
            'name': self.name.text,
            'teacher': self.teacher.text,
            'location': self.location.text,
            'day': self.day.values.index(self.day.text),
            'start': self.start.text,
            'end': self.end.text,
            'reminder': int(self.reminder.text) if self.reminder.text else 15,
            'weeks': active_weeks
        }

class CourseItem(BoxLayout):
    def __init__(self, course, main_app, **kwargs):
        super().__init__(orientation='vertical', spacing=8, padding=15, size_hint_y=None, height=120, **kwargs)
        self.course = course
        self.main_app = main_app

        # 设置背景颜色
        with self.canvas.before:
            Color(*CARD_COLOR)
            self.bg_rect = Rectangle(size=self.size, pos=self.pos)
            Color(0.8, 0.8, 0.8, 0.3)  # 边框颜色
            self.border = Line(rectangle=(self.x, self.y, self.width, self.height), width=1)

        self.bind(size=self.update_graphics, pos=self.update_graphics)

        # 课程信息布局
        header_layout = BoxLayout(size_hint_y=None, height=30)
        
        # 课程名称
        course_name = Label(
            text=course['name'],
            font_size=18,
            bold=True,
            color=PRIMARY_COLOR,
            text_size=(200, None),
            halign='left'
        )
        header_layout.add_widget(course_name)

        # 操作按钮
        btn_layout = BoxLayout(size_hint_x=None, width=120, spacing=5)
        
        edit_btn = Button(
            text="编辑",
            size_hint_x=None,
            width=55,
            height=25,
            background_normal='',
            background_color=ACCENT_COLOR,
            color=(1, 1, 1, 1),
            font_size=12
        )
        edit_btn.bind(on_press=self.edit)
        
        delete_btn = Button(
            text="删除",
            size_hint_x=None,
            width=55,
            height=25,
            background_normal='',
            background_color=SECONDARY_COLOR,
            color=(1, 1, 1, 1),
            font_size=12
        )
        delete_btn.bind(on_press=self.delete)
        
        btn_layout.add_widget(edit_btn)
        btn_layout.add_widget(delete_btn)
        header_layout.add_widget(btn_layout)

        # 课程详情
        details_layout = BoxLayout(orientation='vertical', spacing=3)
        
        teacher_info = Label(
            text=f"教师: {course['teacher']}",
            font_size=14,
            color=(0.4, 0.4, 0.4, 1),
            text_size=(None, None),
            halign='left'
        )
        
        location_info = Label(
            text=f"地点: {course['location']}",
            font_size=14,
            color=(0.4, 0.4, 0.4, 1),
            text_size=(None, None),
            halign='left'
        )
        
        time_info = Label(
            text=f"时间: {course['start']} - {course['end']}",
            font_size=14,
            color=(0.4, 0.4, 0.4, 1),
            text_size=(None, None),
            halign='left'
        )
        
        details_layout.add_widget(teacher_info)
        details_layout.add_widget(location_info)
        details_layout.add_widget(time_info)

        self.add_widget(header_layout)
        self.add_widget(details_layout)

    def update_graphics(self, *args):
        self.bg_rect.size = self.size
        self.bg_rect.pos = self.pos
        self.border.rectangle = (self.x, self.y, self.width, self.height)

    def edit(self, instance):
        self.main_app.show_form(instance, self.course)

    def delete(self, instance):
        # 删除课程
        if self.course in self.main_app.courses:
            self.main_app.courses.remove(self.course)
            self.main_app.load_courses()
            self.main_app.status_bar.text = "课程已删除"

class TimetableApp(App):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.current_week = 1
        self.current_day = None
        self.db_manager = DatabaseManager()
        self.courses = []

    def build(self):
        self.title = "智能课表 - 安卓版"
        
        # 主布局
        main_layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        main_layout.canvas.before.add(Color(*BACKGROUND_COLOR))
        main_layout.canvas.before.add(Rectangle(size=Window.size, pos=(0, 0)))

        # 顶部标题栏
        header_layout = BoxLayout(size_hint_y=None, height=60, spacing=10)
        header_layout.canvas.before.add(Color(*PRIMARY_COLOR))
        header_rect = Rectangle(size=header_layout.size, pos=header_layout.pos)
        header_layout.canvas.before.add(header_rect)
        header_layout.bind(size=lambda instance, value: setattr(header_rect, 'size', value))
        header_layout.bind(pos=lambda instance, value: setattr(header_rect, 'pos', value))

        # 应用标题 - 添加中文字体支持
        title_label = Label(
            text="📚 智能课表",
            font_size=22,
            bold=True,
            color=(1, 1, 1, 1),
            font_name=FONT_NAME
        )
        header_layout.add_widget(title_label)

        # 刷新按钮 - 改进样式
        refresh_btn = Button(
            text="🔄 刷新",
            size_hint_x=None,
            width=90,
            background_normal='',
            background_color=Theme.SUCCESS,
            color=(1, 1, 1, 1),
            font_size=13,
            font_name=FONT_NAME
        )
        refresh_btn.bind(on_press=self.refresh_courses)
        header_layout.add_widget(refresh_btn)

        # 周次控制 - 改进设计和中文字体支持
        week_layout = BoxLayout(size_hint_y=None, height=55, spacing=10)
        
        prev_btn = Button(
            text="◀ 上周",
            size_hint_x=None,
            width=85,
            background_normal='',
            background_color=Theme.PRIMARY,
            color=(1, 1, 1, 1),
            font_name=FONT_NAME,
            font_size=13
        )
        prev_btn.bind(on_press=lambda x: self.change_week(-1))
        
        # 改用Label显示当前周次，更清晰
        self.week_label = Label(
            text=f"第 {self.current_week} 周",
            font_size=20,
            bold=True,
            color=Theme.DARK,
            font_name=FONT_NAME
        )
        
        next_btn = Button(
            text="下周 ▶",
            size_hint_x=None,
            width=85,
            background_normal='',
            background_color=Theme.PRIMARY,
            color=(1, 1, 1, 1),
            font_name=FONT_NAME,
            font_size=13
        )
        next_btn.bind(on_press=lambda x: self.change_week(1))
        
        week_layout.add_widget(prev_btn)
        week_layout.add_widget(self.week_label)
        week_layout.add_widget(next_btn)

        # 星期过滤按钮 - 使用网格布局，更整齐美观
        day_layout = GridLayout(cols=4, size_hint_y=None, height=80, spacing=8)
        
        days_config = [
            ("📅 全部", None, Theme.WARNING),
            ("周一", 0, Theme.PRIMARY),
            ("周二", 1, Theme.PRIMARY),
            ("周三", 2, Theme.PRIMARY),
            ("周四", 3, Theme.PRIMARY),
            ("周五", 4, Theme.PRIMARY),
            ("周六", 5, Theme.SECONDARY),
            ("周日", 6, Theme.SECONDARY)
        ]
        
        for day_name, day_index, color in days_config:
            btn = Button(
                text=day_name,
                background_normal='',
                background_color=color,
                color=(1, 1, 1, 1),
                font_size=11,
                font_name=FONT_NAME
            )
            btn.bind(on_press=lambda x, day_idx=day_index: self.show_day(day_idx))
            day_layout.add_widget(btn)

        # 操作按钮 - 简化设计，突出重点功能
        action_layout = BoxLayout(size_hint_y=None, height=55, spacing=15)
        
        # 只保留导入功能，简化界面
        import_btn = Button(
            text="📥 同步数据",
            background_normal='',
            background_color=Theme.SUCCESS,
            color=(1, 1, 1, 1),
            font_size=16,
            font_name=FONT_NAME
        )
        import_btn.bind(on_press=self.show_importer)
        
        # 添加设置按钮
        settings_btn = Button(
            text="⚙️ 设置",
            background_normal='',
            background_color=Theme.WARNING,
            color=(1, 1, 1, 1),
            font_size=16,
            font_name=FONT_NAME
        )
        settings_btn.bind(on_press=self.show_settings)
        
        action_layout.add_widget(import_btn)
        action_layout.add_widget(settings_btn)

        # 课程列表
        scroll = ScrollView()
        self.list_layout = BoxLayout(orientation='vertical', spacing=10, size_hint_y=None)
        self.list_layout.bind(minimum_height=self.list_layout.setter('height'))
        scroll.add_widget(self.list_layout)

        # 状态栏 - 改进样式和中文字体支持
        self.status_bar = Label(
            text="📚 欢迎使用智能课表",
            size_hint_y=None,
            height=35,
            color=Theme.DARK,
            font_name=FONT_NAME,
            font_size=14
        )

        # 添加所有组件
        main_layout.add_widget(header_layout)
        main_layout.add_widget(week_layout)
        main_layout.add_widget(day_layout)
        main_layout.add_widget(action_layout)
        main_layout.add_widget(scroll)
        main_layout.add_widget(self.status_bar)

        # 加载课程数据
        self.load_courses()
        
        # 设置定时检查提醒
        Clock.schedule_interval(self.check_reminders, 60)  # 每分钟检查一次

        return main_layout

    def refresh_courses(self, instance):
        """刷新课程数据"""
        self.courses = self.db_manager.get_all_courses()
        self.load_courses()
        self.status_bar.text = "课程数据已刷新"

    def change_week(self, delta):
        """切换周次"""
        new_week = max(1, min(20, self.current_week + delta))
        if new_week != self.current_week:
            self.current_week = new_week
            self.week_label.text = f"第 {self.current_week} 周"
            self.load_courses()
    
    def show_settings(self, instance):
        """显示设置界面"""
        popup_content = BoxLayout(orientation='vertical', spacing=15, padding=20)
        
        # 设置信息
        info_text = f"""📱 智能课表设置

🔗 数据库状态: {'✅ 已连接' if self.db_manager.db_available else '❌ 未连接'}
📊 课程总数: {len(self.courses)}
📅 当前周次: 第{self.current_week}周
🎨 字体支持: {'✅ 中文字体' if FONT_LOADED else '⚠️ 默认字体'}

💡 使用提示:
• 左右滑动切换周次
• 点击星期按钮筛选课程
• 定期点击"同步数据"获取最新课程"""
        
        info_label = Label(
            text=info_text,
            font_name=FONT_NAME,
            color=Theme.DARK,
            text_size=(300, None),
            halign='left'
        )
        popup_content.add_widget(info_label)
        
        # 关闭按钮
        close_btn = Button(
            text="✅ 确定",
            size_hint_y=None,
            height=45,
            background_normal='',
            background_color=Theme.PRIMARY,
            color=(1, 1, 1, 1),
            font_name=FONT_NAME
        )
        
        popup = Popup(
            title="设置",
            content=popup_content,
            size_hint=(0.85, 0.75),
            separator_color=Theme.PRIMARY
        )
        
        close_btn.bind(on_press=popup.dismiss)
        popup_content.add_widget(close_btn)
        popup.open()

    def select_week(self, spinner, text):
        """选择周次"""
        self.current_week = int(text.replace("第", "").replace("周", ""))
        self.load_courses()

    def show_day(self, day_index):
        """显示指定天的课程"""
        self.current_day = day_index
        self.load_courses()
        if day_index is None:
            self.status_bar.text = f"第{self.current_week}周 | 显示: 全部课程"
        else:
            days = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
            self.status_bar.text = f"第{self.current_week}周 | 显示: {days[day_index]} 课程"

    def show_form(self, instance, course=None):
        form = CourseForm(course)
        popup = Popup(
            title="编辑课程" if course else "添加新课程",
            content=form,
            size_hint=(0.85, 0.85),
            separator_color=PRIMARY_COLOR
        )

        btn_layout = BoxLayout(size_hint_y=None, height=60, spacing=10)

        cancel_btn = Button(
            text="取消",
            background_normal='',
            background_color=(0.8, 0.8, 0.8, 1),
            color=(0.3, 0.3, 0.3, 1)
        )
        cancel_btn.bind(on_press=lambda x: popup.dismiss())

        save_btn = Button(
            text="保存课程",
            background_normal='',
            background_color=ACCENT_COLOR,
            color=(1, 1, 1, 1)
        )
        save_btn.bind(on_press=lambda x: self.save_form(form, popup, course))

        btn_layout.add_widget(cancel_btn)
        btn_layout.add_widget(save_btn)
        form.add_widget(btn_layout)

        popup.open()

    def save_form(self, form, popup, course):
        data = form.get_data()
        
        # 保存到数据库
        if self.db_manager.save_course(data):
            popup.dismiss()
            self.refresh_courses(None)
            self.status_bar.text = "课程保存成功"
        else:
            # 如果数据库保存失败，使用内存保存
            if course:
                course.update(data)
            else:
                new_id = max(c['id'] for c in self.courses) + 1 if self.courses else 1
                data['id'] = new_id
                self.courses.append(data)
            
            popup.dismiss()
            self.load_courses()
            self.status_bar.text = "课程保存成功（本地）"

    def load_courses(self):
        """加载课程数据"""
        if not self.courses:
            self.courses = self.db_manager.get_all_courses()
        
        # 根据当前周次和日期过滤显示课程
        if self.current_day is not None:
            display_courses = [
                c for c in self.courses
                if c['day'] == self.current_day and self.current_week in c.get('weeks', [])
            ]
        else:
            display_courses = [
                c for c in self.courses
                if self.current_week in c.get('weeks', [])
            ]

        self.status_bar.text = f"第{self.current_week}周 | 共 {len(display_courses)} 门课程"
        Clock.schedule_once(lambda dt: self.update_list(display_courses))

    def update_list(self, courses):
        """更新课程列表"""
        self.list_layout.clear_widgets()
        if not courses:
            empty_label = Label(
                text=f"第{self.current_week}周暂无课程安排",
                halign='center',
                font_size=20,
                color=(0.7, 0.7, 0.7, 1),
                size_hint_y=None,
                height=200
            )
            self.list_layout.add_widget(empty_label)
            return

        for course in courses:
            item = self.create_course_item(course)
            self.list_layout.add_widget(item)

    def create_course_item(self, course):
        """创建课程项目"""
        item_layout = BoxLayout(orientation='vertical', spacing=8, padding=15, size_hint_y=None, height=120)
        
        # 背景
        with item_layout.canvas.before:
            Color(*CARD_COLOR)
            bg_rect = Rectangle(size=item_layout.size, pos=item_layout.pos)
            Color(0.8, 0.8, 0.8, 0.3)
            border = Line(rectangle=(item_layout.x, item_layout.y, item_layout.width, item_layout.height), width=1)
        
        def update_graphics(instance, value):
            bg_rect.size = instance.size
            bg_rect.pos = instance.pos
            border.rectangle = (instance.x, instance.y, instance.width, instance.height)
        
        item_layout.bind(size=update_graphics, pos=update_graphics)

        # 课程名称 - 添加中文字体和emoji
        name_label = Label(
            text=f"📖 {course['name']}",
            font_size=18,
            bold=True,
            color=Theme.PRIMARY,
            size_hint_y=None,
            height=30,
            font_name=FONT_NAME
        )
        
        # 课程详情 - 优化格式和中文字体
        days_cn = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
        details_text = f"👨‍🏫 教师: {course['teacher']}\n📍 地点: {course['location']}\n🕐 时间: {course['start']} - {course['end']}\n📅 星期: {days_cn[course['day']]}"
        details_label = Label(
            text=details_text,
            font_size=13,
            color=Theme.DARK,
            size_hint_y=None,
            height=80,
            font_name=FONT_NAME,
            text_size=(None, None),
            halign='left'
        )
        
        item_layout.add_widget(name_label)
        item_layout.add_widget(details_label)
        
        return item_layout

    def show_importer(self, instance):
        content = BoxLayout(orientation='vertical', spacing=10, padding=10)
        
        info_label = Label(
            text="导入功能将从桌面端数据库同步课程数据",
            size_hint_y=None,
            height=50,
            color=(0.5, 0.5, 0.5, 1)
        )
        content.add_widget(info_label)

        btn_layout = BoxLayout(size_hint_y=None, height=50, spacing=10)

        import_btn = Button(
            text="从数据库导入",
            background_normal='',
            background_color=PRIMARY_COLOR,
            color=(1, 1, 1, 1)
        )
        import_btn.bind(on_press=lambda x: self.import_from_database(popup))

        cancel_btn = Button(
            text="取消",
            background_normal='',
            background_color=(0.8, 0.8, 0.8, 1),
            color=(0.3, 0.3, 0.3, 1)
        )
        cancel_btn.bind(on_press=lambda x: popup.dismiss())

        btn_layout.add_widget(cancel_btn)
        btn_layout.add_widget(import_btn)
        content.add_widget(btn_layout)

        popup = Popup(
            title="导入课程数据",
            content=content,
            size_hint=(0.8, 0.5),
            separator_color=PRIMARY_COLOR
        )
        popup.open()

    def import_from_database(self, popup):
        """从数据库导入课程数据"""
        popup.dismiss()
        self.status_bar.text = "正在从数据库导入课程..."
        
        # 异步加载数据
        def load_data():
            self.courses = self.db_manager.get_all_courses()
            Clock.schedule_once(lambda dt: self.finish_import())
        
        threading.Thread(target=load_data).start()

    def finish_import(self):
        """完成导入"""
        self.load_courses()
        self.status_bar.text = f"成功导入 {len(self.courses)} 门课程"

    def check_reminders(self, dt):
        """检查课程提醒"""
        now = datetime.now()
        current_day = now.weekday()  # 周一=0, 周日=6
        current_time = now.time()

        for course in self.courses:
            # 检查课程是否在当前周次
            if self.current_week not in course.get('weeks', []):
                continue

            if course['day'] == current_day:
                start_time = datetime.strptime(course['start'], '%H:%M').time()
                reminder_time = self.calculate_reminder_time(start_time, course['reminder'])

                if self.is_time_between(current_time, reminder_time, start_time):
                    self.send_notification(course)

    def calculate_reminder_time(self, start_time, minutes_before):
        """计算提醒时间"""
        start_dt = datetime.combine(datetime.today(), start_time)
        reminder_dt = start_dt - timedelta(minutes=minutes_before)
        return reminder_dt.time()

    def is_time_between(self, check_time, start_time, end_time):
        """检查时间是否在指定范围内"""
        if start_time < end_time:
            return start_time <= check_time <= end_time
        else:  # 跨越午夜
            return check_time >= start_time or check_time <= end_time

    def send_notification(self, course):
        """发送课程提醒通知"""
        title = f"课程提醒: {course['name']}"
        message = f"{course['start']} 在 {course['location']}\n教师: {course['teacher']}\n第{self.current_week}周"

        try:
            notification.notify(
                title=title,
                message=message,
                app_name="智能课表",
                timeout=10
            )
        except Exception as e:
            print("通知发送失败:", e)

if __name__ == '__main__':
    TimetableApp().run() 