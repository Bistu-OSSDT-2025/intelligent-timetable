# 智能课表系统 - 完整功能无弹窗版本 v4.0
import tkinter as tk
from tkinter import ttk, filedialog
import traceback
import os
from datetime import datetime, timedelta
import threading

# 尝试导入数据库相关模块
try:
    import pymysql
    import pymysql.cursors
    import pandas as pd
    from openpyxl import load_workbook
    from apscheduler.schedulers.background import BackgroundScheduler
    from mysqlconnect import get_db_connection, check_table_exists, get_all_table_names, query_by_id_and_table, \
        update_field, insert_into_table, delete_by_id_and_table
    DB_AVAILABLE = True
except ImportError:
    DB_AVAILABLE = False

# 日志记录函数
def log_message(message_type, message):
    """记录消息到日志文件"""
    try:
        log_file = os.path.join(os.path.dirname(__file__), 'debug.log')
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S")} [{message_type}]: {message}\n')
    except:
        pass

# 无弹窗消息框替代品
class StatusMessageBox:
    def __init__(self, app):
        self.app = app
    
    def showerror(self, title, message):
        log_message("ERROR", f"{title}: {message}")
        if hasattr(self.app, 'update_status'):
            self.app.update_status(f"错误: {message}", is_error=True)
        return None
    
    def showinfo(self, title, message):
        log_message("INFO", f"{title}: {message}")
        if hasattr(self.app, 'update_status'):
            self.app.update_status(f"成功: {message}")
        return None
    
    def showwarning(self, title, message):
        log_message("WARNING", f"{title}: {message}")
        if hasattr(self.app, 'update_status'):
            self.app.update_status(f"警告: {message}")
        return None
    
    def askyesno(self, title, message):
        log_message("QUESTION", f"{title}: {message} (默认: 是)")
        if hasattr(self.app, 'update_status'):
            self.app.update_status(f"确认: {message}")
        return True

class CourseEditDialog:
    """课程编辑对话框"""
    def __init__(self, parent, course_data=None, is_new=True):
        self.parent = parent
        self.course_data = course_data
        self.is_new = is_new
        self.result = None
        
        # 使用父窗口的消息框
        self.messagebox = parent.messagebox
        
        # 创建对话框窗口
        self.dialog = tk.Toplevel(parent.root)
        self.dialog.title("编辑课程" if not is_new else "添加课程")
        self.dialog.geometry("400x500")
        self.dialog.transient(parent.root)
        self.dialog.grab_set()
        
        # 使对话框居中
        self.dialog.update_idletasks()
        x = (self.dialog.winfo_screenwidth() // 2) - (400 // 2)
        y = (self.dialog.winfo_screenheight() // 2) - (500 // 2)
        self.dialog.geometry(f"400x500+{x}+{y}")
        
        self.setup_ui()
        
    def setup_ui(self):
        """设置对话框UI"""
        main_frame = tk.Frame(self.dialog, bg="#f0f2f5")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # 标题
        title_label = tk.Label(main_frame, 
                              text="编辑课程信息" if not self.is_new else "添加新课程",
                              font=("微软雅黑", 16, "bold"),
                              bg="#f0f2f5", fg="#2c3e50")
        title_label.pack(pady=(0, 20))
        
        # 课程名称
        self.create_field(main_frame, "课程名称:", "name")
        
        # 任课教师
        self.create_field(main_frame, "任课教师:", "teacher")
        
        # 上课地点
        self.create_field(main_frame, "上课地点:", "place")
        
        # 星期选择
        week_frame = tk.Frame(main_frame, bg="#f0f2f5")
        week_frame.pack(fill=tk.X, pady=5)
        tk.Label(week_frame, text="星期:", font=("微软雅黑", 10), 
                bg="#f0f2f5", fg="#34495e", width=12, anchor="w").pack(side=tk.LEFT)
        
        self.day_var = tk.StringVar()
        day_combo = ttk.Combobox(week_frame, textvariable=self.day_var, width=20,
                                values=["0", "1", "2", "3", "4"],  # 只显示工作日
                                font=("微软雅黑", 10), state="readonly")
        day_combo.pack(side=tk.LEFT, padx=(10, 0))
        
        # 节次选择
        time_frame = tk.Frame(main_frame, bg="#f0f2f5")
        time_frame.pack(fill=tk.X, pady=5)
        tk.Label(time_frame, text="上课时间:", font=("微软雅黑", 10), 
                bg="#f0f2f5", fg="#34495e", width=12, anchor="w").pack(side=tk.LEFT)
        
        self.time_var = tk.StringVar()
        time_values = [f"第{i}节" for i in range(1, 14)]  # 第1节到第13节
        # 添加常见的连续课程时间段
        time_values.extend([
            "1-2节", "3-4节", "5-6节", "7-8节", "9-10节", "11-12节",
            "1-3节", "3-5节", "5-7节", "7-9节", "9-11节", "11-13节",
            "1-4节", "3-6节", "5-8节", "7-10节", "9-12节",
            "1-8节"  # 长课程
        ])
        time_combo = ttk.Combobox(time_frame, textvariable=self.time_var, width=20,
                                 values=time_values,
                                 font=("微软雅黑", 10), state="readonly")
        time_combo.pack(side=tk.LEFT, padx=(10, 0))
        
        # 上课周次
        self.create_field(main_frame, "上课周次:", "week")
        
        # 学期
        self.create_field(main_frame, "学期:", "term")
        
        # 按钮区域
        button_frame = tk.Frame(main_frame, bg="#f0f2f5")
        button_frame.pack(fill=tk.X, pady=(30, 0))
        
        # 保存按钮
        save_btn = tk.Button(button_frame, text="保存", 
                            command=self.save_course,
                            font=("微软雅黑", 12, "bold"),
                            bg="#3498db", fg="white", 
                            relief=tk.FLAT, padx=20, pady=8)
        save_btn.pack(side=tk.LEFT, padx=(0, 10))
        
        # 删除按钮（仅编辑时显示）
        if not self.is_new:
            delete_btn = tk.Button(button_frame, text="删除", 
                                  command=self.delete_course,
                                  font=("微软雅黑", 12, "bold"),
                                  bg="#e74c3c", fg="white", 
                                  relief=tk.FLAT, padx=20, pady=8)
            delete_btn.pack(side=tk.LEFT, padx=(0, 10))
        
        # 取消按钮
        cancel_btn = tk.Button(button_frame, text="取消", 
                              command=self.dialog.destroy,
                              font=("微软雅黑", 12),
                              bg="#95a5a6", fg="white", 
                              relief=tk.FLAT, padx=20, pady=8)
        cancel_btn.pack(side=tk.RIGHT)
        
        # 如果是编辑模式，填充数据
        if not self.is_new and self.course_data:
            self.load_course_data()
            
    def create_field(self, parent, label_text, field_name):
        """创建输入字段"""
        frame = tk.Frame(parent, bg="#f0f2f5")
        frame.pack(fill=tk.X, pady=5)
        
        label = tk.Label(frame, text=label_text, font=("微软雅黑", 10), 
                        bg="#f0f2f5", fg="#34495e", width=12, anchor="w")
        label.pack(side=tk.LEFT)
        
        entry = tk.Entry(frame, font=("微软雅黑", 10), width=25)
        entry.pack(side=tk.LEFT, padx=(10, 0))
        
        setattr(self, f"{field_name}_entry", entry)
        
    def load_course_data(self):
        """加载课程数据到表单"""
        if self.course_data:
            # 确保所有entry字段都存在后再填充数据
            if hasattr(self, 'name_entry'):
                self.name_entry.insert(0, self.course_data.get('table_name', ''))
            if hasattr(self, 'teacher_entry'):
                self.teacher_entry.insert(0, self.course_data.get('teacher', ''))
            if hasattr(self, 'place_entry'):
                self.place_entry.insert(0, self.course_data.get('place', ''))
            if hasattr(self, 'day_var'):
                self.day_var.set(str(self.course_data.get('day', '0')))
            if hasattr(self, 'time_var'):
                self.time_var.set(self.course_data.get('time', '第1节'))
            if hasattr(self, 'week_entry'):
                self.week_entry.insert(0, str(self.course_data.get('week', '')))
            if hasattr(self, 'term_entry'):
                self.term_entry.insert(0, self.course_data.get('term', ''))
            
    def save_course(self):
        """保存课程信息"""
        try:
            # 获取表单数据
            table_name = self.name_entry.get().strip()
            teacher = self.teacher_entry.get().strip()
            place = self.place_entry.get().strip()
            day = self.day_var.get()
            time = self.time_var.get()
            week = self.week_entry.get().strip()
            term = self.term_entry.get().strip()
            
            # 验证必填字段
            if not all([table_name, teacher, place, day, time, week, term]):
                self.messagebox.showerror("错误", "请填写所有字段！")
                return
                
            if not DB_AVAILABLE:
                self.messagebox.showerror("错误", "数据库模块不可用！")
                return
                
            # 清理课程名称：替换非法字符
            cleaned_table_name = table_name.replace('+', '和').replace(' ', '_')
            
            if self.is_new:
                # 新增课程
                if insert_into_table(cleaned_table_name, place, time, int(week), teacher, day, term):
                    self.messagebox.showinfo("成功", "课程添加成功！")
                    self.result = 'success'
                    self.dialog.destroy()
                else:
                    self.messagebox.showerror("错误", "添加课程失败！")
            else:
                # 更新课程
                old_table_name = self.course_data['table_name']
                record_id = self.course_data['id']
                
                # 如果课程名称改变，需要重新创建表
                if cleaned_table_name != old_table_name:
                    # 删除旧记录
                    delete_by_id_and_table(old_table_name, record_id)
                    # 创建新记录
                    if insert_into_table(cleaned_table_name, place, time, int(week), teacher, day, term):
                        self.messagebox.showinfo("成功", "课程更新成功！")
                        self.result = 'success'
                        self.dialog.destroy()
                    else:
                        self.messagebox.showerror("错误", "更新课程失败！")
                else:
                    # 更新现有记录
                    update_field(old_table_name, record_id, 'place', place)
                    update_field(old_table_name, record_id, 'time', time)
                    update_field(old_table_name, record_id, 'week', int(week))
                    update_field(old_table_name, record_id, 'teacher', teacher)
                    update_field(old_table_name, record_id, 'day', day)
                    update_field(old_table_name, record_id, 'term', term)
                    
                    self.messagebox.showinfo("成功", "课程更新成功！")
                    self.result = 'success'
                    self.dialog.destroy()
                    
        except Exception as e:
            self.messagebox.showerror("错误", f"保存失败：{str(e)}")
            
    def delete_course(self):
        """删除课程"""
        if self.messagebox.askyesno("确认删除", "确定要删除这门课程吗？"):
            try:
                if not DB_AVAILABLE:
                    self.messagebox.showerror("错误", "数据库模块不可用！")
                    return
                    
                old_table_name = self.course_data['table_name']
                record_id = self.course_data['id']
                
                if delete_by_id_and_table(old_table_name, record_id):
                    self.messagebox.showinfo("成功", "课程删除成功！")
                    self.result = 'success'
                    self.dialog.destroy()
                else:
                    self.messagebox.showerror("错误", "删除课程失败！")
            except Exception as e:
                self.messagebox.showerror("错误", f"删除失败：{str(e)}")

class SmartTimetableApp:
    def __init__(self):
        # 初始化主窗口
        self.root = tk.Tk()
        self.root.title("智能课表系统 v4.0 - 完整功能无弹窗版")
        self.root.geometry("1800x1200")
        self.root.configure(bg="#f0f2f5")
        
        # 初始化消息框
        self.messagebox = StatusMessageBox(self)
        
        # 周数变量
        self.current_week = tk.IntVar()
        self.current_week.set(1)
        
        # 课程表网格 - 5天×13节课
        self.course_grid = [[None for _ in range(5)] for _ in range(13)]
        
        # 智能提醒系统初始化
        if DB_AVAILABLE:
            self.scheduler = BackgroundScheduler()
            self.scheduler.start()
            self.reminders = []  # 存储提醒信息
        
        # 节次→开始时间映射表
        self.section_time_map = {
            "第1节": (8, 0),
            "第2节": (8, 50),
            "第3节": (9, 50),
            "第4节": (10, 40),
            "第5节": (11, 30),
            "第6节": (13, 30),  # 下午第一节
            "第7节": (14, 20),
            "第8节": (15, 20),
            "第9节": (16, 10),
            "第10节": (18, 30),  # 晚上第一节
            "第11节": (19, 20),
            "第12节": (20, 10),
            "第13节": (21, 0),
        }
        
        # 特殊节次（下午和晚上第一节）
        self.special_sections = {"第6节", "第10节"}
        
        # 创建状态栏
        self.status_var = tk.StringVar()
        self.status_var.set("系统就绪")
        
        # 设置UI
        self.setup_ui()
        
        # 加载课程数据
        self.load_courses()
        
        if DB_AVAILABLE:
            self.setup_smart_reminders()  # 设置智能提醒
        
        # 程序退出时清理调度器
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        
        # 记录启动
        log_message("INFO", "智能课表系统启动")
        self.update_status("智能课表系统启动成功")
        
    def update_status(self, message, is_error=False, duration=3000):
        """更新状态栏"""
        self.status_var.set(message)
        if is_error:
            self.status_label.config(fg="red")
        else:
            self.status_label.config(fg="green")
        
        if duration > 0:
            self.root.after(duration, lambda: (
                self.status_var.set("系统就绪"),
                self.status_label.config(fg="black")
            ))
        
    def setup_ui(self):
        """设置UI界面"""
        # 设置主题样式
        style = ttk.Style()
        style.theme_use('clam')
        
        # 顶部控制面板
        self.setup_control_panel()
        
        # 主内容区域
        self.setup_main_content()
        
    def setup_control_panel(self):
        """设置顶部控制面板"""
        control_frame = tk.Frame(self.root, bg="#4a6baf", height=70)
        control_frame.pack(fill=tk.X, padx=0, pady=0)
        control_frame.pack_propagate(False)
        
        # 标题标签
        title_label = tk.Label(control_frame,
                             text="智能课表系统 v4.0",
                             font=("微软雅黑", 20, 'bold'),
                             bg="#4a6baf", fg="#FFFFFF")
        title_label.pack(side=tk.LEFT, padx=25, pady=10)
        
        # 右侧按钮区域
        right_frame = tk.Frame(control_frame, bg="#4a6baf")
        right_frame.pack(side=tk.RIGHT, padx=25, pady=10)
        
        # 导入课表按钮
        import_btn = tk.Button(right_frame, text="导入课表",
                              command=self.import_excel,
                              font=("微软雅黑", 12, "bold"),
                              bg="#f39c12", fg="white",
                              relief=tk.FLAT, padx=15, pady=5)
        import_btn.pack(side=tk.RIGHT, padx=(10, 0))
        
        # 提醒设置按钮
        reminder_btn = tk.Button(right_frame, text="⏰ 提醒",
                                command=self.open_reminder_settings,
                                font=("微软雅黑", 12, "bold"),
                                bg="#9b59b6", fg="white",
                                relief=tk.FLAT, padx=15, pady=5)
        reminder_btn.pack(side=tk.RIGHT, padx=(10, 0))
        
        # 删除所有课程按钮
        delete_all_btn = tk.Button(right_frame, text="删除所有课程",
                                  command=self.delete_all_courses,
                                  font=("微软雅黑", 12, "bold"),
                                  bg="#e74c3c", fg="white",
                                  relief=tk.FLAT, padx=15, pady=5)
        delete_all_btn.pack(side=tk.RIGHT, padx=(10, 0))
        
        # 添加课程按钮
        add_btn = tk.Button(right_frame, text="添加课程",
                           command=self.add_course,
                           font=("微软雅黑", 12, "bold"),
                           bg="#27ae60", fg="white",
                           relief=tk.FLAT, padx=15, pady=5)
        add_btn.pack(side=tk.RIGHT, padx=(10, 0))
        
        # 刷新按钮
        refresh_btn = tk.Button(right_frame, text="刷新",
                              command=self.load_courses,
                              font=("微软雅黑", 12),
                              bg="#3498db", fg="white",
                              relief=tk.FLAT, padx=15, pady=5)
        refresh_btn.pack(side=tk.RIGHT, padx=(10, 0))
        
        # 周数控制
        week_frame = tk.Frame(right_frame, bg="#4a6baf")
        week_frame.pack(side=tk.RIGHT, padx=(0, 20))
        
        # 上一周按钮
        prev_btn = tk.Button(week_frame, text="◀",
                            command=self.prev_week,
                            font=("微软雅黑", 12, "bold"),
                            bg="#34495e", fg="white",
                            relief=tk.FLAT, width=3)
        prev_btn.pack(side=tk.LEFT)
        
        # 周数标签
        self.week_label = tk.Label(week_frame,
                                  text=f"第 {self.current_week.get()} 周",
                                  font=("微软雅黑", 14, 'bold'),
                                  bg="#4a6baf", fg="#FFFFFF", width=8)
        self.week_label.pack(side=tk.LEFT, padx=5)
        
        # 下一周按钮
        next_btn = tk.Button(week_frame, text="▶",
                            command=self.next_week,
                            font=("微软雅黑", 12, "bold"),
                            bg="#34495e", fg="white",
                            relief=tk.FLAT, width=3)
        next_btn.pack(side=tk.LEFT)
        
    def setup_main_content(self):
        """设置主内容区域"""
        # 主框架
        main_container = tk.Frame(self.root, bg="#f0f2f5")
        main_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 上半部分：课表网格
        timetable_container = tk.Frame(main_container, bg="#f0f2f5")
        timetable_container.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # 创建课表网格
        self.create_timetable_grid(timetable_container)
        
        # 下半部分：状态栏
        status_frame = tk.Frame(main_container, bg="#ecf0f1", relief=tk.SUNKEN, bd=1)
        status_frame.pack(fill=tk.X)
        
        self.status_label = tk.Label(status_frame, textvariable=self.status_var,
                                    font=("微软雅黑", 12),
                                    bg="#ecf0f1", fg="black", anchor="w")
        self.status_label.pack(side=tk.LEFT, padx=10, pady=8)
        
    def create_timetable_grid(self, parent):
        """创建课表网格"""
        # 主框架
        main_frame = tk.Frame(parent, bg="#f0f2f5")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=30, pady=20)
        
        # 表头
        header_frame = tk.Frame(main_frame, bg="#f0f2f5")
        header_frame.pack(fill=tk.X, pady=(0, 10))
        
        # 左上角空格
        corner = tk.Label(header_frame, text="节次\\星期", 
                         font=("微软雅黑", 12, "bold"),
                         bg="#34495e", fg="white",
                         relief=tk.RAISED, bd=1, width=8, height=2)
        corner.grid(row=0, column=0, sticky="nsew", padx=1, pady=1)
        
        # 星期标题
        weekdays = ["一", "二", "三", "四", "五"]
        for col, day in enumerate(weekdays, 1):
            day_label = tk.Label(header_frame, text=f"星期{day}",
                               font=("微软雅黑", 12, "bold"),
                               bg="#3498db", fg="white",
                               relief=tk.RAISED, bd=1, width=20, height=2)
            day_label.grid(row=0, column=col, sticky="nsew", padx=1, pady=1)
        
        # 配置列权重
        for i in range(6):
            header_frame.grid_columnconfigure(i, weight=1)
        
        # 课程表主体
        grid_frame = tk.Frame(main_frame, bg="#f0f2f5")
        grid_frame.pack(fill=tk.BOTH, expand=True)
        
        # 初始化课程网格按钮
        self.course_buttons = []
        
        for row in range(13):  # 13节课
            button_row = []
            
            # 节次标签
            section_label = tk.Label(grid_frame, text=f"第{row+1}节",
                                   font=("微软雅黑", 10, "bold"),
                                   bg="#34495e", fg="white",
                                   relief=tk.RAISED, bd=1, width=8, height=3)
            section_label.grid(row=row, column=0, sticky="nsew", padx=1, pady=1)
            
            # 课程按钮
            for col in range(5):  # 5天
                btn = tk.Button(grid_frame, text="",
                              font=("微软雅黑", 9),
                              bg="#ecf0f1", fg="#2c3e50",
                              relief=tk.RAISED, bd=1,
                              wraplength=150,
                              justify=tk.CENTER,
                              command=lambda r=row, c=col: self.edit_course_cell(r, c))
                btn.grid(row=row, column=col+1, sticky="nsew", padx=1, pady=1)
                button_row.append(btn)
            
            self.course_buttons.append(button_row)
        
        # 配置网格权重
        for i in range(6):
            grid_frame.grid_columnconfigure(i, weight=1)
        for i in range(13):
            grid_frame.grid_rowconfigure(i, weight=1)
        
    # =================== 课表功能方法 ===================
    
    def load_courses(self):
        """加载课程数据"""
        try:
            if not DB_AVAILABLE:
                self.update_status("数据库功能不可用 - 请安装相关依赖", is_error=True)
                return
                
            self.update_status("正在加载课程数据...")
            
            # 清空当前课程网格
            for row in range(13):
                for col in range(5):
                    self.course_grid[row][col] = None
                    self.course_buttons[row][col].config(text="", bg="#ecf0f1")
            
            # 获取所有课程表
            table_names = get_all_table_names()
            if not table_names:
                self.update_status("暂无课程数据")
                return
            
            current_week = self.current_week.get()
            loaded_count = 0
            
            for table_name in table_names:
                try:
                    # 查询当前周的课程
                    courses = self.query_all_courses_from_table(table_name)
                    if courses:
                        for course in courses:
                            if course['week'] == current_week:
                                self.add_course_to_grid(course, table_name)
                                loaded_count += 1
                except Exception as e:
                    log_message("ERROR", f"加载课程表 {table_name} 失败: {str(e)}")
                    continue
            
            self.update_status(f"成功加载 {loaded_count} 门课程")
            log_message("INFO", f"课程加载完成，共 {loaded_count} 门课程")
            
        except Exception as e:
            error_msg = f"加载课程失败: {str(e)}"
            log_message("ERROR", error_msg)
            self.update_status(error_msg, is_error=True)
    
    def query_all_courses_from_table(self, table_name):
        """查询指定表中的所有课程"""
        try:
            if not check_table_exists(table_name):
                return []
                
            connection = get_db_connection()
            if connection is None:
                return []
                
            cursor = connection.cursor(pymysql.cursors.DictCursor)
            cursor.execute(f"SELECT * FROM `{table_name}`")
            courses = cursor.fetchall()
            cursor.close()
            connection.close()
            
            return courses if courses else []
            
        except Exception as e:
            log_message("ERROR", f"查询表 {table_name} 中的所有课程失败: {str(e)}")
            return []
    
    def add_course_to_grid(self, course, table_name):
        """将课程添加到网格中"""
        try:
            day = int(course['day'])
            time_str = course['time']
            
            # 解析时间段
            sections = self.parse_section_from_time(time_str)
            
            for section in sections:
                section_num = int(section.replace('第', '').replace('节', '')) - 1
                if 0 <= section_num < 13 and 0 <= day < 5:
                    # 保存课程信息
                    course_info = {
                        'table_name': table_name,
                        'teacher': course['teacher'],
                        'place': course['place'],
                        'time': section,
                        'week': course['week'],
                        'term': course['term'],
                        'id': course['id']
                    }
                    self.course_grid[section_num][day] = course_info
                    
                    # 更新按钮显示
                    display_text = f"{table_name}\n{course['teacher']}\n{course['place']}"
                    self.course_buttons[section_num][day].config(
                        text=display_text,
                        bg="#d5f4e6",
                        fg="#27ae60"
                    )
                    
        except Exception as e:
            log_message("ERROR", f"添加课程到网格失败: {str(e)}")
    
    def edit_course_cell(self, row, col):
        """编辑课程单元格"""
        try:
            course_data = self.course_grid[row][col]
            
            if course_data:
                # 编辑现有课程
                dialog = CourseEditDialog(self, course_data, is_new=False)
                self.root.wait_window(dialog.dialog)
                if dialog.result == 'success':
                    self.load_courses()  # 重新加载课程
            else:
                # 添加新课程
                # 预填充时间和星期信息
                default_data = {
                    'table_name': '',
                    'teacher': '',
                    'place': '',
                    'day': str(col),
                    'time': f"第{row+1}节",
                    'week': self.current_week.get(),
                    'term': '2024-2025学年第一学期'
                }
                dialog = CourseEditDialog(self, default_data, is_new=True)
                self.root.wait_window(dialog.dialog)
                if dialog.result == 'success':
                    self.load_courses()  # 重新加载课程
                    
        except Exception as e:
            error_msg = f"编辑课程失败: {str(e)}"
            log_message("ERROR", error_msg)
            self.update_status(error_msg, is_error=True)
    
    def add_course(self):
        """添加课程"""
        try:
            if not DB_AVAILABLE:
                self.messagebox.showerror("错误", "数据库功能不可用！")
                return
                
            # 创建添加课程对话框
            default_data = {
                'table_name': '',
                'teacher': '',
                'place': '',
                'day': '0',
                'time': '第1节',
                'week': self.current_week.get(),
                'term': '2024-2025学年第一学期'
            }
            dialog = CourseEditDialog(self, default_data, is_new=True)
            self.root.wait_window(dialog.dialog)
            if dialog.result == 'success':
                self.load_courses()  # 重新加载课程
                
        except Exception as e:
            error_msg = f"添加课程失败: {str(e)}"
            log_message("ERROR", error_msg)
            self.update_status(error_msg, is_error=True)
    
    def delete_all_courses(self):
        """删除所有课程"""
        try:
            if not DB_AVAILABLE:
                self.messagebox.showerror("错误", "数据库功能不可用！")
                return
                
            if self.messagebox.askyesno("确认删除", "确定要删除所有课程吗？此操作不可恢复！"):
                self.update_status("正在删除所有课程...")
                
                # 获取所有课程表并删除
                table_names = get_all_table_names()
                deleted_count = 0
                
                for table_name in table_names:
                    try:
                        # 删除整个表
                        connection = get_db_connection()
                        cursor = connection.cursor()
                        cursor.execute(f"DROP TABLE IF EXISTS `{table_name}`")
                        connection.commit()
                        cursor.close()
                        connection.close()
                        deleted_count += 1
                    except Exception as e:
                        log_message("ERROR", f"删除表 {table_name} 失败: {str(e)}")
                        continue
                
                self.load_courses()  # 重新加载（清空显示）
                self.update_status(f"成功删除 {deleted_count} 个课程表")
                
        except Exception as e:
            error_msg = f"删除所有课程失败: {str(e)}"
            log_message("ERROR", error_msg)
            self.update_status(error_msg, is_error=True)
    
    def import_excel(self):
        """导入Excel课表"""
        try:
            if not DB_AVAILABLE:
                self.messagebox.showerror("错误", "数据库功能不可用，无法导入课表！")
                return
                
            # 检查Excel处理库是否可用
            try:
                from openpyxl import load_workbook
                excel_available = True
            except ImportError:
                excel_available = False
            
            if not excel_available:
                self.update_status("Excel处理库不可用，请先安装openpyxl模块", is_error=True)
                self.messagebox.showerror("缺少依赖", "请先安装openpyxl模块以支持Excel导入功能")
                return
                
            file_path = filedialog.askopenfilename(
                title="选择Excel课表文件",
                filetypes=[
                    ("Excel文件", "*.xlsx *.xls"),
                    ("CSV文件", "*.csv"),
                    ("所有文件", "*.*")
                ]
            )
            
            if not file_path:
                return
            
            self.update_status("正在导入课表文件...")
            
            imported_count = 0
            
            # 根据文件扩展名选择处理方式
            if file_path.lower().endswith('.csv'):
                # 处理CSV文件
                imported_count = self.import_csv_file(file_path)
            else:
                # 处理Excel文件
                imported_count = self.import_excel_file(file_path)
            
            self.load_courses()  # 重新加载课程
            self.update_status(f"成功导入 {imported_count} 门课程")
            
        except Exception as e:
            error_msg = f"导入文件失败: {str(e)}"
            log_message("ERROR", error_msg)
            self.update_status(error_msg, is_error=True)
    
    def import_excel_file(self, file_path):
        """导入Excel文件"""
        from openpyxl import load_workbook
        import re
        
        # 首先尝试解析传统课表格式（如data.xlsx）
        try:
            if self.is_traditional_timetable_format(file_path):
                return self.import_traditional_timetable(file_path)
        except Exception as e:
            log_message("INFO", f"传统课表格式解析失败，尝试标准格式: {str(e)}")
        
        # 标准Excel格式导入
        workbook = load_workbook(file_path)
        sheet = workbook.active
        
        imported_count = 0
        for row in sheet.iter_rows(min_row=2, values_only=True):  # 跳过标题行
            if len(row) >= 6 and row[0]:  # 确保有足够的列和课程名称不为空
                course_name = str(row[0]).strip()
                teacher = str(row[1] or '').strip()
                place = str(row[2] or '').strip()
                day = str(row[3] or '0').strip()
                time = str(row[4] or '第1节').strip()
                week = int(row[5] or 1)
                term = str(row[6] or '2024-2025学年第一学期').strip() if len(row) > 6 else '2024-2025学年第一学期'
                
                if self.import_single_course(course_name, teacher, place, day, time, week, term):
                    imported_count += 1
        
        return imported_count
    
    def is_traditional_timetable_format(self, file_path):
        """检测是否为传统课表格式（如data.xlsx）"""
        from openpyxl import load_workbook
        
        workbook = load_workbook(file_path)
        sheet = workbook.active
        
        # 检查是否包含"星期"字样和"节"字样
        has_weekday = False
        has_period = False
        
        for row in sheet.iter_rows(values_only=True):
            for cell in row:
                if cell and isinstance(cell, str):
                    if '星期' in cell:
                        has_weekday = True
                    if '节' in cell:
                        has_period = True
                        
        return has_weekday and has_period
    
    def import_traditional_timetable(self, file_path):
        """导入传统课表格式（如data.xlsx）"""
        from openpyxl import load_workbook
        import re
        
        self.update_status("检测到传统课表格式，正在解析...")
        
        # 加载Excel工作簿
        workbook = load_workbook(file_path)
        sheet = workbook.active

        # 获取星期列名
        weekdays = ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日']
        weekday_map = {day: idx for idx, day in enumerate(weekdays)}

        imported_count = 0
        
        # 遍历每一行
        for row in sheet.iter_rows(values_only=True):
            # 获取时间节次（A列）
            time_slot = row[0] if row[0] else ""

            # 只处理包含"节"的时间行
            if "节" not in str(time_slot):
                continue

            # 遍历每个工作日列
            for col_idx, weekday_str in enumerate(weekdays, 1):
                # 跳过超出列范围的索引
                if col_idx >= len(row):
                    continue

                cell_value = row[col_idx]
                if not cell_value:
                    continue

                # 分割多个课程（按逗号分隔）
                raw_courses = [c.strip() for c in str(cell_value).split(',') if c.strip()]

                for course_str in raw_courses:
                    # 分割课程详细信息（按<br>或换行符）
                    parts = [p.strip() for p in re.split('<br>|\n', course_str) if p.strip()]

                    if len(parts) < 3:
                        continue

                    course_name = parts[0]
                    teacher = parts[1]
                    time_location = parts[2]

                    # 解析时间和地点
                    location = ""
                    time_info = ""

                    # 尝试分割时间和地点
                    if ', ' in time_location:
                        time_info, location = time_location.split(', ', 1)
                    elif ',' in time_location:
                        time_info, location = time_location.split(',', 1)
                    elif '， ' in time_location:  # 中文逗号加空格
                        time_info, location = time_location.split('， ', 1)
                    elif '，' in time_location:  # 中文逗号
                        time_info, location = time_location.split('，', 1)
                    else:
                        time_info = time_location

                    # 解析周次和节次
                    week_match = re.search(r'(\d+)周', time_info)
                    period_match = re.search(r'(\d+-\d+)节', time_info)

                    week_num = week_match.group(1) if week_match else "1"
                    period = period_match.group(1) if period_match else time_slot

                    # 将星期字符串转换为数字
                    weekday_num = weekday_map.get(weekday_str, 0)

                    # 导入课程
                    if self.import_single_course(
                        course_name, 
                        teacher, 
                        location.strip(), 
                        str(weekday_num), 
                        period, 
                        int(week_num), 
                        '2024-2025学年第一学期'
                    ):
                        imported_count += 1

        return imported_count
    
    def import_csv_file(self, file_path):
        """导入CSV文件"""
        imported_count = 0
        
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            
        # 跳过标题行
        for line in lines[1:]:
            if line.strip():
                try:
                    parts = line.strip().split(',')
                    if len(parts) >= 6:
                        course_name = parts[0].strip()
                        teacher = parts[1].strip()
                        place = parts[2].strip()
                        day = parts[3].strip()
                        time = parts[4].strip()
                        week = int(parts[5].strip())
                        term = parts[6].strip() if len(parts) > 6 else '2024-2025学年第一学期'
                        
                        if self.import_single_course(course_name, teacher, place, day, time, week, term):
                            imported_count += 1
                except Exception as e:
                    log_message("ERROR", f"导入CSV行失败: {str(e)}")
                    continue
        
        return imported_count
    
    def import_single_course(self, course_name, teacher, place, day, time, week, term):
        """导入单个课程"""
        try:
            if not course_name:
                return False
                
            # 清理课程名称
            cleaned_name = course_name.replace('+', '和').replace(' ', '_')
            
            if insert_into_table(cleaned_name, place, time, week, teacher, day, term):
                return True
            else:
                log_message("ERROR", f"导入课程 {course_name} 失败")
                return False
                
        except Exception as e:
            log_message("ERROR", f"导入课程 {course_name} 失败: {str(e)}")
            return False
    
    def prev_week(self):
        """上一周"""
        if self.current_week.get() > 1:
            self.current_week.set(self.current_week.get() - 1)
            self.week_label.config(text=f"第 {self.current_week.get()} 周")
            self.load_courses()
            self.update_status(f"切换到第 {self.current_week.get()} 周")
    
    def next_week(self):
        """下一周"""
        if self.current_week.get() < 30:  # 最多30周
            self.current_week.set(self.current_week.get() + 1)
            self.week_label.config(text=f"第 {self.current_week.get()} 周")
            self.load_courses()
            self.update_status(f"切换到第 {self.current_week.get()} 周")
    
    def parse_section_from_time(self, time_str):
        """从时间字符串解析节次信息"""
        if '-' in time_str:
            # 连续课程，如"1-2节"、"第1-3节"
            parts = time_str.replace('第', '').replace('节', '').split('-')
            start_section = int(parts[0])
            end_section = int(parts[1])
            return [f"第{i}节" for i in range(start_section, end_section + 1)]
        else:
            # 单节课程，如"第1节"
            if '第' in time_str:
                return [time_str]
            else:
                # 处理纯数字格式
                section_num = time_str.replace('节', '')
                return [f"第{section_num}节"]
    
    def setup_smart_reminders(self):
        """设置智能提醒系统"""
        try:
            if not DB_AVAILABLE:
                return
            
            # 启动后台提醒检查
            self.reminder_enabled = True
            self.reminder_advance_minutes = 10  # 提前10分钟提醒
            self.reminded_courses = set()  # 记录已提醒的课程，避免重复提醒
            
            # 启动定时检查任务
            self.start_reminder_check()
            
            self.update_status("智能提醒系统已启用（提前10分钟提醒）")
            log_message("INFO", "智能提醒系统已启用")
            
        except Exception as e:
            error_msg = f"设置智能提醒失败: {str(e)}"
            log_message("ERROR", error_msg)
            self.update_status(error_msg, is_error=True)
    
    def start_reminder_check(self):
        """启动定时提醒检查"""
        try:
            # 立即检查一次
            self.check_upcoming_courses()
            
            # 每分钟检查一次
            if self.reminder_enabled:
                self.root.after(60000, self.start_reminder_check)  # 60秒后再次检查
                
        except Exception as e:
            log_message("ERROR", f"提醒检查失败: {str(e)}")
    
    def check_upcoming_courses(self):
        """检查即将开始的课程"""
        try:
            if not DB_AVAILABLE or not self.reminder_enabled:
                return
            
            current_time = datetime.now()
            current_weekday = current_time.weekday()  # 0=周一, 6=周日
            current_week = self.current_week.get()
            
            # 只检查工作日（周一到周五）
            if current_weekday >= 5:
                return
            
            # 获取所有课程表
            table_names = get_all_table_names()
            
            for table_name in table_names:
                try:
                    courses = self.query_all_courses_from_table(table_name)
                    if not courses:
                        continue
                    
                    for course in courses:
                        # 检查是否是当前周和当前星期的课程
                        if (course['week'] == current_week and 
                            int(course['day']) == current_weekday):
                            
                            # 解析课程时间段
                            sections = self.parse_section_from_time(course['time'])
                            
                            for section in sections:
                                if section in self.section_time_map:
                                    course_start_time = self.get_course_start_time(current_time.date(), section)
                                    
                                    # 计算提醒时间
                                    reminder_time = course_start_time - timedelta(minutes=self.reminder_advance_minutes)
                                    
                                    # 创建课程唯一标识
                                    course_id = f"{table_name}_{course['id']}_{section}_{current_time.date()}"
                                    
                                    # 检查是否应该提醒
                                    if (current_time >= reminder_time and 
                                        current_time <= course_start_time and
                                        course_id not in self.reminded_courses):
                                        
                                        self.send_course_reminder(table_name, course, section, course_start_time)
                                        self.reminded_courses.add(course_id)
                
                except Exception as e:
                    log_message("ERROR", f"检查课程表 {table_name} 的提醒失败: {str(e)}")
                    continue
            
            # 清理过期的提醒记录（清理昨天之前的记录）
            self.cleanup_old_reminders()
            
        except Exception as e:
            log_message("ERROR", f"检查即将开始的课程失败: {str(e)}")
    
    def get_course_start_time(self, date, section):
        """获取课程开始时间"""
        if section in self.section_time_map:
            hour, minute = self.section_time_map[section]
            return datetime.combine(date, datetime.min.time().replace(hour=hour, minute=minute))
        return None
    
    def send_course_reminder(self, course_name, course_info, section, start_time):
        """发送课程提醒"""
        try:
            # 格式化提醒信息
            start_time_str = start_time.strftime("%H:%M")
            
            title = "📚 课程提醒"
            message = (f"课程：{course_name}\n"
                      f"教师：{course_info['teacher']}\n"
                      f"时间：{section} ({start_time_str})\n"
                      f"地点：{course_info['place']}\n"
                      f"⏰ {self.reminder_advance_minutes}分钟后开始")
            
            # 记录提醒日志
            log_message("REMINDER", f"课程提醒: {course_name} - {section} - {start_time_str}")
            
            # 显示在状态栏
            self.update_status(f"提醒: {course_name} {section} {start_time_str}开始", duration=8000)
            
            # 发送系统通知
            self.show_system_notification(title, message)
            
            # 在控制台也输出（用于调试）
            print(f"\n🔔 {title}")
            print(f"📖 {message}")
            
        except Exception as e:
            log_message("ERROR", f"发送课程提醒失败: {str(e)}")
    
    def show_system_notification(self, title, message):
        """显示系统通知"""
        try:
            # Windows系统通知
            if os.name == 'nt':  # Windows
                import subprocess
                
                # 使用PowerShell显示Toast通知
                ps_script = f'''
                Add-Type -AssemblyName System.Windows.Forms
                $notification = New-Object System.Windows.Forms.NotifyIcon
                $notification.Icon = [System.Drawing.SystemIcons]::Information
                $notification.BalloonTipTitle = "{title}"
                $notification.BalloonTipText = "{message.replace(chr(10), " | ")}"
                $notification.Visible = $true
                $notification.ShowBalloonTip(5000)
                Start-Sleep -Seconds 6
                $notification.Dispose()
                '''
                
                try:
                    subprocess.run(['powershell', '-Command', ps_script], 
                                 capture_output=True, timeout=10)
                except subprocess.TimeoutExpired:
                    pass  # 忽略超时错误
                except Exception:
                    # 如果PowerShell方式失败，尝试简单的命令行通知
                    subprocess.run(['msg', '*', f"{title}\n{message}"], 
                                 capture_output=True)
            
        except Exception as e:
            log_message("ERROR", f"显示系统通知失败: {str(e)}")
    
    def cleanup_old_reminders(self):
        """清理过期的提醒记录"""
        try:
            current_date = datetime.now().date()
            yesterday = current_date - timedelta(days=1)
            
            # 移除昨天之前的提醒记录
            self.reminded_courses = {
                course_id for course_id in self.reminded_courses 
                if not course_id.endswith(str(yesterday))
            }
            
        except Exception as e:
            log_message("ERROR", f"清理过期提醒记录失败: {str(e)}")
    
    def toggle_reminders(self):
        """切换提醒功能开关"""
        try:
            if hasattr(self, 'reminder_enabled'):
                self.reminder_enabled = not self.reminder_enabled
                if self.reminder_enabled:
                    self.start_reminder_check()
                    self.update_status("课程提醒已启用")
                else:
                    self.update_status("课程提醒已关闭")
            else:
                self.setup_smart_reminders()
                
        except Exception as e:
            log_message("ERROR", f"切换提醒功能失败: {str(e)}")
    
    def set_reminder_advance(self, minutes):
        """设置提醒提前时间"""
        try:
            if 1 <= minutes <= 60:
                self.reminder_advance_minutes = minutes
                self.update_status(f"提醒时间已设置为提前{minutes}分钟")
                log_message("INFO", f"提醒时间设置为提前{minutes}分钟")
            else:
                self.update_status("提醒时间应在1-60分钟之间", is_error=True)
                
        except Exception as e:
            log_message("ERROR", f"设置提醒时间失败: {str(e)}")
    
    def open_reminder_settings(self):
        """打开提醒设置对话框"""
        try:
            # 创建设置对话框
            settings_window = tk.Toplevel(self.root)
            settings_window.title("⏰ 课程提醒设置")
            settings_window.geometry("400x300")
            settings_window.transient(self.root)
            settings_window.grab_set()
            
            # 居中显示
            settings_window.update_idletasks()
            x = (settings_window.winfo_screenwidth() // 2) - (400 // 2)
            y = (settings_window.winfo_screenheight() // 2) - (300 // 2)
            settings_window.geometry(f"400x300+{x}+{y}")
            settings_window.configure(bg="#f0f2f5")
            
            # 主框架
            main_frame = tk.Frame(settings_window, bg="#f0f2f5")
            main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
            
            # 标题
            title_label = tk.Label(main_frame, text="📚 智能课程提醒设置", 
                                  font=("微软雅黑", 16, "bold"),
                                  bg="#f0f2f5", fg="#2c3e50")
            title_label.pack(pady=(0, 20))
            
            # 提醒开关
            switch_frame = tk.Frame(main_frame, bg="#f0f2f5")
            switch_frame.pack(fill=tk.X, pady=10)
            
            tk.Label(switch_frame, text="提醒功能:", font=("微软雅黑", 12),
                    bg="#f0f2f5", fg="#34495e").pack(side=tk.LEFT)
            
            # 获取当前提醒状态
            reminder_status = getattr(self, 'reminder_enabled', False)
            status_text = "已启用 ✅" if reminder_status else "已关闭 ❌"
            status_color = "#27ae60" if reminder_status else "#e74c3c"
            
            self.status_label_reminder = tk.Label(switch_frame, text=status_text, 
                                                 font=("微软雅黑", 12, "bold"),
                                                 bg="#f0f2f5", fg=status_color)
            self.status_label_reminder.pack(side=tk.LEFT, padx=(10, 0))
            
            # 开关按钮
            toggle_btn = tk.Button(switch_frame, text="切换开关",
                                  command=lambda: self.toggle_reminder_and_update_ui(settings_window),
                                  font=("微软雅黑", 10), bg="#3498db", fg="white",
                                  relief=tk.FLAT, padx=10, pady=5)
            toggle_btn.pack(side=tk.RIGHT)
            
            # 提前时间设置
            time_frame = tk.Frame(main_frame, bg="#f0f2f5")
            time_frame.pack(fill=tk.X, pady=15)
            
            tk.Label(time_frame, text="提前提醒时间:", font=("微软雅黑", 12),
                    bg="#f0f2f5", fg="#34495e").pack(side=tk.LEFT)
            
            # 时间选择
            time_var = tk.IntVar()
            current_advance = getattr(self, 'reminder_advance_minutes', 10)
            time_var.set(current_advance)
            
            time_spinbox = tk.Spinbox(time_frame, from_=1, to=60, width=10,
                                     textvariable=time_var, font=("微软雅黑", 11))
            time_spinbox.pack(side=tk.LEFT, padx=(10, 5))
            
            tk.Label(time_frame, text="分钟", font=("微软雅黑", 12),
                    bg="#f0f2f5", fg="#34495e").pack(side=tk.LEFT)
            
            # 设置按钮
            set_time_btn = tk.Button(time_frame, text="设置",
                                    command=lambda: self.set_reminder_advance(time_var.get()),
                                    font=("微软雅黑", 10), bg="#f39c12", fg="white",
                                    relief=tk.FLAT, padx=10, pady=5)
            set_time_btn.pack(side=tk.RIGHT)
            
            # 测试提醒
            test_frame = tk.Frame(main_frame, bg="#f0f2f5")
            test_frame.pack(fill=tk.X, pady=15)
            
            test_btn = tk.Button(test_frame, text="🔔 测试提醒功能",
                                command=self.test_reminder,
                                font=("微软雅黑", 12, "bold"),
                                bg="#e74c3c", fg="white",
                                relief=tk.FLAT, padx=20, pady=8)
            test_btn.pack()
            
            # 当前状态信息
            info_frame = tk.Frame(main_frame, bg="#ecf0f1", relief=tk.SUNKEN, bd=1)
            info_frame.pack(fill=tk.X, pady=(20, 0))
            
            info_text = (f"📋 当前设置:\n"
                        f"• 提醒状态: {'启用' if reminder_status else '关闭'}\n"
                        f"• 提前时间: {current_advance} 分钟\n"
                        f"• 检查频率: 每分钟检查一次\n"
                        f"• 工作时间: 周一至周五")
            
            info_label = tk.Label(info_frame, text=info_text,
                                 font=("微软雅黑", 10), bg="#ecf0f1", fg="#2c3e50",
                                 justify=tk.LEFT)
            info_label.pack(padx=15, pady=10)
            
            # 关闭按钮
            close_btn = tk.Button(main_frame, text="关闭",
                                 command=settings_window.destroy,
                                 font=("微软雅黑", 12), bg="#95a5a6", fg="white",
                                 relief=tk.FLAT, padx=20, pady=8)
            close_btn.pack(pady=(20, 0))
            
        except Exception as e:
            log_message("ERROR", f"打开提醒设置失败: {str(e)}")
            self.update_status("打开提醒设置失败", is_error=True)
    
    def toggle_reminder_and_update_ui(self, window):
        """切换提醒并更新UI"""
        try:
            self.toggle_reminders()
            
            # 更新状态标签
            reminder_status = getattr(self, 'reminder_enabled', False)
            status_text = "已启用 ✅" if reminder_status else "已关闭 ❌"
            status_color = "#27ae60" if reminder_status else "#e74c3c"
            
            if hasattr(self, 'status_label_reminder'):
                self.status_label_reminder.config(text=status_text, fg=status_color)
                
        except Exception as e:
            log_message("ERROR", f"切换提醒状态失败: {str(e)}")
    
    def test_reminder(self):
        """测试提醒功能"""
        try:
            title = "📚 测试提醒"
            message = ("这是一个测试提醒！\n"
                      "如果您看到这个通知，说明提醒功能正常工作。\n"
                      "⏰ 提醒功能已就绪")
            
            log_message("TEST", "用户测试提醒功能")
            self.update_status("发送测试提醒中...", duration=3000)
            
            # 发送测试通知
            self.show_system_notification(title, message)
            
            # 控制台输出
            print(f"\n🔔 {title}")
            print(f"📖 {message}")
            
        except Exception as e:
            log_message("ERROR", f"测试提醒失败: {str(e)}")
            self.update_status("测试提醒失败", is_error=True)
    
    def on_closing(self):
        """关闭程序时的处理"""
        try:
            # 停止提醒系统
            if hasattr(self, 'reminder_enabled'):
                self.reminder_enabled = False
            
            # 停止调度器
            if hasattr(self, 'scheduler') and self.scheduler.running:
                self.scheduler.shutdown()
            
            log_message("INFO", "智能课表系统关闭")
            self.root.destroy()
        except Exception as e:
            log_message("ERROR", f"关闭程序失败: {str(e)}")
    
    def run(self):
        """运行程序"""
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.root.mainloop()

if __name__ == "__main__":
    try:
        app = SmartTimetableApp()
        app.run()
    except Exception as e:
        print(f"程序启动失败: {str(e)}")
        log_message("CRITICAL", f"程序启动失败: {str(e)}")
        input("按回车键退出...") 