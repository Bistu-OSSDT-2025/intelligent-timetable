#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
智能课表系统 - 导入功能测试脚本
用于验证各种导入格式是否正常工作
"""

import os
import sys

def test_import_functions():
    """测试所有导入功能"""
    print("=== 智能课表系统导入功能测试 ===\n")
    
    # 检查文件是否存在
    files_to_check = [
        ('智能课表.py', '主程序'),
        ('data.xlsx', '传统课表格式'),
        ('课程导入模板.csv', 'CSV模板'),
        ('app_pandes.py', '解析程序')
    ]
    
    print("1. 检查必要文件...")
    missing_files = []
    for filename, description in files_to_check:
        if os.path.exists(filename):
            print(f"✓ {filename} - {description}")
        else:
            print(f"✗ {filename} - {description} (缺失)")
            missing_files.append(filename)
    
    if missing_files:
        print(f"\n错误：缺少文件 {missing_files}")
        return False
    
    print("\n2. 测试传统课表格式识别...")
    try:
        # 导入主程序
        from 智能课表 import SmartTimetableApp
        app = SmartTimetableApp()
        
        # 测试格式识别
        is_traditional = app.is_traditional_timetable_format('data.xlsx')
        print(f"✓ data.xlsx 格式识别: {'传统课表' if is_traditional else '标准格式'}")
        
        if is_traditional:
            print("✓ 系统能够正确识别传统课表格式")
        else:
            print("⚠ 警告：未能识别传统课表格式")
            
    except Exception as e:
        print(f"✗ 格式识别测试失败: {str(e)}")
        return False
    
    print("\n3. 测试CSV模板...")
    try:
        with open('课程导入模板.csv', 'r', encoding='utf-8') as f:
            lines = f.readlines()
            if len(lines) >= 2:
                print(f"✓ CSV模板包含 {len(lines)} 行数据")
                print(f"✓ 表头: {lines[0].strip()}")
            else:
                print("⚠ 警告：CSV模板内容不足")
    except Exception as e:
        print(f"✗ CSV模板测试失败: {str(e)}")
        return False
    
    print("\n4. 测试依赖库...")
    dependencies = [
        ('tkinter', '图形界面库'),
        ('datetime', '时间处理库'),
        ('os', '系统操作库')
    ]
    
    for module_name, description in dependencies:
        try:
            __import__(module_name)
            print(f"✓ {module_name} - {description}")
        except ImportError:
            print(f"✗ {module_name} - {description} (缺失)")
    
    # 测试可选依赖
    optional_deps = [
        ('openpyxl', 'Excel处理库'),
        ('pymysql', '数据库连接库')
    ]
    
    print("\n5. 检查可选依赖...")
    for module_name, description in optional_deps:
        try:
            __import__(module_name)
            print(f"✓ {module_name} - {description}")
        except ImportError:
            print(f"- {module_name} - {description} (可选，未安装)")
    
    print("\n=== 测试完成 ===")
    print("\n📋 功能说明:")
    print("• 传统课表导入：支持data.xlsx格式，自动识别解析")
    print("• CSV导入：支持简单的逗号分隔格式")
    print("• 标准Excel导入：支持规范的行列格式")
    print("• 智能识别：系统自动选择合适的解析方式")
    
    print("\n🚀 使用建议:")
    print("• 直接导入data.xlsx文件测试传统课表功能")
    print("• 使用'课程导入模板.csv'创建新的课程数据")
    print("• 运行'启动智能课表.bat'启动完整系统")
    
    return True

if __name__ == "__main__":
    try:
        success = test_import_functions()
        if success:
            print("\n✅ 所有测试通过！系统准备就绪。")
        else:
            print("\n❌ 测试失败，请检查错误信息。")
    except Exception as e:
        print(f"\n💥 测试过程中出现异常: {str(e)}")
        import traceback
        traceback.print_exc()
    
    input("\n按回车键退出...") 