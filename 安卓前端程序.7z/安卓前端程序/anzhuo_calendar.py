#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
智能课表系统 - 安卓端完整版 v4.0
基于桌面端框架设计，实现完整的课表管理功能
"""

import os
from datetime import datetime, timedelta
import threading
import json

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.popup import Popup
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.graphics import Color, Rectangle, Line
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.core.text import LabelBase
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.switch import Switch
from kivy.factory import Factory

# 导入Excel处理相关库
try:
    import pandas as pd
    import openpyxl
    EXCEL_AVAILABLE = True
    print("Excel处理库加载成功")
except ImportError as e:
    print(f"Excel处理库加载失败: {e}")
    EXCEL_AVAILABLE = False

# 导入通知库
try:
    from plyer import notification
    NOTIFICATION_AVAILABLE = True
    print("系统通知库加载成功")
except ImportError as e:
    print(f"系统通知库加载失败: {e}")
    NOTIFICATION_AVAILABLE = False

# 注册中文字体
def setup_chinese_font():
    """设置中文字体支持"""
    try:
        font_paths = [
            "C:/Windows/Fonts/msyh.ttc",     # 微软雅黑
            "C:/Windows/Fonts/simsun.ttc",   # 宋体
            "C:/Windows/Fonts/simhei.ttf"    # 黑体
        ]
        
        for font_path in font_paths:
            if os.path.exists(font_path):
                LabelBase.register(name="Chinese", fn_regular=font_path)
                print(f"中文字体加载成功: {font_path}")
                return True
        
        print("未找到中文字体，使用默认字体")
        return False
    except Exception as e:
        print(f"字体加载失败: {e}")
        return False

# 设置字体
FONT_LOADED = setup_chinese_font()
FONT_NAME = "Chinese" if FONT_LOADED else "Roboto"

# 导入数据库模块
try:
    from mysqlconnect import get_db_connection, get_all_table_names, check_table_exists, \
        query_by_id_and_table, update_field, insert_into_table, delete_by_id_and_table
    import pymysql
    import pandas as pd
    DB_AVAILABLE = True
    print("数据库模块加载成功")
except ImportError as e:
    print(f"数据库模块加载失败: {e}")
    DB_AVAILABLE = False

# 主题颜色 - 现代移动端美化配色
class Theme:
    # 主色调 - 现代蓝紫渐变
    PRIMARY = (0.20, 0.51, 0.96, 1)     # #3478F6 - 鲜艳蓝色主色调
    PRIMARY_LIGHT = (0.33, 0.61, 0.98, 1)  # #5497FB - 浅蓝色
    PRIMARY_DARK = (0.12, 0.38, 0.85, 1)   # #1F61D9 - 深蓝色
    
    # 辅助色
    SECONDARY = (0.44, 0.20, 0.96, 1)   # #7033F6 - 紫色次要色
    ACCENT = (0.20, 0.88, 0.69, 1)      # #33E0B0 - 青绿强调色
    
    # 功能色 - 更鲜艳活泼
    SUCCESS = (0.00, 0.80, 0.44, 1)     # #00CC70 - 活力绿
    WARNING = (1.00, 0.58, 0.00, 1)     # #FF9500 - 橘橙色
    DANGER = (1.00, 0.27, 0.27, 1)      # #FF4545 - 珊瑚红
    INFO = (0.20, 0.74, 1.00, 1)        # #33BDFF - 天空蓝
    
    # 特殊色
    PURPLE = (0.73, 0.33, 0.96, 1)      # #BA55F6 - 亮紫色
    PINK = (1.00, 0.33, 0.73, 1)        # #FF55BA - 粉红色
    TEAL = (0.20, 0.84, 0.84, 1)        # #33D6D6 - 青色
    
    # 背景色系 - 更干净现代
    LIGHT = (0.98, 0.98, 1.00, 1)       # #FAFAFF - 极浅蓝白
    CARD = (1.00, 1.00, 1.00, 1)        # #FFFFFF - 纯白卡片
    CARD_HOVER = (0.96, 0.98, 1.00, 1)  # #F5FAFF - 悬停效果
    
    # 文字色系
    DARK = (0.13, 0.16, 0.24, 1)        # #21293D - 深色文字
    GRAY = (0.47, 0.52, 0.62, 1)        # #78849E - 灰色文字
    WHITE = (1.00, 1.00, 1.00, 1)       # #FFFFFF - 白色
    
    # 边框和分割线
    BORDER = (0.91, 0.93, 0.96, 1)      # #E8EEF5 - 浅色边框
    DIVIDER = (0.95, 0.96, 0.98, 1)     # #F2F5FA - 分割线
    
    # 渐变色定义
    GRADIENT_START = PRIMARY
    GRADIENT_END = SECONDARY
    
    # 课程颜色 - 多彩方案
    COURSE_COLORS = [
        (0.20, 0.51, 0.96, 1),  # 蓝色
        (0.44, 0.20, 0.96, 1),  # 紫色
        (0.00, 0.80, 0.44, 1),  # 绿色
        (1.00, 0.58, 0.00, 1),  # 橙色
        (1.00, 0.27, 0.27, 1),  # 红色
        (0.73, 0.33, 0.96, 1),  # 亮紫
        (0.20, 0.84, 0.84, 1),  # 青色
        (1.00, 0.33, 0.73, 1),  # 粉色
    ]

# 时间段定义 - 13节课制
TIME_SLOTS = [
    ("08:00", "08:45"),   # 第1节
    ("08:55", "09:40"),   # 第2节
    ("10:00", "10:45"),   # 第3节
    ("10:55", "11:40"),   # 第4节
    ("13:30", "14:15"),   # 第5节
    ("14:25", "15:10"),   # 第6节
    ("15:20", "16:05"),   # 第7节
    ("16:15", "17:00"),   # 第8节
    ("17:10", "17:55"),   # 第9节
    ("19:00", "19:45"),   # 第10节
    ("19:55", "20:40"),   # 第11节
    ("20:50", "21:35"),   # 第12节
    ("21:45", "22:30")    # 第13节
]

# 星期名称
WEEKDAYS = ["周一", "周二", "周三", "周四", "周五"]

def clean_text(text):
    """清理文本，移除可能导致乱码的字符"""
    if not text:
        return ""
    
    text = str(text).strip()
    
    # 替换常见的特殊字符
    replacements = {
        '"': '"', '"': '"', ''': "'", ''': "'",
        '…': "...", '—': "-", '–': "-",
        '\u200b': '', '\ufeff': '',
    }
    
    for old, new in replacements.items():
        text = text.replace(old, new)
    
    return text

def log_message(message_type, message):
    """记录日志信息"""
    try:
        log_file = os.path.join(os.path.dirname(__file__), 'app.log')
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f'{datetime.now().strftime("%Y-%m-%d %H:%M:%S")} [{message_type}]: {message}\n')
    except:
        pass

# 文件导入对话框
class FileImportDialog(Popup):
    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.title = "导入课表文件"
        self.size_hint = (0.9, 0.9)
        self.auto_dismiss = False
        self.result = None
        
        self.setup_ui()
    
    def setup_ui(self):
        """设置文件选择界面"""
        main_layout = BoxLayout(orientation='vertical', spacing=10, padding=15)
        
        # 标题
        title_label = Label(
            text="选择课表文件进行导入",
            font_size=18,
            bold=True,
            color=Theme.DARK,
            font_name=FONT_NAME,
            size_hint_y=None,
            height=40
        )
        main_layout.add_widget(title_label)
        
        # 文件类型说明
        info_label = Label(
            text="支持格式：Excel文件(.xlsx, .xls) 和 CSV文件(.csv)",
            font_size=14,
            color=Theme.GRAY,
            font_name=FONT_NAME,
            size_hint_y=None,
            height=30
        )
        main_layout.add_widget(info_label)
        
        # 文件选择器
        self.file_chooser = FileChooserListView(
            path='.',
            filters=['*.xlsx', '*.xls', '*.csv'],
            size_hint_y=0.7
        )
        main_layout.add_widget(self.file_chooser)
        
        # 按钮区域
        button_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=50, spacing=10)
        
        cancel_btn = Button(
            text="取消",
            background_color=Theme.GRAY,
            color=Theme.WHITE,
            font_name=FONT_NAME,
            size_hint_x=0.3
        )
        cancel_btn.bind(on_press=self.cancel_import)
        
        import_btn = Button(
            text="开始导入",
            background_color=Theme.PRIMARY,
            color=Theme.WHITE,
            font_name=FONT_NAME,
            size_hint_x=0.7
        )
        import_btn.bind(on_press=self.start_import)
        
        button_layout.add_widget(cancel_btn)
        button_layout.add_widget(import_btn)
        main_layout.add_widget(button_layout)
        
        self.content = main_layout
    
    def cancel_import(self, instance):
        """取消导入"""
        self.result = 'cancel'
        self.dismiss()
    
    def start_import(self, instance):
        """开始导入文件"""
        if not self.file_chooser.selection:
            self.app.update_status("请选择要导入的文件", is_error=True)
            return
        
        file_path = self.file_chooser.selection[0]
        self.result = file_path
        self.dismiss()

# 提醒列表对话框
class RemindersListDialog(Popup):
    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.title = "课程提醒列表"
        self.size_hint = (0.95, 0.85)
        self.auto_dismiss = True
        
        self.setup_ui()
        self.load_reminders()
    
    def setup_ui(self):
        """设置提醒列表界面"""
        main_layout = BoxLayout(orientation='vertical', spacing=10, padding=15)
        
        # 标题和状态信息
        header_layout = BoxLayout(orientation='vertical', size_hint_y=None, height=80, spacing=5)
        
        title_label = Label(
            text="智能课程提醒列表",
            font_size=18,
            bold=True,
            color=Theme.DARK,
            font_name=FONT_NAME,
            size_hint_y=None,
            height=30
        )
        header_layout.add_widget(title_label)
        
        # 提醒状态信息
        status_text = f"提醒状态: {'已启用' if self.app.reminder_enabled else '已关闭'}"
        if self.app.reminder_enabled:
            status_text += f" | 提前时间: {self.app.reminder_advance_minutes}分钟"
        
        status_label = Label(
            text=status_text,
            font_size=14,
            color=Theme.GRAY,
            font_name=FONT_NAME,
            size_hint_y=None,
            height=25
        )
        header_layout.add_widget(status_label)
        
        # 今日课程提醒信息
        today_info = self.get_today_reminder_info()
        today_label = Label(
            text=today_info,
            font_size=12,
            color=Theme.INFO[0:3] + (1,),
            font_name=FONT_NAME,
            size_hint_y=None,
            height=25
        )
        header_layout.add_widget(today_label)
        
        main_layout.add_widget(header_layout)
        
        # 分隔线
        separator = Label(
            text="-" * 50,
            color=Theme.BORDER,
            size_hint_y=None,
            height=20
        )
        main_layout.add_widget(separator)
        
        # 滚动区域
        scroll = ScrollView()
        
        # 提醒列表容器
        self.reminders_layout = BoxLayout(
            orientation='vertical',
            size_hint_y=None,
            spacing=8
        )
        self.reminders_layout.bind(minimum_height=self.reminders_layout.setter('height'))
        
        scroll.add_widget(self.reminders_layout)
        main_layout.add_widget(scroll)
        
        # 底部按钮
        button_layout = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=50,
            spacing=10
        )
        
        # 刷新按钮
        refresh_btn = Button(
            text="刷新列表",
            background_color=Theme.INFO,
            color=Theme.WHITE,
            font_name=FONT_NAME,
            size_hint_x=0.3
        )
        refresh_btn.bind(on_press=lambda x: self.load_reminders())
        button_layout.add_widget(refresh_btn)
        
        # 测试提醒按钮
        test_btn = Button(
            text="测试提醒",
            background_color=Theme.WARNING,
            color=Theme.WHITE,
            font_name=FONT_NAME,
            size_hint_x=0.3
        )
        test_btn.bind(on_press=lambda x: self.app.test_reminder_function())
        button_layout.add_widget(test_btn)
        
        # 关闭按钮
        close_btn = Button(
            text="关闭",
            background_color=Theme.GRAY,
            color=Theme.WHITE,
            font_name=FONT_NAME,
            size_hint_x=0.4
        )
        close_btn.bind(on_press=self.dismiss)
        button_layout.add_widget(close_btn)
        
        main_layout.add_widget(button_layout)
        self.content = main_layout
    
    def get_today_reminder_info(self):
        """获取今日提醒信息"""
        try:
            from datetime import datetime
            
            current_time = datetime.now()
            current_weekday = current_time.weekday()  # 0=周一, 6=周日
            
            if current_weekday >= 5:
                return "今天是周末，无课程提醒"
            
            # 统计今日课程
            today_courses = []
            for course in self.app.courses:
                if course['day'] == current_weekday:
                    today_courses.append(course)
            
            if not today_courses:
                return "今天没有课程"
            
            return f"今天有 {len(today_courses)} 门课程"
            
        except Exception as e:
            return "无法获取今日信息"
    
    def load_reminders(self):
        """加载提醒列表"""
        self.reminders_layout.clear_widgets()
        
        try:
            from datetime import datetime, timedelta
            
            # 按星期分组显示课程
            weekday_courses = [[] for _ in range(5)]  # 周一到周五
            
            for course in self.app.courses:
                day_index = course['day']
                if 0 <= day_index < 5:  # 只显示工作日课程
                    weekday_courses[day_index].append(course)
            
            # 显示每天的课程提醒
            weekdays = ['周一', '周二', '周三', '周四', '周五']
            
            for day_index, courses in enumerate(weekday_courses):
                if courses:  # 如果这天有课程
                    self.add_day_section(weekdays[day_index], courses, day_index)
            
            if not any(weekday_courses):
                # 如果没有任何课程
                no_courses_label = Label(
                    text="暂无课程提醒\n\n请先添加课程或导入课表",
                    font_size=16,
                    color=Theme.GRAY,
                    font_name=FONT_NAME,
                    text_size=(None, None),
                    halign='center',
                    valign='middle'
                )
                self.reminders_layout.add_widget(no_courses_label)
                
        except Exception as e:
            error_label = Label(
                text=f"加载提醒列表失败: {e}",
                font_size=14,
                color=Theme.DANGER,
                font_name=FONT_NAME
            )
            self.reminders_layout.add_widget(error_label)
    
    def add_day_section(self, day_name, courses, day_index):
        """添加某天的课程提醒部分"""
        # 当前时间判断
        from datetime import datetime
        current_time = datetime.now()
        current_weekday = current_time.weekday()
        is_today = (day_index == current_weekday)
        
        # 天数标题
        day_color = Theme.PRIMARY if is_today else Theme.GRAY
        day_title = f"{day_name} ({len(courses)}门课程){'  <- 今天' if is_today else ''}"
        
        day_label = Label(
            text=day_title,
            font_size=16,
            bold=True,
            color=day_color,
            font_name=FONT_NAME,
            size_hint_y=None,
            height=35,
            text_size=(None, None),
            halign='left',
            valign='middle'
        )
        self.reminders_layout.add_widget(day_label)
        
        # 课程列表
        for course in sorted(courses, key=lambda x: self.get_course_time_sort_key(x['time'])):
            self.add_course_reminder_card(course, is_today)
        
        # 添加间距
        spacer = Label(text="", size_hint_y=None, height=10)
        self.reminders_layout.add_widget(spacer)
    
    def get_course_time_sort_key(self, time_str):
        """获取课程时间排序键"""
        try:
            # 从时间字符串中提取节次数字
            import re
            match = re.search(r'第(\d+)节', time_str)
            if match:
                return int(match.group(1))
            return 999  # 如果无法解析，排到最后
        except:
            return 999
    
    def add_course_reminder_card(self, course, is_today):
        """添加课程提醒卡片"""
        # 卡片容器
        card_layout = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=80,
            spacing=10,
            padding=[10, 5]
        )
        
        # 设置卡片背景
        card_bg_color = Theme.CARD_HOVER if is_today else Theme.CARD
        with card_layout.canvas.before:
            from kivy.graphics import Color, RoundedRectangle
            Color(*card_bg_color)
            RoundedRectangle(size=card_layout.size, pos=card_layout.pos, radius=[8])
        
        # 时间信息
        time_layout = BoxLayout(
            orientation='vertical',
            size_hint_x=0.25,
            spacing=2
        )
        
        time_label = Label(
            text=course['time'],
            font_size=12,
            bold=True,
            color=Theme.PRIMARY,
            font_name=FONT_NAME,
            text_size=(None, None),
            halign='center',
            valign='middle'
        )
        time_layout.add_widget(time_label)
        
        # 获取具体时间
        time_range = self.get_time_range(course['time'])
        time_range_label = Label(
            text=time_range,
            font_size=10,
            color=Theme.GRAY,
            font_name=FONT_NAME,
            text_size=(None, None),
            halign='center',
            valign='middle'
        )
        time_layout.add_widget(time_range_label)
        
        card_layout.add_widget(time_layout)
        
        # 课程信息
        course_layout = BoxLayout(
            orientation='vertical',
            size_hint_x=0.75,
            spacing=3
        )
        
        # 课程名称
        name_label = Label(
            text=f"课程: {course['name']}",
            font_size=14,
            bold=True,
            color=Theme.DARK,
            font_name=FONT_NAME,
            text_size=(None, None),
            halign='left',
            valign='middle'
        )
        course_layout.add_widget(name_label)
        
        # 详细信息
        details = f"教师: {course['teacher']} | 地点: {course['place']}"
        if course.get('week'):
            details += f" | 周次: {course['week']}周"
        
        details_label = Label(
            text=details,
            font_size=11,
            color=Theme.GRAY,
            font_name=FONT_NAME,
            text_size=(None, None),
            halign='left',
            valign='middle'
        )
        course_layout.add_widget(details_label)
        
        # 提醒信息
        reminder_text = f"提醒: 提前{self.app.reminder_advance_minutes}分钟"
        if not self.app.reminder_enabled:
            reminder_text = "提醒已关闭"
        
        reminder_label = Label(
            text=reminder_text,
            font_size=10,
            color=Theme.SUCCESS if self.app.reminder_enabled else Theme.DANGER,
            font_name=FONT_NAME,
            text_size=(None, None),
            halign='left',
            valign='middle'
        )
        course_layout.add_widget(reminder_label)
        
        card_layout.add_widget(course_layout)
        self.reminders_layout.add_widget(card_layout)
    
    def get_time_range(self, time_str):
        """获取时间段"""
        try:
            # 从节次获取具体时间
            time_map = self.app.section_time_map
            
            # 清理时间字符串
            clean_time = str(time_str).strip()
            
            # 尝试直接匹配
            if clean_time in time_map:
                hour, minute = time_map[clean_time]
                start_time = f"{hour:02d}:{minute:02d}"
                end_minute = minute + 45
                end_hour = hour
                if end_minute >= 60:
                    end_minute -= 60
                    end_hour += 1
                end_time = f"{end_hour:02d}:{end_minute:02d}"
                return f"{start_time}-{end_time}"
            
            # 处理范围格式如"1-2节"、"第1-2节"等
            import re
            
            # 匹配单节课：第1节、1节等
            single_match = re.search(r'第?(\d+)节?', clean_time)
            if single_match:
                section_num = int(single_match.group(1))
                section_key = f"第{section_num}节"
                if section_key in time_map:
                    hour, minute = time_map[section_key]
                    start_time = f"{hour:02d}:{minute:02d}"
                    end_minute = minute + 45
                    end_hour = hour
                    if end_minute >= 60:
                        end_minute -= 60
                        end_hour += 1
                    end_time = f"{end_hour:02d}:{end_minute:02d}"
                    return f"{start_time}-{end_time}"
            
            # 匹配连续节课：第1-2节、1-2节等
            range_match = re.search(r'第?(\d+)-(\d+)节?', clean_time)
            if range_match:
                start_section = int(range_match.group(1))
                end_section = int(range_match.group(2))
                start_key = f"第{start_section}节"
                end_key = f"第{end_section}节"
                
                if start_key in time_map and end_key in time_map:
                    start_hour, start_minute = time_map[start_key]
                    end_hour, end_minute = time_map[end_key]
                    
                    # 结束时间加45分钟
                    end_minute += 45
                    if end_minute >= 60:
                        end_minute -= 60
                        end_hour += 1
                    
                    start_time = f"{start_hour:02d}:{start_minute:02d}"
                    end_time = f"{end_hour:02d}:{end_minute:02d}"
                    return f"{start_time}-{end_time}"
            
            # 使用预定义时间映射表
            time_mapping = {
                "第1节": "08:00-08:45", "第2节": "08:55-09:40", "第3节": "10:00-10:45", 
                "第4节": "10:55-11:40", "第5节": "13:30-14:15", "第6节": "14:25-15:10",
                "第7节": "15:20-16:05", "第8节": "16:15-17:00", "第9节": "17:10-17:55",
                "第10节": "19:00-19:45", "第11节": "19:55-20:40", "第12节": "20:50-21:35",
                "第13节": "21:45-22:30",
                "1-2节": "08:00-09:40", "3-4节": "10:00-11:40", "5-6节": "13:30-15:10",
                "7-8节": "15:20-17:00", "9-10节": "17:10-19:45", "11-12节": "19:55-21:35"
            }
            
            # 检查预定义映射
            for pattern, time_range in time_mapping.items():
                if pattern in clean_time or clean_time in pattern:
                    return time_range
            
            # 如果还是找不到，返回默认时间
            return "08:00-08:45"
            
        except Exception as e:
            print(f"解析时间失败: {e}, 时间字符串: {time_str}")
            return "08:00-08:45"

# 课程编辑对话框
class CourseEditDialog(Popup):
    def __init__(self, app, course_data=None, is_new=True, row=0, col=0, **kwargs):
        super().__init__(**kwargs)
        self.app = app
        self.course_data = course_data
        self.is_new = is_new
        self.row = row
        self.col = col
        self.result = None
        
        self.title = "添加课程" if is_new else "编辑课程"
        self.size_hint = (0.9, 0.8)
        self.auto_dismiss = False
        
        self.setup_ui()
        
    def setup_ui(self):
        """设置对话框界面"""
        main_layout = BoxLayout(orientation='vertical', spacing=10, padding=15)
        
        # 标题
        title_label = Label(
            text=self.title,
            font_size=18,
            bold=True,
            color=Theme.DARK,
            font_name=FONT_NAME,
            size_hint_y=None,
            height=40
        )
        main_layout.add_widget(title_label)
        
        # 表单区域
        form_scroll = ScrollView()
        form_layout = BoxLayout(orientation='vertical', spacing=8, size_hint_y=None)
        form_layout.bind(minimum_height=form_layout.setter('height'))
        
        # 课程名称
        self.name_input = self.create_field(form_layout, "课程名称:")
        
        # 任课教师
        self.teacher_input = self.create_field(form_layout, "任课教师:")
        
        # 上课地点
        self.place_input = self.create_field(form_layout, "上课地点:")
        
        # 星期选择
        self.day_spinner = self.create_spinner(form_layout, "星期:", 
                                              ["0", "1", "2", "3", "4"], 
                                              str(self.col))
        
        # 节次选择
        time_values = [f"第{i}节" for i in range(1, 14)]
        time_values.extend(["1-2节", "3-4节", "5-6节", "7-8节", "9-10节", "11-12节"])
        self.time_spinner = self.create_spinner(form_layout, "上课时间:", 
                                               time_values, 
                                               f"第{self.row + 1}节")
        
        # 上课周次
        self.week_input = self.create_field(form_layout, "上课周次:")
        
        # 学期
        self.term_input = self.create_field(form_layout, "学期:")
        
        form_scroll.add_widget(form_layout)
        main_layout.add_widget(form_scroll)
        
        # 按钮区域
        button_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=50, spacing=10)
        
        # 保存按钮
        save_btn = Button(
            text="保存",
            background_color=Theme.SUCCESS,
            color=Theme.WHITE,
            font_name=FONT_NAME,
            bold=True
        )
        save_btn.bind(on_press=self.save_course)
        button_layout.add_widget(save_btn)
        
        # 删除按钮（编辑时显示）
        if not self.is_new:
            delete_btn = Button(
                text="删除",
                background_color=Theme.DANGER,
                color=Theme.WHITE,
                font_name=FONT_NAME,
                bold=True
            )
            delete_btn.bind(on_press=self.delete_course)
            button_layout.add_widget(delete_btn)
        
        # 取消按钮
        cancel_btn = Button(
            text="取消",
            background_color=Theme.SECONDARY,
            color=Theme.WHITE,
            font_name=FONT_NAME
        )
        cancel_btn.bind(on_press=self.dismiss)
        button_layout.add_widget(cancel_btn)
        
        main_layout.add_widget(button_layout)
        
        # 如果是编辑模式，加载数据
        if not self.is_new and self.course_data:
            self.load_course_data()
        
        self.content = main_layout
        
    def create_field(self, parent, label_text):
        """创建输入字段"""
        field_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=40, spacing=10)
        
        label = Label(
            text=label_text,
            font_name=FONT_NAME,
            color=Theme.DARK,
            size_hint_x=0.3,
            text_size=(None, None),
            halign='left'
        )
        
        text_input = TextInput(
            multiline=False,
            font_name=FONT_NAME,
            size_hint_x=0.7,
            background_color=Theme.WHITE,
            foreground_color=Theme.DARK
        )
        
        field_layout.add_widget(label)
        field_layout.add_widget(text_input)
        parent.add_widget(field_layout)
        
        return text_input
        
    def create_spinner(self, parent, label_text, values, default_value):
        """创建选择框"""
        field_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=40, spacing=10)
        
        label = Label(
            text=label_text,
            font_name=FONT_NAME,
            color=Theme.DARK,
            size_hint_x=0.3,
            text_size=(None, None),
            halign='left'
        )
        
        spinner = Spinner(
            text=default_value,
            values=values,
            size_hint_x=0.7,
            font_name=FONT_NAME
        )
        
        field_layout.add_widget(label)
        field_layout.add_widget(spinner)
        parent.add_widget(field_layout)
        
        return spinner
    
    def load_course_data(self):
        """加载课程数据"""
        if self.course_data:
            self.name_input.text = clean_text(self.course_data.get('name', ''))
            self.teacher_input.text = clean_text(self.course_data.get('teacher', ''))
            self.place_input.text = clean_text(self.course_data.get('place', ''))
            self.week_input.text = clean_text(str(self.course_data.get('week', '1-16')))
            self.term_input.text = clean_text(self.course_data.get('term', '2024-2025-1'))
    
    def save_course(self, instance):
        """保存课程"""
        try:
            # 收集数据
            course_data = {
                'name': self.name_input.text.strip(),
                'teacher': self.teacher_input.text.strip(),
                'place': self.place_input.text.strip(),
                'day': self.day_spinner.text,
                'time': self.time_spinner.text,
                'week': self.week_input.text.strip() or '1-16',
                'term': self.term_input.text.strip() or '2024-2025-1'
            }
            
            # 验证数据
            if not course_data['name']:
                self.app.update_status("请输入课程名称", is_error=True)
                return
            
            # 保存到数据库
            if self.app.save_course_to_db(course_data, self.is_new):
                self.app.update_status("课程保存成功" if self.is_new else "课程更新成功")
                self.app.refresh_timetable()
                self.dismiss()
            else:
                self.app.update_status("保存失败", is_error=True)
                
        except Exception as e:
            log_message("ERROR", f"保存课程失败: {e}")
            self.app.update_status("保存失败", is_error=True)
    
    def delete_course(self, instance):
        """删除课程"""
        try:
            if self.app.delete_course_from_db(self.course_data):
                self.app.update_status("课程删除成功")
                self.app.refresh_timetable()
                self.dismiss()
            else:
                self.app.update_status("删除失败", is_error=True)
        except Exception as e:
            log_message("ERROR", f"删除课程失败: {e}")
            self.app.update_status("删除失败", is_error=True)

# 数据库管理器
class DatabaseManager:
    def __init__(self):
        self.db_available = DB_AVAILABLE
        
    def get_all_courses(self):
        """获取所有课程数据"""
        if not self.db_available:
            return self.get_demo_courses()
        
        try:
            courses = []
            table_names = get_all_table_names()
            
            for table_name in table_names:
                if table_name.lower() in ['course_schedule', 'courses']:
                    continue
                    
                try:
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    cursor.execute(f"SELECT * FROM `{table_name}`")
                    records = cursor.fetchall()
                    
                    # 获取列名
                    columns = [desc[0] for desc in cursor.description]
                    
                    for record in records:
                        # 将元组转换为字典
                        record_dict = dict(zip(columns, record))
                        course = {
                            'id': record_dict.get('id', 0),
                            'name': clean_text(table_name),
                            'teacher': clean_text(record_dict.get('teacher', '')),
                            'place': clean_text(record_dict.get('place', '')),
                            'day': self.parse_day(record_dict.get('day', '0')),
                            'time': clean_text(record_dict.get('time', '第1节')),
                            'week': clean_text(record_dict.get('week', '1-16')),
                            'term': clean_text(record_dict.get('term', '2024-2025-1')),
                            'table_name': table_name
                        }
                        courses.append(course)
                        
                    cursor.close()
                    conn.close()
                    
                except Exception as e:
                    print(f"查询表 {table_name} 失败: {e}")
                    
            return courses
            
        except Exception as e:
            print(f"获取课程数据失败: {e}")
            return self.get_demo_courses()
    
    def get_demo_courses(self):
        """获取演示课程数据"""
        return [
            {
                "id": 1, "name": "高等数学", "teacher": "张教授", "place": "A101",
                "day": 0, "time": "第1节", "week": "1-16", "term": "2024-2025-1", "table_name": "高等数学"
            },
            {
                "id": 2, "name": "大学英语", "teacher": "李老师", "place": "B203",
                "day": 1, "time": "第3节", "week": "1-16", "term": "2024-2025-1", "table_name": "大学英语"
            },
            {
                "id": 3, "name": "计算机基础", "teacher": "王老师", "place": "机房201",
                "day": 2, "time": "第5节", "week": "1-16", "term": "2024-2025-1", "table_name": "计算机基础"
            },
            {
                "id": 4, "name": "体育课", "teacher": "刘老师", "place": "体育馆",
                "day": 3, "time": "第7节", "week": "1-16", "term": "2024-2025-1", "table_name": "体育课"
            },
            {
                "id": 5, "name": "思想政治", "teacher": "陈老师", "place": "C305",
                "day": 4, "time": "第10节", "week": "1-16", "term": "2024-2025-1", "table_name": "思想政治"
            }
        ]
    
    def parse_day(self, day_str):
        """解析星期"""
        day_map = {'0': 0, '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6}
        return day_map.get(str(day_str), 0)

# 主应用类
class SmartTimetableApp(App):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.title = "智能课表系统 - 安卓版 v4.0"
        self.db_manager = DatabaseManager()
        self.courses = []
        self.course_grid = [[None for _ in range(5)] for _ in range(13)]  # 13节课×5天
        self.current_week = 1
        self.course_buttons = []
        
        # 智能提醒系统初始化
        self.reminder_enabled = True
        self.reminder_advance_minutes = 10  # 提前10分钟提醒
        self.reminded_courses = set()  # 记录已提醒的课程，避免重复提醒
        
        # 节次时间映射
        self.section_time_map = {
            "第1节": (8, 0), "第2节": (8, 55), "第3节": (10, 0), "第4节": (10, 55),
            "第5节": (13, 30), "第6节": (14, 25), "第7节": (15, 20), "第8节": (16, 15),
            "第9节": (17, 10), "第10节": (19, 0), "第11节": (19, 55), "第12节": (20, 50),
            "第13节": (21, 45)
        }
        
    def build(self):
        """构建应用界面"""
        Window.clearcolor = Theme.LIGHT
        
        # 主布局
        main_layout = BoxLayout(orientation='vertical')
        
        # 顶部控制面板
        control_panel = self.create_control_panel()
        main_layout.add_widget(control_panel)
        
        # 主内容区域
        content_scroll = ScrollView()
        content_layout = BoxLayout(orientation='vertical', size_hint_y=None)
        content_layout.bind(minimum_height=content_layout.setter('height'))
        
        # 课表网格
        timetable_widget = self.create_timetable_grid()
        content_layout.add_widget(timetable_widget)
        
        content_scroll.add_widget(content_layout)
        main_layout.add_widget(content_scroll)
        
        # 底部状态栏
        self.status_bar = Label(
            text="智能课表系统 - 安卓版 v4.0",
            size_hint_y=None,
            height=35,
            font_name=FONT_NAME,
            color=Theme.DARK
        )
        with self.status_bar.canvas.before:
            Color(*Theme.CARD)
            Rectangle(size=self.status_bar.size, pos=self.status_bar.pos)
        self.status_bar.bind(size=self.update_status_bg, pos=self.update_status_bg)
        main_layout.add_widget(self.status_bar)
        
        # 加载数据
        Clock.schedule_once(lambda dt: self.load_courses(), 0.1)
        
        # 启动智能提醒系统（每分钟检查一次）
        if self.reminder_enabled:
            Clock.schedule_interval(self.check_course_reminders, 60)
        
        return main_layout
    
    def update_status_bg(self, instance, value):
        """更新状态栏背景"""
        instance.canvas.before.clear()
        with instance.canvas.before:
            Color(*Theme.CARD)
            Rectangle(size=instance.size, pos=instance.pos)
    
    def create_control_panel(self):
        """创建顶部控制面板"""
        panel = BoxLayout(orientation='vertical', size_hint_y=None, height=120, spacing=5)
        
        # 设置背景
        with panel.canvas.before:
            Color(*Theme.PRIMARY)
            Rectangle(size=panel.size, pos=panel.pos)
        panel.bind(size=self.update_panel_bg, pos=self.update_panel_bg)
        
        # 标题行
        title_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=40, padding=[10, 5])
        
        title_label = Label(
            text="智能课表系统 v4.0",
            font_size=18,
            bold=True,
            color=Theme.WHITE,
            font_name=FONT_NAME,
            size_hint_x=0.7
        )
        title_layout.add_widget(title_label)
        
        # 周次控制
        week_layout = BoxLayout(orientation='horizontal', size_hint_x=0.3, spacing=5)
        
        prev_btn = Button(
            text="◀",
            size_hint_x=0.2,
            background_color=Theme.SECONDARY,
            color=Theme.WHITE,
            font_name=FONT_NAME,
            bold=True
        )
        prev_btn.bind(on_press=self.prev_week)
        week_layout.add_widget(prev_btn)
        
        self.week_label = Label(
            text=f"第{self.current_week}周",
            font_size=12,
            bold=True,
            color=Theme.WHITE,
            font_name=FONT_NAME,
            size_hint_x=0.6
        )
        week_layout.add_widget(self.week_label)
        
        next_btn = Button(
            text="▶",
            size_hint_x=0.2,
            background_color=Theme.SECONDARY,
            color=Theme.WHITE,
            font_name=FONT_NAME,
            bold=True
        )
        next_btn.bind(on_press=self.next_week)
        week_layout.add_widget(next_btn)
        
        title_layout.add_widget(week_layout)
        panel.add_widget(title_layout)
        
        # 功能按钮行
        button_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=40, spacing=5, padding=[10, 5])
        
        # 刷新按钮
        refresh_btn = Button(
            text="刷新",
            background_color=Theme.INFO,
            color=Theme.WHITE,
            font_name=FONT_NAME,
            size_hint_x=0.13
        )
        refresh_btn.bind(on_press=self.refresh_data)
        button_layout.add_widget(refresh_btn)
        
        # 添加课程按钮
        add_btn = Button(
            text="添加课程",
            background_color=Theme.SUCCESS,
            color=Theme.WHITE,
            font_name=FONT_NAME,
            size_hint_x=0.17
        )
        add_btn.bind(on_press=self.add_course)
        button_layout.add_widget(add_btn)
        
        # 删除所有按钮
        delete_all_btn = Button(
            text="删除所有",
            background_color=Theme.DANGER,
            color=Theme.WHITE,
            font_name=FONT_NAME,
            size_hint_x=0.17
        )
        delete_all_btn.bind(on_press=self.delete_all_courses)
        button_layout.add_widget(delete_all_btn)
        
        # 导入课表按钮
        import_btn = Button(
            text="导入课表",
            background_color=Theme.WARNING,
            color=Theme.WHITE,
            font_name=FONT_NAME,
            size_hint_x=0.17
        )
        import_btn.bind(on_press=self.import_timetable)
        button_layout.add_widget(import_btn)
        
        # 查看提醒按钮
        reminders_btn = Button(
            text="查看提醒",
            background_color=Theme.TEAL,
            color=Theme.WHITE,
            font_name=FONT_NAME,
            size_hint_x=0.17
        )
        reminders_btn.bind(on_press=self.show_reminders_list)
        button_layout.add_widget(reminders_btn)
        
        # 设置按钮
        settings_btn = Button(
            text="设置",
            background_color=Theme.PURPLE,
            color=Theme.WHITE,
            font_name=FONT_NAME,
            size_hint_x=0.13
        )
        settings_btn.bind(on_press=self.open_settings)
        button_layout.add_widget(settings_btn)
        
        panel.add_widget(button_layout)
        
        return panel
    
    def update_panel_bg(self, instance, value):
        """更新面板背景"""
        instance.canvas.before.clear()
        with instance.canvas.before:
            Color(*Theme.PRIMARY)
            Rectangle(size=instance.size, pos=instance.pos)
    
    def create_timetable_grid(self):
        """创建课表网格"""
        container = BoxLayout(orientation='vertical', size_hint_y=None, padding=10)
        container.bind(minimum_height=container.setter('height'))
        
        # 表头 - 增加高度和间距，让表头更突出
        header_layout = GridLayout(cols=6, size_hint_y=None, height=50, spacing=2)
        
        # 左上角 - 加强显示效果
        corner_label = Label(
            text="节次/星期",
            font_size=14,
            bold=True,
            color=Theme.WHITE,
            font_name=FONT_NAME,
            text_size=(None, None),
            halign='center',
            valign='middle'
        )
        corner_label._bg_color = Theme.DARK  # 设置背景颜色属性
        with corner_label.canvas.before:
            Color(*Theme.DARK)  # 使用深色背景更醒目
            Rectangle(size=corner_label.size, pos=corner_label.pos)
        corner_label.bind(size=self.update_cell_bg, pos=self.update_cell_bg)
        header_layout.add_widget(corner_label)
        
        # 星期标题 - 使用渐变色
        for i, day in enumerate(WEEKDAYS):
            # 为每个星期使用不同的渐变色
            gradient_colors = [
                Theme.PRIMARY,      # 周一 - 主蓝色
                Theme.ACCENT,       # 周二 - 青绿色
                Theme.SUCCESS,      # 周三 - 绿色
                Theme.WARNING,      # 周四 - 橙色
                Theme.PURPLE        # 周五 - 紫色
            ]
            
            day_label = Label(
                text=day,
                font_size=14,
                bold=True,
                color=Theme.WHITE,
                font_name=FONT_NAME,
                text_size=(None, None),
                halign='center',
                valign='middle'
            )
            day_label._bg_color = gradient_colors[i]  # 设置背景颜色属性
            with day_label.canvas.before:
                Color(*gradient_colors[i])
                Rectangle(size=day_label.size, pos=day_label.pos)
            day_label.bind(size=self.update_cell_bg, pos=self.update_cell_bg)
            header_layout.add_widget(day_label)
        
        container.add_widget(header_layout)
        
        # 课程表主体 - 增加间距让表格更清晰
        grid_layout = GridLayout(cols=6, size_hint_y=None, spacing=2)
        grid_layout.bind(minimum_height=grid_layout.setter('height'))
        
        self.course_buttons = []
        
        for row in range(13):  # 13节课
            button_row = []
            
            # 节次标签 - 使用时间段分组配色
            time_slot = TIME_SLOTS[row] if row < len(TIME_SLOTS) else ("--:--", "--:--")
            section_text = f"第{row+1}节\n{time_slot[0]}-{time_slot[1]}"
            
            # 根据时间段使用不同颜色 - 使用更深的背景色确保文字清晰可见
            if row < 4:  # 上午 1-4节
                section_color = Theme.PRIMARY  # 使用主蓝色
            elif row < 9:  # 下午 5-9节
                section_color = Theme.SUCCESS  # 使用绿色
            else:  # 晚上 10-13节
                section_color = Theme.SECONDARY  # 使用紫色
            
            section_label = Label(
                text=section_text,
                font_size=11,
                bold=True,
                color=Theme.WHITE,
                font_name=FONT_NAME,
                size_hint_y=None,
                height=60,
                text_size=(None, None),
                halign='center',
                valign='middle'
            )
            section_label._bg_color = section_color  # 设置背景颜色属性
            with section_label.canvas.before:
                Color(*section_color)
                Rectangle(size=section_label.size, pos=section_label.pos)
            section_label.bind(size=self.update_cell_bg, pos=self.update_cell_bg)
            grid_layout.add_widget(section_label)
            
            # 课程按钮 - 简化背景设置，避免白色条纹
            for col in range(5):  # 5天
                btn = Button(
                    text="",
                    font_size=10,
                    font_name=FONT_NAME,
                    background_normal='',  # 移除默认背景
                    background_color=Theme.CARD,
                    color=Theme.GRAY,
                    size_hint_y=None,
                    height=60,
                    text_size=(None, None),
                    halign='center',
                    valign='middle'
                )
                
                # 设置简洁的背景色
                btn._bg_color = Theme.CARD
                with btn.canvas.before:
                    Color(*Theme.CARD)
                    Rectangle(size=btn.size, pos=btn.pos)
                
                btn.bind(on_press=lambda x, r=row, c=col: self.edit_course_cell(r, c))
                btn.bind(size=self.update_button_bg, pos=self.update_button_bg)
                btn.bind(size=self.update_button_text_size)
                grid_layout.add_widget(btn)
                button_row.append(btn)
            
            self.course_buttons.append(button_row)
        
        container.add_widget(grid_layout)
        
        # 延迟刷新背景，确保布局完成后重新绘制
        Clock.schedule_once(self.refresh_backgrounds, 0.1)
        
        return container
    
    def refresh_backgrounds(self, dt):
        """刷新所有背景显示"""
        try:
            # 遍历所有子控件，强制刷新背景
            def refresh_widget(widget):
                if hasattr(widget, '_bg_color') and hasattr(widget, 'canvas'):
                    widget.canvas.before.clear()
                    with widget.canvas.before:
                        Color(*widget._bg_color)
                        Rectangle(size=widget.size, pos=widget.pos)
                
                # 递归处理子控件
                if hasattr(widget, 'children'):
                    for child in widget.children:
                        refresh_widget(child)
            
            refresh_widget(self.root)
        except Exception as e:
            log_message("ERROR", f"刷新背景失败: {e}")
    
    def update_cell_bg(self, instance, value):
        """更新单元格背景 - 重新绘制背景颜色"""
        if hasattr(instance, 'canvas') and hasattr(instance.canvas, 'before'):
            # 清除旧的背景
            instance.canvas.before.clear()
            
            # 重新绘制背景
            with instance.canvas.before:
                # 根据控件获取正确的背景颜色
                if hasattr(instance, '_bg_color'):
                    Color(*instance._bg_color)
                else:
                    # 默认背景色
                    Color(*Theme.CARD)
                Rectangle(size=instance.size, pos=instance.pos)
    
    def update_button_text_size(self, instance, value):
        """更新按钮文本大小"""
        instance.text_size = (instance.width - 10, instance.height - 10)
    
    def update_button_bg(self, instance, value):
        """更新按钮背景"""
        if hasattr(instance, 'canvas') and hasattr(instance.canvas, 'before'):
            # 清除旧的背景
            instance.canvas.before.clear()
            
            # 重新绘制背景
            with instance.canvas.before:
                if hasattr(instance, '_bg_color'):
                    Color(*instance._bg_color)
                else:
                    Color(*Theme.CARD)
                Rectangle(size=instance.size, pos=instance.pos)
    
    def edit_course_cell(self, row, col):
        """编辑课程单元格"""
        course_data = self.course_grid[row][col]
        is_new = course_data is None
        
        dialog = CourseEditDialog(
            self, 
            course_data=course_data, 
            is_new=is_new, 
            row=row, 
            col=col
        )
        dialog.open()
    
    def add_course(self, instance):
        """添加课程"""
        dialog = CourseEditDialog(self, is_new=True)
        dialog.open()
    
    def delete_all_courses(self, instance):
        """删除所有课程"""
        # 简化版本，直接确认
        try:
            if DB_AVAILABLE:
                # 这里应该有确认对话框，简化处理
                self.update_status("删除所有课程功能需要确认")
            else:
                self.update_status("演示模式下不支持删除")
        except Exception as e:
            log_message("ERROR", f"删除所有课程失败: {e}")
            self.update_status("删除失败", is_error=True)
    
    def import_timetable(self, instance):
        """导入课表"""
        if not EXCEL_AVAILABLE:
            self.update_status("Excel处理库不可用，请安装pandas和openpyxl", is_error=True)
            return
        
        if not DB_AVAILABLE:
            self.update_status("数据库功能不可用，无法导入课表", is_error=True)
            return
        
        # 显示文件选择对话框
        dialog = FileImportDialog(self)
        dialog.bind(on_dismiss=self.on_import_dialog_dismiss)
        dialog.open()
    
    def on_import_dialog_dismiss(self, dialog):
        """处理导入对话框关闭事件"""
        if dialog.result and dialog.result != 'cancel':
            file_path = dialog.result
            self.process_import_file(file_path)
    
    def process_import_file(self, file_path):
        """处理导入文件"""
        try:
            self.update_status("正在处理文件...")
            
            file_ext = file_path.lower().split('.')[-1]
            imported_count = 0
            
            if file_ext == 'csv':
                imported_count = self.import_csv_file(file_path)
            elif file_ext in ['xlsx', 'xls']:
                # 先检查是否为传统课表格式
                if self.is_traditional_timetable_format(file_path):
                    imported_count = self.import_traditional_timetable(file_path)
                else:
                    imported_count = self.import_excel_file(file_path)
            else:
                self.update_status("不支持的文件格式", is_error=True)
                return
            
            # 重新加载课程显示
            self.load_courses()
            self.update_status(f"成功导入 {imported_count} 门课程")
            
        except Exception as e:
            error_msg = f"导入文件失败: {str(e)}"
            log_message("ERROR", error_msg)
            self.update_status(error_msg, is_error=True)
    
    def import_csv_file(self, file_path):
        """导入CSV文件"""
        imported_count = 0
        
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        # 跳过标题行
        for line in lines[1:]:
            if line.strip():
                try:
                    parts = line.strip().split(',')
                    if len(parts) >= 6:
                        course_name = parts[0].strip()
                        teacher = parts[1].strip()
                        place = parts[2].strip()
                        day = parts[3].strip()
                        time = parts[4].strip()
                        week = int(parts[5].strip())
                        term = parts[6].strip() if len(parts) > 6 else '2024-2025学年第一学期'
                        
                        if self.import_single_course(course_name, teacher, place, day, time, week, term):
                            imported_count += 1
                except Exception as e:
                    log_message("ERROR", f"导入CSV行失败: {str(e)}")
                    continue
        
        return imported_count
    
    def import_excel_file(self, file_path):
        """导入标准Excel文件"""
        try:
            df = pd.read_excel(file_path)
            imported_count = 0
            
            for index, row in df.iterrows():
                if len(row) >= 6 and str(row[0]).strip():  # 确保有足够的列和课程名称不为空
                    course_name = str(row[0]).strip()
                    teacher = str(row[1] or '').strip()
                    place = str(row[2] or '').strip()
                    day = str(row[3] or '0').strip()
                    time = str(row[4] or '第1节').strip()
                    week = int(row[5] or 1)
                    term = str(row[6] or '2024-2025学年第一学期').strip() if len(row) > 6 else '2024-2025学年第一学期'
                    
                    if self.import_single_course(course_name, teacher, place, day, time, week, term):
                        imported_count += 1
            
            return imported_count
            
        except Exception as e:
            log_message("ERROR", f"导入Excel文件失败: {str(e)}")
            raise e
    
    def is_traditional_timetable_format(self, file_path):
        """检测是否为传统课表格式"""
        try:
            from openpyxl import load_workbook
            
            workbook = load_workbook(file_path)
            sheet = workbook.active
            
            # 检查是否包含"星期"字样和"节"字样
            has_weekday = False
            has_period = False
            
            for row in sheet.iter_rows(values_only=True):
                for cell in row:
                    if cell and isinstance(cell, str):
                        if '星期' in cell:
                            has_weekday = True
                        if '节' in cell:
                            has_period = True
                            
            return has_weekday and has_period
            
        except Exception:
            return False
    
    def import_traditional_timetable(self, file_path):
        """导入传统课表格式"""
        try:
            from openpyxl import load_workbook
            import re
            
            self.update_status("检测到传统课表格式，正在解析...")
            
            workbook = load_workbook(file_path)
            sheet = workbook.active
            
            weekdays = ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日']
            weekday_map = {day: idx for idx, day in enumerate(weekdays)}
            
            imported_count = 0
            
            # 遍历每一行
            for row in sheet.iter_rows(values_only=True):
                time_slot = row[0] if row[0] else ""
                
                # 只处理包含"节"的时间行
                if "节" not in str(time_slot):
                    continue
                
                # 遍历每个工作日列
                for col_idx, weekday_str in enumerate(weekdays, 1):
                    if col_idx >= len(row):
                        continue
                    
                    cell_value = row[col_idx]
                    if not cell_value:
                        continue
                    
                    # 分割多个课程
                    raw_courses = [c.strip() for c in str(cell_value).split(',') if c.strip()]
                    
                    for course_str in raw_courses:
                        # 分割课程详细信息
                        parts = [p.strip() for p in re.split('<br>|\n', course_str) if p.strip()]
                        
                        if len(parts) < 3:
                            continue
                        
                        course_name = parts[0]
                        teacher = parts[1]
                        time_location = parts[2]
                        
                        # 解析时间和地点
                        location = ""
                        time_info = ""
                        
                        if ', ' in time_location:
                            time_info, location = time_location.split(', ', 1)
                        elif ',' in time_location:
                            time_info, location = time_location.split(',', 1)
                        elif '， ' in time_location:
                            time_info, location = time_location.split('， ', 1)
                        elif '，' in time_location:
                            time_info, location = time_location.split('，', 1)
                        else:
                            time_info = time_location
                        
                        # 解析周次和节次
                        week_match = re.search(r'(\d+)周', time_info)
                        period_match = re.search(r'(\d+-\d+)节', time_info)
                        
                        week_num = week_match.group(1) if week_match else "1"
                        period = period_match.group(1) if period_match else time_slot
                        
                        weekday_num = weekday_map.get(weekday_str, 0)
                        
                        if self.import_single_course(
                            course_name, teacher, location.strip(), 
                            str(weekday_num), period, int(week_num), 
                            '2024-2025学年第一学期'
                        ):
                            imported_count += 1
            
            return imported_count
            
        except Exception as e:
            log_message("ERROR", f"导入传统课表失败: {str(e)}")
            raise e
    
    def import_single_course(self, course_name, teacher, place, day, time, week, term):
        """导入单个课程"""
        try:
            if not course_name:
                return False
            
            # 清理课程名称
            cleaned_name = course_name.replace('+', '和').replace(' ', '_')
            
            # 使用数据库插入函数
            if insert_into_table(cleaned_name, place, time, week, teacher, day, term):
                return True
            else:
                log_message("ERROR", f"导入课程 {course_name} 失败")
                return False
                
        except Exception as e:
            log_message("ERROR", f"导入课程 {course_name} 失败: {str(e)}")
            return False
    
    def show_reminders_list(self, instance):
        """显示提醒列表"""
        dialog = RemindersListDialog(self)
        dialog.open()
    
    def open_settings(self, instance):
        """打开设置"""
        self.show_settings_dialog()
    
    def show_settings_dialog(self):
        """显示设置对话框"""
        settings_popup = Popup(
            title="系统设置",
            size_hint=(0.9, 0.8),
            auto_dismiss=True
        )
        
        main_layout = BoxLayout(orientation='vertical', spacing=10, padding=15)
        
        # 系统信息区域
        info_layout = BoxLayout(orientation='vertical', size_hint_y=0.4, spacing=5)
        
        info_title = Label(
            text="系统信息",
            font_size=16,
            bold=True,
            color=Theme.DARK,
            font_name=FONT_NAME,
            size_hint_y=None,
            height=30
        )
        info_layout.add_widget(info_title)
        
        info_text = f"""数据库状态: {'已连接' if self.db_manager.db_available else '未连接'}
Excel库状态: {'可用' if EXCEL_AVAILABLE else '不可用'}
课程总数: {len(self.courses)}
当前周次: 第{self.current_week}周
提醒状态: {'启用' if self.reminder_enabled else '关闭'}
提前时间: {self.reminder_advance_minutes}分钟"""
        
        info_label = Label(
            text=info_text,
            font_size=12,
            color=Theme.GRAY,
            font_name=FONT_NAME,
            text_size=(None, None),
            halign='left',
            valign='top'
        )
        info_layout.add_widget(info_label)
        
        main_layout.add_widget(info_layout)
        
        # 提醒设置区域
        reminder_layout = BoxLayout(orientation='vertical', size_hint_y=0.4, spacing=5)
        
        reminder_title = Label(
            text="提醒设置",
            font_size=16,
            bold=True,
            color=Theme.DARK,
            font_name=FONT_NAME,
            size_hint_y=None,
            height=30
        )
        reminder_layout.add_widget(reminder_title)
        
        # 提醒开关
        switch_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=40, spacing=10)
        
        switch_label = Label(
            text="课程提醒:",
            font_size=14,
            color=Theme.DARK,
            font_name=FONT_NAME,
            size_hint_x=0.6
        )
        switch_layout.add_widget(switch_label)
        
        reminder_switch = Switch(
            active=self.reminder_enabled,
            size_hint_x=0.4
        )
        reminder_switch.bind(active=self.on_reminder_switch_change)
        switch_layout.add_widget(reminder_switch)
        
        reminder_layout.add_widget(switch_layout)
        
        # 提前时间设置
        time_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=40, spacing=10)
        
        time_label = Label(
            text="提前时间(分钟):",
            font_size=14,
            color=Theme.DARK,
            font_name=FONT_NAME,
            size_hint_x=0.6
        )
        time_layout.add_widget(time_label)
        
        time_values = ['5', '10', '15', '20', '30']
        time_spinner = Spinner(
            text=str(self.reminder_advance_minutes),
            values=time_values,
            size_hint_x=0.4,
            font_name=FONT_NAME
        )
        time_spinner.bind(text=self.on_reminder_time_change)
        time_layout.add_widget(time_spinner)
        
        reminder_layout.add_widget(time_layout)
        
        main_layout.add_widget(reminder_layout)
        
        # 按钮区域
        button_layout = BoxLayout(orientation='horizontal', size_hint_y=0.2, spacing=10)
        
        test_btn = Button(
            text="测试提醒",
            background_color=Theme.INFO,
            color=Theme.WHITE,
            font_name=FONT_NAME,
            size_hint_x=0.5
        )
        test_btn.bind(on_press=lambda x: self.test_reminder_function())
        button_layout.add_widget(test_btn)
        
        close_btn = Button(
            text="关闭",
            background_color=Theme.GRAY,
            color=Theme.WHITE,
            font_name=FONT_NAME,
            size_hint_x=0.5
        )
        close_btn.bind(on_press=lambda x: settings_popup.dismiss())
        button_layout.add_widget(close_btn)
        
        main_layout.add_widget(button_layout)
        
        settings_popup.content = main_layout
        settings_popup.open()
    
    def on_reminder_switch_change(self, instance, value):
        """提醒开关变化处理"""
        if value != self.reminder_enabled:
            self.toggle_reminders()
    
    def on_reminder_time_change(self, instance, value):
        """提醒时间变化处理"""
        try:
            minutes = int(value)
            self.set_reminder_advance_time(minutes)
        except ValueError:
            self.update_status("无效的提醒时间设置", is_error=True)
    
    def test_reminder_function(self):
        """测试提醒功能"""
        try:
            title = "测试提醒"
            message = ("这是一个测试提醒！\n"
                      "如果您看到这个通知，说明提醒功能正常工作。\n"
                      "提醒功能已就绪\n\n"
                      f"当前设置：提前{self.reminder_advance_minutes}分钟提醒\n"
                      f"提醒状态：{'已启用' if self.reminder_enabled else '已关闭'}")
            
            # 同时测试系统通知和弹窗提醒
            self.send_system_notification(title, message)
            self.show_reminder_popup(title, message)
            
            self.update_status("测试提醒已发送（系统通知+弹窗）")
            log_message("TEST", "用户测试提醒功能（系统通知+弹窗）")
            
        except Exception as e:
            error_msg = f"测试提醒失败: {str(e)}"
            print(error_msg)  # 控制台输出
            log_message("ERROR", error_msg)
            self.update_status("测试提醒失败", is_error=True)
    
    def show_system_info(self):
        """显示系统信息"""
        info_text = f"""智能课表系统信息

数据库状态: {'已连接' if self.db_manager.db_available else '未连接'}
课程总数: {len(self.courses)}
当前周次: 第{self.current_week}周
字体支持: {'中文字体' if FONT_LOADED else '默认字体'}

使用说明:
- 点击课程格子可编辑课程
- 使用顶部按钮管理课程
- 左右箭头切换周次
- 支持添加、编辑、删除课程

版本: 安卓版 v4.0
基于桌面端框架设计"""
        
        content = BoxLayout(orientation='vertical', spacing=10, padding=15)
        
        info_label = Label(
            text=info_text,
            font_name=FONT_NAME,
            color=Theme.DARK,
            text_size=(300, None),
            halign='left',
            valign='top'
        )
        content.add_widget(info_label)
        
        close_btn = Button(
            text="确定",
            size_hint_y=None,
            height=40,
            background_color=Theme.INFO,
            color=Theme.WHITE,
            font_name=FONT_NAME
        )
        
        popup = Popup(
            title="系统信息",
            content=content,
            size_hint=(0.8, 0.7),
            auto_dismiss=True
        )
        
        close_btn.bind(on_press=popup.dismiss)
        content.add_widget(close_btn)
        popup.open()
    
    def prev_week(self, instance):
        """上一周"""
        if self.current_week > 1:
            self.current_week -= 1
            self.week_label.text = f"第{self.current_week}周"
            self.update_course_display()
    
    def next_week(self, instance):
        """下一周"""
        if self.current_week < 20:
            self.current_week += 1
            self.week_label.text = f"第{self.current_week}周"
            self.update_course_display()
    
    def refresh_data(self, instance):
        """刷新数据"""
        self.update_status("正在刷新数据...")
        self.load_courses()
    
    def load_courses(self):
        """加载课程数据"""
        try:
            self.courses = self.db_manager.get_all_courses()
            self.update_course_display()
            self.update_status(f"加载完成，共 {len(self.courses)} 门课程")
        except Exception as e:
            log_message("ERROR", f"加载课程失败: {e}")
            self.update_status("加载失败", is_error=True)
    
    def update_course_display(self):
        """更新课程显示 - 使用新的美化配色"""
        # 清空网格并重置为美化样式
        for row in range(13):
            for col in range(5):
                self.course_grid[row][col] = None
                btn = self.course_buttons[row][col]
                btn.text = ""
                btn.background_color = Theme.CARD
                btn.color = Theme.GRAY
                btn.bold = False
                
                # 重置为空闲状态的悬停效果
                btn.canvas.before.clear()
                with btn.canvas.before:
                    Color(*Theme.CARD_HOVER)
                    Rectangle(size=btn.size, pos=btn.pos)

        # 填充课程
        for course in self.courses:
            if self.is_course_in_current_week(course):
                self.add_course_to_grid(course)
    
    def is_course_in_current_week(self, course):
        """判断课程是否在当前周"""
        week_str = course.get('week', '1-16')
        try:
            # 处理范围格式如 '1-16'
            if '-' in week_str:
                start, end = map(int, week_str.split('-'))
                return start <= self.current_week <= end
            else:
                # 处理单个数字格式如 '1', '2', '3'
                week_num = int(week_str)
                return self.current_week == week_num
        except:
            # 如果解析失败，默认显示课程
            return True
    
    def add_course_to_grid(self, course):
        """添加课程到网格"""
        try:
            day = course.get('day', 0)
            time_str = course.get('time', '1')
            
            # 解析时间 - 支持多种格式
            if '第' in time_str and '节' in time_str:
                # 处理 "第1节"、"第1-2节" 格式
                if '-' in time_str:
                    parts = time_str.replace('第', '').replace('节', '').split('-')
                    start_section = int(parts[0]) - 1
                    end_section = int(parts[1]) - 1
                    
                    for section in range(start_section, end_section + 1):
                        if 0 <= section < 13 and 0 <= day < 5:
                            self.course_grid[section][day] = course
                            self.update_course_button(section, day, course)
                else:
                    section = int(time_str.replace('第', '').replace('节', '')) - 1
                    if 0 <= section < 13 and 0 <= day < 5:
                        self.course_grid[section][day] = course
                        self.update_course_button(section, day, course)
            else:
                # 处理 "1-8"、"2-5"、"9-12" 等数字格式
                if '-' in time_str:
                    parts = time_str.split('-')
                    start_section = int(parts[0]) - 1
                    end_section = int(parts[1]) - 1
                    
                    # 为连续课程的每个时间段添加课程
                    for section in range(start_section, end_section + 1):
                        if 0 <= section < 13 and 0 <= day < 5:
                            self.course_grid[section][day] = course
                            self.update_course_button(section, day, course)
                else:
                    # 处理单节课如 "1"、"2" 格式
                    section = int(time_str) - 1
                    if 0 <= section < 13 and 0 <= day < 5:
                        self.course_grid[section][day] = course
                        self.update_course_button(section, day, course)
                        
        except Exception as e:
            log_message("ERROR", f"添加课程到网格失败: {e} - 课程: {course}")
    
    def update_course_button(self, row, col, course):
        """更新课程按钮显示 - 使用多彩配色方案"""
        try:
            btn = self.course_buttons[row][col]
            
            # 根据课程名称计算颜色索引，确保同名课程颜色一致
            color_index = hash(course['name']) % len(Theme.COURSE_COLORS)
            course_color = Theme.COURSE_COLORS[color_index]
            
            # 设置课程信息显示
            course_name = course['name'][:8] + "..." if len(course['name']) > 8 else course['name']
            teacher_name = course['teacher'][:6] + "..." if len(course['teacher']) > 6 else course['teacher']
            place_name = course['place'][:8] + "..." if len(course['place']) > 8 else course['place']
            
            btn.text = f"{course_name}\n{teacher_name}\n{place_name}"
            btn.background_color = course_color
            btn.color = Theme.WHITE
            btn.bold = True
            
            # 添加阴影效果（通过稍微调整透明度）
            btn.background_color = (*course_color[:3], 0.9)
            
        except Exception as e:
            log_message("ERROR", f"更新课程按钮失败: {e}")
    
    def save_course_to_db(self, course_data, is_new):
        """保存课程到数据库"""
        try:
            if not DB_AVAILABLE:
                return False
            
            # 简化版本，这里应该有完整的数据库操作
            log_message("INFO", f"保存课程: {course_data}")
            return True
            
        except Exception as e:
            log_message("ERROR", f"保存课程到数据库失败: {e}")
            return False
    
    def delete_course_from_db(self, course_data):
        """从数据库删除课程"""
        try:
            if not DB_AVAILABLE:
                return False
            
            # 简化版本，这里应该有完整的数据库操作
            log_message("INFO", f"删除课程: {course_data}")
            return True
            
        except Exception as e:
            log_message("ERROR", f"删除课程失败: {e}")
            return False
    
    def refresh_timetable(self):
        """刷新课表显示"""
        self.load_courses()
    
    def update_status(self, message, is_error=False):
        """更新状态栏"""
        self.status_bar.text = message
        if is_error:
            self.status_bar.color = Theme.DANGER
        else:
            self.status_bar.color = Theme.DARK
        
        # 3秒后恢复默认状态
        if is_error:
            Clock.schedule_once(lambda dt: self.reset_status(), 3)
        else:
            Clock.schedule_once(lambda dt: self.reset_status(), 2)
    
    def reset_status(self):
        """重置状态栏"""
        self.status_bar.text = "智能课表系统 - 安卓版 v4.0"
        self.status_bar.color = Theme.DARK
    
    # =================== 智能提醒系统 ===================
    
    def check_course_reminders(self, dt):
        """检查课程提醒（定时任务）"""
        if not self.reminder_enabled or not DB_AVAILABLE:
            return
        
        try:
            from datetime import datetime, timedelta
            
            current_time = datetime.now()
            current_weekday = current_time.weekday()  # 0=周一, 6=周日
            
            # 只在工作日检查提醒
            if current_weekday >= 5:
                return
            
            # 获取当前周的课程
            current_courses = []
            for course in self.courses:
                if self.is_course_in_current_week(course) and course['day'] == current_weekday:
                    current_courses.append(course)
            
            # 检查每门课程的提醒
            for course in current_courses:
                self.check_single_course_reminder(course, current_time)
                
        except Exception as e:
            log_message("ERROR", f"检查课程提醒失败: {str(e)}")
    
    def check_single_course_reminder(self, course, current_time):
        """检查单个课程的提醒"""
        try:
            time_str = course['time']
            course_sections = self.parse_course_sections(time_str)
            
            for section in course_sections:
                if section in self.section_time_map:
                    # 计算课程开始时间
                    hour, minute = self.section_time_map[section]
                    course_start = current_time.replace(hour=hour, minute=minute, second=0, microsecond=0)
                    
                    # 计算提醒时间
                    reminder_time = course_start - timedelta(minutes=self.reminder_advance_minutes)
                    
                    # 创建唯一标识
                    course_id = f"{course['name']}_{section}_{current_time.date()}"
                    
                    # 检查是否需要提醒
                    if (current_time >= reminder_time and 
                        current_time <= course_start and
                        course_id not in self.reminded_courses):
                        
                        self.send_course_reminder(course, section, course_start)
                        self.reminded_courses.add(course_id)
            
            # 清理过期的提醒记录
            self.cleanup_old_reminders(current_time)
            
        except Exception as e:
            log_message("ERROR", f"检查单个课程提醒失败: {str(e)}")
    
    def parse_course_sections(self, time_str):
        """解析课程节次"""
        import re
        
        # 匹配单节课：第1节
        single_match = re.search(r'第(\d+)节', time_str)
        if single_match:
            section_num = int(single_match.group(1))
            return [f"第{section_num}节"]
        
        # 匹配连续节课：第1-2节
        range_match = re.search(r'第(\d+)-(\d+)节', time_str)
        if range_match:
            start_section = int(range_match.group(1))
            end_section = int(range_match.group(2))
            return [f"第{i}节" for i in range(start_section, end_section + 1)]
        
        # 默认返回第1节
        return ["第1节"]
    
    def send_course_reminder(self, course, section, course_start_time):
        """发送课程提醒"""
        try:
            start_time_str = course_start_time.strftime("%H:%M")
            
            # 创建提醒消息
            title = "课程提醒"
            message = (f"课程：{course['name']}\n"
                      f"教师：{course['teacher']}\n"
                      f"时间：{section} ({start_time_str})\n"
                      f"地点：{course['place']}\n"
                      f"将在{self.reminder_advance_minutes}分钟后开始")
            
            # 发送系统通知
            self.send_system_notification(title, message)
            
            # 显示通知对话框
            self.show_reminder_popup(title, message)
            
            # 更新状态栏
            self.update_status(f"提醒: {course['name']} {section} {start_time_str}开始", is_error=False)
            
            # 记录日志
            log_message("REMINDER", f"课程提醒: {course['name']} - {section} - {start_time_str}")
            
        except Exception as e:
            error_msg = f"发送课程提醒失败: {str(e)}"
            print(error_msg)  # 控制台输出
            log_message("ERROR", error_msg)
    
    def send_system_notification(self, title, message):
        """发送系统通知"""
        try:
            if NOTIFICATION_AVAILABLE:
                # 清理消息格式，移除换行符用于系统通知
                clean_message = message.replace('\n', ' | ')
                
                notification.notify(
                    title=title,
                    message=clean_message,
                    app_name="智能课表",
                    timeout=10,
                    toast=True  # 在安卓上显示Toast通知
                )
                
                # 控制台输出，用于终端显示
                print(f"\n🔔 系统通知已发送")
                print(f"📝 标题: {title}")
                print(f"📖 内容: {clean_message}")
                
                log_message("NOTIFICATION", f"系统通知已发送: {title}")
            else:
                print("⚠️ 系统通知库不可用，使用控制台输出")
                print(f"🔔 {title}")
                print(f"📝 {message}")
                
        except Exception as e:
            error_msg = f"发送系统通知失败: {str(e)}"
            print(error_msg)
            log_message("ERROR", error_msg)
            # 备用方案：直接在控制台输出
            print(f"🔔 备用通知: {title}")
            print(f"📝 {message}")
    
    def show_reminder_popup(self, title, message):
        """显示提醒弹窗"""
        try:
            # 创建内容布局
            content_layout = BoxLayout(orientation='vertical', spacing=10, padding=15)
            
            # 消息标签
            message_label = Label(
                text=message,
                font_name=FONT_NAME,
                font_size=14,
                color=Theme.DARK,
                text_size=(250, None),
                halign='center',
                valign='middle'
            )
            content_layout.add_widget(message_label)
            
            # 按钮布局
            button_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=40, spacing=10)
            
            # 确定按钮
            ok_button = Button(
                text="确定",
                background_color=Theme.INFO,
                color=Theme.WHITE,
                font_name=FONT_NAME,
                bold=True
            )
            
            # 创建弹窗
            popup = Popup(
                title=title,
                content=content_layout,
                size_hint=(0.8, 0.6),
                auto_dismiss=True
            )
            
            # 绑定确定按钮事件
            ok_button.bind(on_press=popup.dismiss)
            button_layout.add_widget(ok_button)
            content_layout.add_widget(button_layout)
            
            # 设置背景色
            with content_layout.canvas.before:
                Color(*Theme.LIGHT)
                Rectangle(size=content_layout.size, pos=content_layout.pos)
            
            popup.open()
            
            # 10秒后自动关闭
            Clock.schedule_once(lambda dt: popup.dismiss(), 10)
            
        except Exception as e:
            error_msg = f"显示提醒弹窗失败: {str(e)}"
            print(error_msg)  # 控制台输出
            log_message("ERROR", error_msg)
            # 备用提醒方式
            self.update_status("提醒：" + message[:30] + "...", is_error=False)
    
    def cleanup_old_reminders(self, current_time):
        """清理过期的提醒记录"""
        try:
            yesterday = current_time.date() - timedelta(days=1)
            
            # 移除昨天之前的提醒记录
            self.reminded_courses = {
                course_id for course_id in self.reminded_courses 
                if not course_id.endswith(str(yesterday))
            }
            
        except Exception as e:
            log_message("ERROR", f"清理过期提醒记录失败: {str(e)}")
    
    def toggle_reminders(self):
        """切换提醒功能开关"""
        try:
            self.reminder_enabled = not self.reminder_enabled
            
            if self.reminder_enabled:
                # 重新启动定时检查
                Clock.schedule_interval(self.check_course_reminders, 60)
                self.update_status("课程提醒已启用")
                log_message("INFO", "课程提醒已启用")
            else:
                # 停止定时检查
                Clock.unschedule(self.check_course_reminders)
                self.update_status("课程提醒已关闭")
                log_message("INFO", "课程提醒已关闭")
                
        except Exception as e:
            log_message("ERROR", f"切换提醒功能失败: {str(e)}")
            self.update_status("切换提醒功能失败", is_error=True)
    
    def set_reminder_advance_time(self, minutes):
        """设置提醒提前时间"""
        try:
            if 1 <= minutes <= 60:
                self.reminder_advance_minutes = minutes
                self.update_status(f"提醒时间已设置为提前{minutes}分钟")
                log_message("INFO", f"提醒时间设置为提前{minutes}分钟")
            else:
                self.update_status("提醒时间应在1-60分钟之间", is_error=True)
                
        except Exception as e:
            log_message("ERROR", f"设置提醒时间失败: {str(e)}")
            self.update_status("设置提醒时间失败", is_error=True)

if __name__ == '__main__':
    SmartTimetableApp().run() 