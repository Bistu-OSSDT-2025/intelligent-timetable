import pymysql
import logging
import os

# 设置日志配置（可选，写入日志文件而不是控制台）
def setup_logging():
    """设置日志配置"""
    try:
        log_file = os.path.join(os.path.dirname(__file__), 'app.log')
        logging.basicConfig(
            filename=log_file,
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            encoding='utf-8'
        )
    except:
        # 如果日志设置失败，就不记录日志
        pass

# 初始化日志
setup_logging()

# ======================== 通用工具函数 ========================
def get_db_connection():
    """获取数据库连接"""
    try:
        return pymysql.connect(
            host='localhost',
            user='root',
            password='password',
            database='smart timetable',
            charset='utf8mb4'
        )
    except pymysql.Error as e:
        # 静默处理数据库连接错误，写入日志而不是显示错误
        try:
            logging.error(f"数据库连接失败: {e}")
        except:
            pass
        # 返回None而不是抛出异常
        return None

# ======================== 表结构管理 ========================
def check_table_exists(table_name):
    """检查表是否存在"""
    try:
        conn = get_db_connection()
        if conn is None:
            return False
        cursor = conn.cursor()
        cursor.execute(f"SHOW TABLES LIKE '{table_name}'")
        result = cursor.fetchone() is not None
        cursor.close()
        conn.close()
        return result
    except Exception as e:
        try:
            logging.error(f"检查表存在性失败: {e}")
        except:
            pass
        return False

def delete_table_by_name(table_name):
    """根据课程名称删除表格"""
    try:
        if not check_table_exists(table_name):
            return False

        conn = get_db_connection()
        if conn is None:
            return False
        cursor = conn.cursor()
        try:
            cursor.execute(f"DROP TABLE {table_name}")
            conn.commit()
            try:
                logging.info(f"成功删除表 {table_name}")
            except:
                pass
            return True
        except Exception as e:
            conn.rollback()
            try:
                logging.error(f"删除表失败: {e}")
            except:
                pass
            return False
        finally:
            cursor.close()
            conn.close()
    except Exception as e:
        try:
            logging.error(f"删除表操作失败: {e}")
        except:
            pass
        return False

# ======================== 数据增删改查（按课程表） ========================
def get_min_available_id(table_name):
    """获取指定表中最小的空缺 ID（从 1 开始找）"""
    try:
        conn = get_db_connection()
        if conn is None:
            return 1
        cursor = conn.cursor()

        cursor.execute(f"SELECT id FROM {table_name} ORDER BY id ASC")
        existing_ids = [row[0] for row in cursor.fetchall()]

        min_id = 1
        for id in existing_ids:
            if id > min_id:
                break
            min_id += 1

        cursor.close()
        conn.close()
        return min_id
    except Exception as e:
        try:
            logging.error(f"获取最小可用ID失败: {e}")
        except:
            pass
        return 1

def insert_into_table(table_name, place, time, week, teacher, day, term):
    """插入数据到指定课程表（自动创建表）"""
    try:
        if not check_table_exists(table_name):
            # 创建新表
            create_table_sql = f"""
            CREATE TABLE `{table_name}` (
                id INT PRIMARY KEY AUTO_INCREMENT,
                place VARCHAR(255),
                time VARCHAR(255),
                week INT,
                teacher VARCHAR(255),
                day VARCHAR(255),
                term VARCHAR(255)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """
            conn = get_db_connection()
            if conn is None:
                return False
            cursor = conn.cursor()
            try:
                cursor.execute(create_table_sql)
                conn.commit()
                new_id = 1
                try:
                    logging.info(f"成功创建表 {table_name}")
                except:
                    pass
            except Exception as e:
                conn.rollback()
                try:
                    logging.error(f"创建表失败: {e}")
                except:
                    pass
                return False
            finally:
                cursor.close()
                conn.close()
        else:
            new_id = get_min_available_id(table_name)

        # 插入数据
        conn = get_db_connection()
        if conn is None:
            return False
        cursor = conn.cursor()
        sql = f"""
        INSERT INTO `{table_name}` (id, place, time, week, teacher, day, term) 
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        data = (new_id, place, time, week, teacher, day, term)

        try:
            cursor.execute(sql, data)
            conn.commit()
            try:
                logging.info(f"成功插入 {table_name} 表，ID: {new_id}")
            except:
                pass
            return True
        except Exception as e:
            conn.rollback()
            try:
                logging.error(f"插入失败: {e}")
            except:
                pass
            return False
        finally:
            cursor.close()
            conn.close()
    except Exception as e:
        try:
            logging.error(f"插入操作失败: {e}")
        except:
            pass
        return False

def query_by_id_and_table(table_name, record_id):
    """根据课程表名和ID查询数据"""
    try:
        if not check_table_exists(table_name):
            return None

        conn = get_db_connection()
        if conn is None:
            return None
        cursor = conn.cursor(pymysql.cursors.DictCursor)
        sql = f"SELECT * FROM `{table_name}` WHERE id = %s"
        data = (record_id,)

        try:
            cursor.execute(sql, data)
            result = cursor.fetchone()
            return result
        except Exception as e:
            try:
                logging.error(f"查询失败: {e}")
            except:
                pass
            return None
        finally:
            cursor.close()
            conn.close()
    except Exception as e:
        try:
            logging.error(f"查询操作失败: {e}")
        except:
            pass
        return None

def update_field(table_name, record_id, field_name, new_value):
    """单独修改指定字段的值（按课程表名+ID）"""
    try:
        valid_fields = ['place', 'time', 'week', 'teacher', 'day', 'term']
        if field_name not in valid_fields:
            return False

        if not check_table_exists(table_name):
            return False

        # 先查询记录是否存在
        record = query_by_id_and_table(table_name, record_id)
        if not record:
            return False

        conn = get_db_connection()
        if conn is None:
            return False
        cursor = conn.cursor()
        sql = f"UPDATE `{table_name}` SET {field_name} = %s WHERE id = %s"
        data = (new_value, record_id)

        try:
            cursor.execute(sql, data)
            if cursor.rowcount > 0:
                conn.commit()
                try:
                    logging.info(f"成功修改 {table_name} 表 ID:{record_id} 的 {field_name} 字段为 {new_value}")
                except:
                    pass
                return True
            else:
                return False
        except Exception as e:
            conn.rollback()
            try:
                logging.error(f"修改失败: {e}")
            except:
                pass
            return False
        finally:
            cursor.close()
            conn.close()
    except Exception as e:
        try:
            logging.error(f"修改操作失败: {e}")
        except:
            pass
        return False

def delete_by_id_and_table(table_name, record_id):
    """根据课程表名和ID删除数据"""
    try:
        if not check_table_exists(table_name):
            return False

        # 先查询记录是否存在
        record = query_by_id_and_table(table_name, record_id)
        if not record:
            return False

        conn = get_db_connection()
        if conn is None:
            return False
        cursor = conn.cursor()
        sql = f"DELETE FROM `{table_name}` WHERE id = %s"
        data = (record_id,)

        try:
            cursor.execute(sql, data)
            if cursor.rowcount > 0:
                conn.commit()
                try:
                    logging.info(f"成功删除 {table_name} 表中 ID:{record_id} 的记录")
                except:
                    pass
                return True
            else:
                return False
        except Exception as e:
            conn.rollback()
            try:
                logging.error(f"删除失败: {e}")
            except:
                pass
            return False
        finally:
            cursor.close()
            conn.close()
    except Exception as e:
        try:
            logging.error(f"删除操作失败: {e}")
        except:
            pass
        return False

def get_all_table_names():
    """获取数据库中所有表的名称"""
    try:
        conn = get_db_connection()
        if conn is None:
            return []
        cursor = conn.cursor()
        cursor.execute("SHOW TABLES")
        tables = [table[0] for table in cursor.fetchall()]
        cursor.close()
        conn.close()
        return tables
    except Exception as e:
        try:
            logging.error(f"获取所有表名失败: {e}")
        except:
            pass
        return []

def delete_all_tables():
    """删除数据库中所有表"""
    try:
        table_names = get_all_table_names()
        success_count = 0
        for table_name in table_names:
            if delete_table_by_name(table_name):
                success_count += 1
        try:
            logging.info(f"删除了 {success_count}/{len(table_names)} 个表")
        except:
            pass
        return success_count == len(table_names)
    except Exception as e:
        try:
            logging.error(f"删除所有表失败: {e}")
        except:
            pass
        return False 